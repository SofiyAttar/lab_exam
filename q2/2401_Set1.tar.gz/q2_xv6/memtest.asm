
_memtest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:

int global_var = 123;

int
main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
   f:	83 ec 28             	sub    $0x28,%esp
  int p[2];
  int pid;
  int before_fork, after_fork, after_wait;
  int parent_pa, child_pa;
  char c = 'x';
  12:	c6 45 ef 78          	movb   $0x78,-0x11(%ebp)
  char *addr;

  printf(1, "\n===== MEMORY STATISTICS TEST =====\n");
  16:	68 1c 0b 00 00       	push   $0xb1c
  1b:	6a 01                	push   $0x1
  1d:	e8 5e 06 00 00       	call   680 <printf>

  // 1. Check free pages at startup.
  printf(1, "Free pages at startup: %d\n", freepages());
  22:	e8 6c 05 00 00       	call   593 <freepages>
  27:	83 c4 0c             	add    $0xc,%esp
  2a:	50                   	push   %eax
  2b:	68 ef 09 00 00       	push   $0x9ef
  30:	6a 01                	push   $0x1
  32:	e8 49 06 00 00       	call   680 <printf>

  // 2. Allocate 10 pages.
  addr = sbrk(10 * 4096);
  37:	c7 04 24 00 a0 00 00 	movl   $0xa000,(%esp)
  3e:	e8 38 05 00 00       	call   57b <sbrk>

  if(addr == (char*)-1){
  43:	83 c4 10             	add    $0x10,%esp
  46:	83 f8 ff             	cmp    $0xffffffff,%eax
  49:	0f 84 0a 01 00 00    	je     159 <main+0x159>
    printf(1, "sbrk failed\n");
    exit();
  }

  printf(1, "Free pages after allocating 10 pages: %d\n",
  4f:	e8 3f 05 00 00       	call   593 <freepages>
  54:	83 ec 04             	sub    $0x4,%esp
  57:	50                   	push   %eax
  58:	68 44 0b 00 00       	push   $0xb44
  5d:	6a 01                	push   $0x1
  5f:	e8 1c 06 00 00       	call   680 <printf>
         freepages());

  // 3. Translate the address of a global variable.
  printf(1, "\nGlobal variable address: 0x%x\n",
  64:	83 c4 0c             	add    $0xc,%esp
  67:	68 28 0f 00 00       	push   $0xf28
  6c:	68 70 0b 00 00       	push   $0xb70
  71:	6a 01                	push   $0x1
  73:	e8 08 06 00 00       	call   680 <printf>
         (uint)&global_var);

  printf(1, "Physical address: 0x%x\n",
  78:	c7 04 24 28 0f 00 00 	movl   $0xf28,(%esp)
  7f:	e8 17 05 00 00       	call   59b <va2pa>
  84:	83 c4 0c             	add    $0xc,%esp
  87:	50                   	push   %eax
  88:	68 17 0a 00 00       	push   $0xa17
  8d:	6a 01                	push   $0x1
  8f:	e8 ec 05 00 00       	call   680 <printf>
         va2pa((int)&global_var));

  // 4. Test an invalid address.
  printf(1, "\nTesting invalid address 0x7fffffff:\n");
  94:	58                   	pop    %eax
  95:	5a                   	pop    %edx
  96:	68 90 0b 00 00       	push   $0xb90
  9b:	6a 01                	push   $0x1
  9d:	e8 de 05 00 00       	call   680 <printf>
  printf(1, "Translation result: %d\n",
  a2:	c7 04 24 ff ff ff 7f 	movl   $0x7fffffff,(%esp)
  a9:	e8 ed 04 00 00       	call   59b <va2pa>
  ae:	83 c4 0c             	add    $0xc,%esp
  b1:	50                   	push   %eax
  b2:	68 2f 0a 00 00       	push   $0xa2f
  b7:	6a 01                	push   $0x1
  b9:	e8 c2 05 00 00       	call   680 <printf>
         va2pa(0x7fffffff));

  // 5. Create a pipe to keep the child alive.
  if(pipe(p) < 0){
  be:	8d 45 f0             	lea    -0x10(%ebp),%eax
  c1:	89 04 24             	mov    %eax,(%esp)
  c4:	e8 3a 04 00 00       	call   503 <pipe>
  c9:	83 c4 10             	add    $0x10,%esp
  cc:	85 c0                	test   %eax,%eax
  ce:	78 76                	js     146 <main+0x146>
    printf(1, "Pipe creation failed\n");
    exit();
  }

  before_fork = freepages();
  d0:	e8 be 04 00 00       	call   593 <freepages>
  d5:	89 c3                	mov    %eax,%ebx

  pid = fork();
  d7:	e8 0f 04 00 00       	call   4eb <fork>

  if(pid < 0){
  dc:	85 c0                	test   %eax,%eax
  de:	0f 88 5e 01 00 00    	js     242 <main+0x242>
    close(p[0]);
    close(p[1]);
    exit();
  }

  if(pid == 0){
  e4:	0f 85 82 00 00 00    	jne    16c <main+0x16c>
    // Child process.
    close(p[1]);
  ea:	83 ec 0c             	sub    $0xc,%esp
  ed:	ff 75 f4             	push   -0xc(%ebp)
  f0:	e8 26 04 00 00       	call   51b <close>

    child_pa = va2pa((int)&global_var);
  f5:	c7 04 24 28 0f 00 00 	movl   $0xf28,(%esp)
  fc:	e8 9a 04 00 00       	call   59b <va2pa>

    printf(1, "\nChild virtual address: 0x%x\n",
 101:	83 c4 0c             	add    $0xc,%esp
 104:	68 28 0f 00 00       	push   $0xf28
    child_pa = va2pa((int)&global_var);
 109:	89 c3                	mov    %eax,%ebx
    printf(1, "\nChild virtual address: 0x%x\n",
 10b:	68 6a 0a 00 00       	push   $0xa6a
 110:	6a 01                	push   $0x1
 112:	e8 69 05 00 00       	call   680 <printf>
           (uint)&global_var);
    printf(1, "Child physical address: 0x%x\n",
 117:	83 c4 0c             	add    $0xc,%esp
 11a:	53                   	push   %ebx
 11b:	68 88 0a 00 00       	push   $0xa88
 120:	6a 01                	push   $0x1
 122:	e8 59 05 00 00       	call   680 <printf>
           child_pa);

    // Wait until parent finishes checking memory.
    read(p[0], &c, 1);
 127:	83 c4 0c             	add    $0xc,%esp
 12a:	8d 45 ef             	lea    -0x11(%ebp),%eax
 12d:	6a 01                	push   $0x1
 12f:	50                   	push   %eax
 130:	ff 75 f0             	push   -0x10(%ebp)
 133:	e8 d3 03 00 00       	call   50b <read>

    close(p[0]);
 138:	5b                   	pop    %ebx
 139:	ff 75 f0             	push   -0x10(%ebp)
 13c:	e8 da 03 00 00       	call   51b <close>
    exit();
 141:	e8 ad 03 00 00       	call   4f3 <exit>
    printf(1, "Pipe creation failed\n");
 146:	50                   	push   %eax
 147:	50                   	push   %eax
 148:	68 47 0a 00 00       	push   $0xa47
 14d:	6a 01                	push   $0x1
 14f:	e8 2c 05 00 00       	call   680 <printf>
    exit();
 154:	e8 9a 03 00 00       	call   4f3 <exit>
    printf(1, "sbrk failed\n");
 159:	51                   	push   %ecx
 15a:	51                   	push   %ecx
 15b:	68 0a 0a 00 00       	push   $0xa0a
 160:	6a 01                	push   $0x1
 162:	e8 19 05 00 00       	call   680 <printf>
    exit();
 167:	e8 87 03 00 00       	call   4f3 <exit>
  }

  // Parent process.
  close(p[0]);
 16c:	83 ec 0c             	sub    $0xc,%esp
 16f:	ff 75 f0             	push   -0x10(%ebp)
 172:	e8 a4 03 00 00       	call   51b <close>

  parent_pa = va2pa((int)&global_var);
 177:	c7 04 24 28 0f 00 00 	movl   $0xf28,(%esp)
 17e:	e8 18 04 00 00       	call   59b <va2pa>

  printf(1, "\nParent virtual address: 0x%x\n",
 183:	83 c4 0c             	add    $0xc,%esp
 186:	68 28 0f 00 00       	push   $0xf28
 18b:	68 b8 0b 00 00       	push   $0xbb8
 190:	6a 01                	push   $0x1
  parent_pa = va2pa((int)&global_var);
 192:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  printf(1, "\nParent virtual address: 0x%x\n",
 195:	e8 e6 04 00 00       	call   680 <printf>
         (uint)&global_var);
  printf(1, "Parent physical address: 0x%x\n",
 19a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 19d:	83 c4 0c             	add    $0xc,%esp
 1a0:	50                   	push   %eax
 1a1:	68 d8 0b 00 00       	push   $0xbd8
 1a6:	6a 01                	push   $0x1
 1a8:	e8 d3 04 00 00       	call   680 <printf>
         parent_pa);

  after_fork = freepages();
 1ad:	e8 e1 03 00 00       	call   593 <freepages>

  printf(1, "\nFree pages before fork: %d\n", before_fork);
 1b2:	83 c4 0c             	add    $0xc,%esp
 1b5:	53                   	push   %ebx
 1b6:	68 a6 0a 00 00       	push   $0xaa6
 1bb:	6a 01                	push   $0x1
  after_fork = freepages();
 1bd:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  printf(1, "\nFree pages before fork: %d\n", before_fork);
 1c0:	e8 bb 04 00 00       	call   680 <printf>
  printf(1, "Free pages after fork: %d\n", after_fork);
 1c5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 1c8:	83 c4 0c             	add    $0xc,%esp
 1cb:	50                   	push   %eax
 1cc:	68 c3 0a 00 00       	push   $0xac3
 1d1:	6a 01                	push   $0x1
 1d3:	e8 a8 04 00 00       	call   680 <printf>

  // Allow child to exit.
  write(p[1], &c, 1);
 1d8:	83 c4 0c             	add    $0xc,%esp
 1db:	8d 45 ef             	lea    -0x11(%ebp),%eax
 1de:	6a 01                	push   $0x1
 1e0:	50                   	push   %eax
 1e1:	ff 75 f4             	push   -0xc(%ebp)
 1e4:	e8 2a 03 00 00       	call   513 <write>
  close(p[1]);
 1e9:	58                   	pop    %eax
 1ea:	ff 75 f4             	push   -0xc(%ebp)
 1ed:	e8 29 03 00 00       	call   51b <close>

  wait();
 1f2:	e8 04 03 00 00       	call   4fb <wait>

  after_wait = freepages();
 1f7:	e8 97 03 00 00       	call   593 <freepages>

  printf(1, "Free pages after child exit and wait: %d\n",
 1fc:	83 c4 0c             	add    $0xc,%esp
 1ff:	50                   	push   %eax
 200:	68 f8 0b 00 00       	push   $0xbf8
 205:	6a 01                	push   $0x1
 207:	89 45 e4             	mov    %eax,-0x1c(%ebp)
 20a:	e8 71 04 00 00       	call   680 <printf>
         after_wait);

  printf(1, "\nFree pages restored: %s\n",
 20f:	83 c4 0c             	add    $0xc,%esp
 212:	ba e8 09 00 00       	mov    $0x9e8,%edx
 217:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
 21a:	b8 ec 09 00 00       	mov    $0x9ec,%eax
 21f:	0f 44 c2             	cmove  %edx,%eax
 222:	50                   	push   %eax
 223:	68 de 0a 00 00       	push   $0xade
 228:	6a 01                	push   $0x1
 22a:	e8 51 04 00 00       	call   680 <printf>
         after_wait == before_fork ? "YES" : "NO");

  printf(1, "===== TEST COMPLETE =====\n");
 22f:	5a                   	pop    %edx
 230:	59                   	pop    %ecx
 231:	68 f8 0a 00 00       	push   $0xaf8
 236:	6a 01                	push   $0x1
 238:	e8 43 04 00 00       	call   680 <printf>

  exit();
 23d:	e8 b1 02 00 00       	call   4f3 <exit>
    printf(1, "Fork failed\n");
 242:	50                   	push   %eax
 243:	50                   	push   %eax
 244:	68 5d 0a 00 00       	push   $0xa5d
 249:	6a 01                	push   $0x1
 24b:	e8 30 04 00 00       	call   680 <printf>
    close(p[0]);
 250:	58                   	pop    %eax
 251:	ff 75 f0             	push   -0x10(%ebp)
 254:	e8 c2 02 00 00       	call   51b <close>
    close(p[1]);
 259:	58                   	pop    %eax
 25a:	ff 75 f4             	push   -0xc(%ebp)
 25d:	e8 b9 02 00 00       	call   51b <close>
    exit();
 262:	e8 8c 02 00 00       	call   4f3 <exit>
 267:	66 90                	xchg   %ax,%ax
 269:	66 90                	xchg   %ax,%ax
 26b:	66 90                	xchg   %ax,%ax
 26d:	66 90                	xchg   %ax,%ax
 26f:	66 90                	xchg   %ax,%ax
 271:	66 90                	xchg   %ax,%ax
 273:	66 90                	xchg   %ax,%ax
 275:	66 90                	xchg   %ax,%ax
 277:	66 90                	xchg   %ax,%ax
 279:	66 90                	xchg   %ax,%ax
 27b:	66 90                	xchg   %ax,%ax
 27d:	66 90                	xchg   %ax,%ax
 27f:	90                   	nop

00000280 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 280:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 281:	31 c0                	xor    %eax,%eax
{
 283:	89 e5                	mov    %esp,%ebp
 285:	53                   	push   %ebx
 286:	8b 4d 08             	mov    0x8(%ebp),%ecx
 289:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 28c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 290:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 294:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 297:	83 c0 01             	add    $0x1,%eax
 29a:	84 d2                	test   %dl,%dl
 29c:	75 f2                	jne    290 <strcpy+0x10>
    ;
  return os;
}
 29e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2a1:	89 c8                	mov    %ecx,%eax
 2a3:	c9                   	leave
 2a4:	c3                   	ret
 2a5:	8d 76 00             	lea    0x0(%esi),%esi
 2a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2af:	00 

000002b0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2b0:	55                   	push   %ebp
 2b1:	89 e5                	mov    %esp,%ebp
 2b3:	53                   	push   %ebx
 2b4:	8b 55 08             	mov    0x8(%ebp),%edx
 2b7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 2ba:	0f b6 02             	movzbl (%edx),%eax
 2bd:	84 c0                	test   %al,%al
 2bf:	75 2d                	jne    2ee <strcmp+0x3e>
 2c1:	eb 4a                	jmp    30d <strcmp+0x5d>
 2c3:	eb 1b                	jmp    2e0 <strcmp+0x30>
 2c5:	8d 76 00             	lea    0x0(%esi),%esi
 2c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2cf:	00 
 2d0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2d7:	00 
 2d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2df:	00 
 2e0:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 2e4:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 2e7:	84 c0                	test   %al,%al
 2e9:	74 15                	je     300 <strcmp+0x50>
 2eb:	83 c1 01             	add    $0x1,%ecx
 2ee:	0f b6 19             	movzbl (%ecx),%ebx
 2f1:	38 c3                	cmp    %al,%bl
 2f3:	74 eb                	je     2e0 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 2f5:	29 d8                	sub    %ebx,%eax
}
 2f7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2fa:	c9                   	leave
 2fb:	c3                   	ret
 2fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 300:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 304:	31 c0                	xor    %eax,%eax
 306:	29 d8                	sub    %ebx,%eax
}
 308:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 30b:	c9                   	leave
 30c:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 30d:	0f b6 19             	movzbl (%ecx),%ebx
 310:	31 c0                	xor    %eax,%eax
 312:	eb e1                	jmp    2f5 <strcmp+0x45>
 314:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 318:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 31f:	00 

00000320 <strlen>:

uint
strlen(const char *s)
{
 320:	55                   	push   %ebp
 321:	89 e5                	mov    %esp,%ebp
 323:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 326:	80 3a 00             	cmpb   $0x0,(%edx)
 329:	74 15                	je     340 <strlen+0x20>
 32b:	31 c0                	xor    %eax,%eax
 32d:	8d 76 00             	lea    0x0(%esi),%esi
 330:	83 c0 01             	add    $0x1,%eax
 333:	89 c1                	mov    %eax,%ecx
 335:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 339:	75 f5                	jne    330 <strlen+0x10>
    ;
  return n;
}
 33b:	89 c8                	mov    %ecx,%eax
 33d:	5d                   	pop    %ebp
 33e:	c3                   	ret
 33f:	90                   	nop
  for(n = 0; s[n]; n++)
 340:	31 c9                	xor    %ecx,%ecx
}
 342:	5d                   	pop    %ebp
 343:	89 c8                	mov    %ecx,%eax
 345:	c3                   	ret
 346:	66 90                	xchg   %ax,%ax
 348:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 34f:	00 

00000350 <memset>:

void*
memset(void *dst, int c, uint n)
{
 350:	55                   	push   %ebp
 351:	89 e5                	mov    %esp,%ebp
 353:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 354:	8b 4d 10             	mov    0x10(%ebp),%ecx
 357:	8b 45 0c             	mov    0xc(%ebp),%eax
 35a:	8b 7d 08             	mov    0x8(%ebp),%edi
 35d:	fc                   	cld
 35e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 360:	8b 45 08             	mov    0x8(%ebp),%eax
 363:	8b 7d fc             	mov    -0x4(%ebp),%edi
 366:	c9                   	leave
 367:	c3                   	ret
 368:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 36f:	00 

00000370 <strchr>:

char*
strchr(const char *s, char c)
{
 370:	55                   	push   %ebp
 371:	89 e5                	mov    %esp,%ebp
 373:	8b 45 08             	mov    0x8(%ebp),%eax
 376:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 37a:	0f b6 10             	movzbl (%eax),%edx
 37d:	84 d2                	test   %dl,%dl
 37f:	75 1a                	jne    39b <strchr+0x2b>
 381:	eb 25                	jmp    3a8 <strchr+0x38>
 383:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 388:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 38f:	00 
 390:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 394:	83 c0 01             	add    $0x1,%eax
 397:	84 d2                	test   %dl,%dl
 399:	74 0d                	je     3a8 <strchr+0x38>
    if(*s == c)
 39b:	38 d1                	cmp    %dl,%cl
 39d:	75 f1                	jne    390 <strchr+0x20>
      return (char*)s;
  return 0;
}
 39f:	5d                   	pop    %ebp
 3a0:	c3                   	ret
 3a1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 3a8:	31 c0                	xor    %eax,%eax
}
 3aa:	5d                   	pop    %ebp
 3ab:	c3                   	ret
 3ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003b0 <gets>:

char*
gets(char *buf, int max)
{
 3b0:	55                   	push   %ebp
 3b1:	89 e5                	mov    %esp,%ebp
 3b3:	57                   	push   %edi
 3b4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 3b5:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 3b8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 3b9:	31 db                	xor    %ebx,%ebx
{
 3bb:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 3be:	eb 27                	jmp    3e7 <gets+0x37>
    cc = read(0, &c, 1);
 3c0:	83 ec 04             	sub    $0x4,%esp
 3c3:	6a 01                	push   $0x1
 3c5:	57                   	push   %edi
 3c6:	6a 00                	push   $0x0
 3c8:	e8 3e 01 00 00       	call   50b <read>
    if(cc < 1)
 3cd:	83 c4 10             	add    $0x10,%esp
 3d0:	85 c0                	test   %eax,%eax
 3d2:	7e 1d                	jle    3f1 <gets+0x41>
      break;
    buf[i++] = c;
 3d4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 3d8:	8b 55 08             	mov    0x8(%ebp),%edx
 3db:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 3df:	3c 0a                	cmp    $0xa,%al
 3e1:	74 1d                	je     400 <gets+0x50>
 3e3:	3c 0d                	cmp    $0xd,%al
 3e5:	74 19                	je     400 <gets+0x50>
  for(i=0; i+1 < max; ){
 3e7:	89 de                	mov    %ebx,%esi
 3e9:	83 c3 01             	add    $0x1,%ebx
 3ec:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 3ef:	7c cf                	jl     3c0 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 3f1:	8b 45 08             	mov    0x8(%ebp),%eax
 3f4:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 3f8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3fb:	5b                   	pop    %ebx
 3fc:	5e                   	pop    %esi
 3fd:	5f                   	pop    %edi
 3fe:	5d                   	pop    %ebp
 3ff:	c3                   	ret
  buf[i] = '\0';
 400:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 403:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 405:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 409:	8d 65 f4             	lea    -0xc(%ebp),%esp
 40c:	5b                   	pop    %ebx
 40d:	5e                   	pop    %esi
 40e:	5f                   	pop    %edi
 40f:	5d                   	pop    %ebp
 410:	c3                   	ret
 411:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 418:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 41f:	00 

00000420 <stat>:

int
stat(const char *n, struct stat *st)
{
 420:	55                   	push   %ebp
 421:	89 e5                	mov    %esp,%ebp
 423:	56                   	push   %esi
 424:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 425:	83 ec 08             	sub    $0x8,%esp
 428:	6a 00                	push   $0x0
 42a:	ff 75 08             	push   0x8(%ebp)
 42d:	e8 01 01 00 00       	call   533 <open>
  if(fd < 0)
 432:	83 c4 10             	add    $0x10,%esp
 435:	85 c0                	test   %eax,%eax
 437:	78 27                	js     460 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 439:	83 ec 08             	sub    $0x8,%esp
 43c:	ff 75 0c             	push   0xc(%ebp)
 43f:	89 c3                	mov    %eax,%ebx
 441:	50                   	push   %eax
 442:	e8 04 01 00 00       	call   54b <fstat>
  close(fd);
 447:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 44a:	89 c6                	mov    %eax,%esi
  close(fd);
 44c:	e8 ca 00 00 00       	call   51b <close>
  return r;
 451:	83 c4 10             	add    $0x10,%esp
}
 454:	8d 65 f8             	lea    -0x8(%ebp),%esp
 457:	89 f0                	mov    %esi,%eax
 459:	5b                   	pop    %ebx
 45a:	5e                   	pop    %esi
 45b:	5d                   	pop    %ebp
 45c:	c3                   	ret
 45d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 460:	be ff ff ff ff       	mov    $0xffffffff,%esi
 465:	eb ed                	jmp    454 <stat+0x34>
 467:	90                   	nop
 468:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 46f:	00 

00000470 <atoi>:

int
atoi(const char *s)
{
 470:	55                   	push   %ebp
 471:	89 e5                	mov    %esp,%ebp
 473:	53                   	push   %ebx
 474:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 477:	0f be 02             	movsbl (%edx),%eax
 47a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 47d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 480:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 485:	77 2e                	ja     4b5 <atoi+0x45>
 487:	eb 17                	jmp    4a0 <atoi+0x30>
 489:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 490:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 497:	00 
 498:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 49f:	00 
    n = n*10 + *s++ - '0';
 4a0:	83 c2 01             	add    $0x1,%edx
 4a3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 4a6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 4aa:	0f be 02             	movsbl (%edx),%eax
 4ad:	8d 58 d0             	lea    -0x30(%eax),%ebx
 4b0:	80 fb 09             	cmp    $0x9,%bl
 4b3:	76 eb                	jbe    4a0 <atoi+0x30>
  return n;
}
 4b5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 4b8:	89 c8                	mov    %ecx,%eax
 4ba:	c9                   	leave
 4bb:	c3                   	ret
 4bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000004c0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 4c0:	55                   	push   %ebp
 4c1:	89 e5                	mov    %esp,%ebp
 4c3:	57                   	push   %edi
 4c4:	8b 45 10             	mov    0x10(%ebp),%eax
 4c7:	8b 55 08             	mov    0x8(%ebp),%edx
 4ca:	56                   	push   %esi
 4cb:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 4ce:	85 c0                	test   %eax,%eax
 4d0:	7e 13                	jle    4e5 <memmove+0x25>
 4d2:	01 d0                	add    %edx,%eax
  dst = vdst;
 4d4:	89 d7                	mov    %edx,%edi
 4d6:	66 90                	xchg   %ax,%ax
 4d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4df:	00 
    *dst++ = *src++;
 4e0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 4e1:	39 f8                	cmp    %edi,%eax
 4e3:	75 fb                	jne    4e0 <memmove+0x20>
  return vdst;
}
 4e5:	5e                   	pop    %esi
 4e6:	89 d0                	mov    %edx,%eax
 4e8:	5f                   	pop    %edi
 4e9:	5d                   	pop    %ebp
 4ea:	c3                   	ret

000004eb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 4eb:	b8 01 00 00 00       	mov    $0x1,%eax
 4f0:	cd 40                	int    $0x40
 4f2:	c3                   	ret

000004f3 <exit>:
SYSCALL(exit)
 4f3:	b8 02 00 00 00       	mov    $0x2,%eax
 4f8:	cd 40                	int    $0x40
 4fa:	c3                   	ret

000004fb <wait>:
SYSCALL(wait)
 4fb:	b8 03 00 00 00       	mov    $0x3,%eax
 500:	cd 40                	int    $0x40
 502:	c3                   	ret

00000503 <pipe>:
SYSCALL(pipe)
 503:	b8 04 00 00 00       	mov    $0x4,%eax
 508:	cd 40                	int    $0x40
 50a:	c3                   	ret

0000050b <read>:
SYSCALL(read)
 50b:	b8 05 00 00 00       	mov    $0x5,%eax
 510:	cd 40                	int    $0x40
 512:	c3                   	ret

00000513 <write>:
SYSCALL(write)
 513:	b8 10 00 00 00       	mov    $0x10,%eax
 518:	cd 40                	int    $0x40
 51a:	c3                   	ret

0000051b <close>:
SYSCALL(close)
 51b:	b8 15 00 00 00       	mov    $0x15,%eax
 520:	cd 40                	int    $0x40
 522:	c3                   	ret

00000523 <kill>:
SYSCALL(kill)
 523:	b8 06 00 00 00       	mov    $0x6,%eax
 528:	cd 40                	int    $0x40
 52a:	c3                   	ret

0000052b <exec>:
SYSCALL(exec)
 52b:	b8 07 00 00 00       	mov    $0x7,%eax
 530:	cd 40                	int    $0x40
 532:	c3                   	ret

00000533 <open>:
SYSCALL(open)
 533:	b8 0f 00 00 00       	mov    $0xf,%eax
 538:	cd 40                	int    $0x40
 53a:	c3                   	ret

0000053b <mknod>:
SYSCALL(mknod)
 53b:	b8 11 00 00 00       	mov    $0x11,%eax
 540:	cd 40                	int    $0x40
 542:	c3                   	ret

00000543 <unlink>:
SYSCALL(unlink)
 543:	b8 12 00 00 00       	mov    $0x12,%eax
 548:	cd 40                	int    $0x40
 54a:	c3                   	ret

0000054b <fstat>:
SYSCALL(fstat)
 54b:	b8 08 00 00 00       	mov    $0x8,%eax
 550:	cd 40                	int    $0x40
 552:	c3                   	ret

00000553 <link>:
SYSCALL(link)
 553:	b8 13 00 00 00       	mov    $0x13,%eax
 558:	cd 40                	int    $0x40
 55a:	c3                   	ret

0000055b <mkdir>:
SYSCALL(mkdir)
 55b:	b8 14 00 00 00       	mov    $0x14,%eax
 560:	cd 40                	int    $0x40
 562:	c3                   	ret

00000563 <chdir>:
SYSCALL(chdir)
 563:	b8 09 00 00 00       	mov    $0x9,%eax
 568:	cd 40                	int    $0x40
 56a:	c3                   	ret

0000056b <dup>:
SYSCALL(dup)
 56b:	b8 0a 00 00 00       	mov    $0xa,%eax
 570:	cd 40                	int    $0x40
 572:	c3                   	ret

00000573 <getpid>:
SYSCALL(getpid)
 573:	b8 0b 00 00 00       	mov    $0xb,%eax
 578:	cd 40                	int    $0x40
 57a:	c3                   	ret

0000057b <sbrk>:
SYSCALL(sbrk)
 57b:	b8 0c 00 00 00       	mov    $0xc,%eax
 580:	cd 40                	int    $0x40
 582:	c3                   	ret

00000583 <sleep>:
SYSCALL(sleep)
 583:	b8 0d 00 00 00       	mov    $0xd,%eax
 588:	cd 40                	int    $0x40
 58a:	c3                   	ret

0000058b <uptime>:
SYSCALL(uptime)
 58b:	b8 0e 00 00 00       	mov    $0xe,%eax
 590:	cd 40                	int    $0x40
 592:	c3                   	ret

00000593 <freepages>:

// Q2: Memory statistics and address translation
SYSCALL(freepages)
 593:	b8 16 00 00 00       	mov    $0x16,%eax
 598:	cd 40                	int    $0x40
 59a:	c3                   	ret

0000059b <va2pa>:
SYSCALL(va2pa)
 59b:	b8 17 00 00 00       	mov    $0x17,%eax
 5a0:	cd 40                	int    $0x40
 5a2:	c3                   	ret
 5a3:	66 90                	xchg   %ax,%ax
 5a5:	66 90                	xchg   %ax,%ax
 5a7:	66 90                	xchg   %ax,%ax
 5a9:	66 90                	xchg   %ax,%ax
 5ab:	66 90                	xchg   %ax,%ax
 5ad:	66 90                	xchg   %ax,%ax
 5af:	66 90                	xchg   %ax,%ax
 5b1:	66 90                	xchg   %ax,%ax
 5b3:	66 90                	xchg   %ax,%ax
 5b5:	66 90                	xchg   %ax,%ax
 5b7:	66 90                	xchg   %ax,%ax
 5b9:	66 90                	xchg   %ax,%ax
 5bb:	66 90                	xchg   %ax,%ax
 5bd:	66 90                	xchg   %ax,%ax
 5bf:	90                   	nop

000005c0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 5c0:	55                   	push   %ebp
 5c1:	89 e5                	mov    %esp,%ebp
 5c3:	57                   	push   %edi
 5c4:	56                   	push   %esi
 5c5:	53                   	push   %ebx
 5c6:	89 cb                	mov    %ecx,%ebx
 5c8:	83 ec 3c             	sub    $0x3c,%esp
 5cb:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5ce:	85 d2                	test   %edx,%edx
 5d0:	0f 89 9a 00 00 00    	jns    670 <printint+0xb0>
 5d6:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 5da:	0f 84 90 00 00 00    	je     670 <printint+0xb0>
    neg = 1;
    x = -xx;
 5e0:	f7 da                	neg    %edx
    neg = 1;
 5e2:	b8 01 00 00 00       	mov    $0x1,%eax
 5e7:	89 45 c0             	mov    %eax,-0x40(%ebp)
 5ea:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 5ec:	31 f6                	xor    %esi,%esi
 5ee:	66 90                	xchg   %ax,%ax
 5f0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5f7:	00 
 5f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5ff:	00 
  do{
    buf[i++] = digits[x % base];
 600:	89 c8                	mov    %ecx,%eax
 602:	31 d2                	xor    %edx,%edx
 604:	89 f7                	mov    %esi,%edi
 606:	f7 f3                	div    %ebx
 608:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 60b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 60d:	0f b6 92 7c 0c 00 00 	movzbl 0xc7c(%edx),%edx
  }while((x /= base) != 0);
 614:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 616:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 61a:	73 e4                	jae    600 <printint+0x40>
  if(neg)
 61c:	8b 45 c0             	mov    -0x40(%ebp),%eax
 61f:	85 c0                	test   %eax,%eax
 621:	74 07                	je     62a <printint+0x6a>
    buf[i++] = '-';
 623:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 628:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 62a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 62e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 631:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 634:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 638:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 63f:	00 
    putc(fd, buf[i]);
 640:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 643:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 646:	83 ee 01             	sub    $0x1,%esi
 649:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 64c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 64f:	6a 01                	push   $0x1
 651:	50                   	push   %eax
 652:	57                   	push   %edi
 653:	e8 bb fe ff ff       	call   513 <write>
  while(--i >= 0)
 658:	83 c4 10             	add    $0x10,%esp
 65b:	39 f3                	cmp    %esi,%ebx
 65d:	75 e1                	jne    640 <printint+0x80>
}
 65f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 662:	5b                   	pop    %ebx
 663:	5e                   	pop    %esi
 664:	5f                   	pop    %edi
 665:	5d                   	pop    %ebp
 666:	c3                   	ret
 667:	90                   	nop
 668:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 66f:	00 
  neg = 0;
 670:	31 c0                	xor    %eax,%eax
 672:	e9 70 ff ff ff       	jmp    5e7 <printint+0x27>
 677:	90                   	nop
 678:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 67f:	00 

00000680 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 680:	55                   	push   %ebp
 681:	89 e5                	mov    %esp,%ebp
 683:	57                   	push   %edi
 684:	56                   	push   %esi
 685:	53                   	push   %ebx
 686:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 689:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 68c:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 68f:	0f b6 13             	movzbl (%ebx),%edx
 692:	83 c3 01             	add    $0x1,%ebx
 695:	84 d2                	test   %dl,%dl
 697:	0f 84 a0 00 00 00    	je     73d <printf+0xbd>
 69d:	8d 45 10             	lea    0x10(%ebp),%eax
 6a0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 6a3:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 6a6:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 6a9:	eb 28                	jmp    6d3 <printf+0x53>
 6ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 6b0:	83 ec 04             	sub    $0x4,%esp
 6b3:	8d 45 e7             	lea    -0x19(%ebp),%eax
 6b6:	88 55 e7             	mov    %dl,-0x19(%ebp)
  for(i = 0; fmt[i]; i++){
 6b9:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 6bc:	6a 01                	push   $0x1
 6be:	50                   	push   %eax
 6bf:	56                   	push   %esi
 6c0:	e8 4e fe ff ff       	call   513 <write>
  for(i = 0; fmt[i]; i++){
 6c5:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 6c9:	83 c4 10             	add    $0x10,%esp
 6cc:	84 d2                	test   %dl,%dl
 6ce:	74 6d                	je     73d <printf+0xbd>
    c = fmt[i] & 0xff;
 6d0:	0f b6 c2             	movzbl %dl,%eax
      if(c == '%'){
 6d3:	83 f8 25             	cmp    $0x25,%eax
 6d6:	75 d8                	jne    6b0 <printf+0x30>
  for(i = 0; fmt[i]; i++){
 6d8:	0f b6 13             	movzbl (%ebx),%edx
 6db:	84 d2                	test   %dl,%dl
 6dd:	74 5e                	je     73d <printf+0xbd>
    c = fmt[i] & 0xff;
 6df:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 6e2:	80 fa 25             	cmp    $0x25,%dl
 6e5:	0f 84 25 01 00 00    	je     810 <printf+0x190>
 6eb:	83 e8 63             	sub    $0x63,%eax
 6ee:	83 f8 15             	cmp    $0x15,%eax
 6f1:	77 0d                	ja     700 <printf+0x80>
 6f3:	ff 24 85 24 0c 00 00 	jmp    *0xc24(,%eax,4)
 6fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 700:	83 ec 04             	sub    $0x4,%esp
 703:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 706:	88 55 d0             	mov    %dl,-0x30(%ebp)
        ap++;
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 709:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 70d:	6a 01                	push   $0x1
 70f:	51                   	push   %ecx
 710:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 713:	56                   	push   %esi
 714:	e8 fa fd ff ff       	call   513 <write>
        putc(fd, c);
 719:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 71d:	83 c4 0c             	add    $0xc,%esp
 720:	88 55 e7             	mov    %dl,-0x19(%ebp)
 723:	6a 01                	push   $0x1
 725:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 728:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 729:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 72c:	56                   	push   %esi
 72d:	e8 e1 fd ff ff       	call   513 <write>
  for(i = 0; fmt[i]; i++){
 732:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 736:	83 c4 10             	add    $0x10,%esp
 739:	84 d2                	test   %dl,%dl
 73b:	75 93                	jne    6d0 <printf+0x50>
      }
      state = 0;
    }
  }
}
 73d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 740:	5b                   	pop    %ebx
 741:	5e                   	pop    %esi
 742:	5f                   	pop    %edi
 743:	5d                   	pop    %ebp
 744:	c3                   	ret
 745:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 748:	83 ec 0c             	sub    $0xc,%esp
 74b:	8b 17                	mov    (%edi),%edx
 74d:	b9 10 00 00 00       	mov    $0x10,%ecx
 752:	89 f0                	mov    %esi,%eax
 754:	6a 00                	push   $0x0
 756:	e8 65 fe ff ff       	call   5c0 <printint>
  for(i = 0; fmt[i]; i++){
 75b:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 75f:	83 c3 02             	add    $0x2,%ebx
 762:	83 c4 10             	add    $0x10,%esp
 765:	84 d2                	test   %dl,%dl
 767:	74 d4                	je     73d <printf+0xbd>
        ap++;
 769:	83 c7 04             	add    $0x4,%edi
 76c:	e9 5f ff ff ff       	jmp    6d0 <printf+0x50>
 771:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 778:	8b 07                	mov    (%edi),%eax
        ap++;
 77a:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 77d:	85 c0                	test   %eax,%eax
 77f:	0f 84 9b 00 00 00    	je     820 <printf+0x1a0>
        while(*s != 0){
 785:	0f b6 10             	movzbl (%eax),%edx
 788:	84 d2                	test   %dl,%dl
 78a:	0f 84 a2 00 00 00    	je     832 <printf+0x1b2>
 790:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 793:	89 c7                	mov    %eax,%edi
 795:	89 d0                	mov    %edx,%eax
 797:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 79a:	89 fb                	mov    %edi,%ebx
 79c:	8d 7d e7             	lea    -0x19(%ebp),%edi
 79f:	90                   	nop
  write(fd, &c, 1);
 7a0:	83 ec 04             	sub    $0x4,%esp
 7a3:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 7a6:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 7a9:	6a 01                	push   $0x1
 7ab:	57                   	push   %edi
 7ac:	56                   	push   %esi
 7ad:	e8 61 fd ff ff       	call   513 <write>
        while(*s != 0){
 7b2:	0f b6 03             	movzbl (%ebx),%eax
 7b5:	83 c4 10             	add    $0x10,%esp
 7b8:	84 c0                	test   %al,%al
 7ba:	75 e4                	jne    7a0 <printf+0x120>
 7bc:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 7bf:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 7c3:	83 c3 02             	add    $0x2,%ebx
 7c6:	84 d2                	test   %dl,%dl
 7c8:	0f 85 d5 fe ff ff    	jne    6a3 <printf+0x23>
 7ce:	e9 6a ff ff ff       	jmp    73d <printf+0xbd>
 7d3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 7d8:	83 ec 0c             	sub    $0xc,%esp
 7db:	8b 17                	mov    (%edi),%edx
 7dd:	b9 0a 00 00 00       	mov    $0xa,%ecx
 7e2:	89 f0                	mov    %esi,%eax
 7e4:	6a 01                	push   $0x1
 7e6:	e8 d5 fd ff ff       	call   5c0 <printint>
  for(i = 0; fmt[i]; i++){
 7eb:	e9 6b ff ff ff       	jmp    75b <printf+0xdb>
        putc(fd, *ap);
 7f0:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 7f2:	83 ec 04             	sub    $0x4,%esp
 7f5:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 7f8:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 7fb:	6a 01                	push   $0x1
 7fd:	51                   	push   %ecx
 7fe:	56                   	push   %esi
 7ff:	e8 0f fd ff ff       	call   513 <write>
 804:	e9 52 ff ff ff       	jmp    75b <printf+0xdb>
 809:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 810:	83 ec 04             	sub    $0x4,%esp
 813:	88 55 e7             	mov    %dl,-0x19(%ebp)
 816:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 819:	6a 01                	push   $0x1
 81b:	e9 08 ff ff ff       	jmp    728 <printf+0xa8>
          s = "(null)";
 820:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 823:	b8 28 00 00 00       	mov    $0x28,%eax
 828:	bf 13 0b 00 00       	mov    $0xb13,%edi
 82d:	e9 65 ff ff ff       	jmp    797 <printf+0x117>
  for(i = 0; fmt[i]; i++){
 832:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 836:	83 c3 02             	add    $0x2,%ebx
 839:	84 d2                	test   %dl,%dl
 83b:	0f 85 8f fe ff ff    	jne    6d0 <printf+0x50>
 841:	e9 f7 fe ff ff       	jmp    73d <printf+0xbd>
 846:	66 90                	xchg   %ax,%ax
 848:	66 90                	xchg   %ax,%ax
 84a:	66 90                	xchg   %ax,%ax
 84c:	66 90                	xchg   %ax,%ax
 84e:	66 90                	xchg   %ax,%ax
 850:	66 90                	xchg   %ax,%ax
 852:	66 90                	xchg   %ax,%ax
 854:	66 90                	xchg   %ax,%ax
 856:	66 90                	xchg   %ax,%ax
 858:	66 90                	xchg   %ax,%ax
 85a:	66 90                	xchg   %ax,%ax
 85c:	66 90                	xchg   %ax,%ax
 85e:	66 90                	xchg   %ax,%ax

00000860 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 860:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 861:	a1 2c 0f 00 00       	mov    0xf2c,%eax
{
 866:	89 e5                	mov    %esp,%ebp
 868:	57                   	push   %edi
 869:	56                   	push   %esi
 86a:	53                   	push   %ebx
 86b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 86e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 871:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 878:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 87f:	00 
 880:	89 c2                	mov    %eax,%edx
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 882:	8b 00                	mov    (%eax),%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 884:	39 ca                	cmp    %ecx,%edx
 886:	73 30                	jae    8b8 <free+0x58>
 888:	39 c1                	cmp    %eax,%ecx
 88a:	72 04                	jb     890 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 88c:	39 c2                	cmp    %eax,%edx
 88e:	72 f0                	jb     880 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 890:	8b 73 fc             	mov    -0x4(%ebx),%esi
 893:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 896:	39 f8                	cmp    %edi,%eax
 898:	74 36                	je     8d0 <free+0x70>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 89a:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 89d:	8b 42 04             	mov    0x4(%edx),%eax
 8a0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 8a3:	39 f1                	cmp    %esi,%ecx
 8a5:	74 40                	je     8e7 <free+0x87>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8a7:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 8a9:	5b                   	pop    %ebx
  freep = p;
 8aa:	89 15 2c 0f 00 00    	mov    %edx,0xf2c
}
 8b0:	5e                   	pop    %esi
 8b1:	5f                   	pop    %edi
 8b2:	5d                   	pop    %ebp
 8b3:	c3                   	ret
 8b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8b8:	39 c2                	cmp    %eax,%edx
 8ba:	72 c4                	jb     880 <free+0x20>
 8bc:	39 c1                	cmp    %eax,%ecx
 8be:	73 c0                	jae    880 <free+0x20>
  if(bp + bp->s.size == p->s.ptr){
 8c0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 8c3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 8c6:	39 f8                	cmp    %edi,%eax
 8c8:	75 d0                	jne    89a <free+0x3a>
 8ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp->s.size += p->s.ptr->s.size;
 8d0:	03 70 04             	add    0x4(%eax),%esi
 8d3:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 8d6:	8b 02                	mov    (%edx),%eax
 8d8:	8b 00                	mov    (%eax),%eax
 8da:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 8dd:	8b 42 04             	mov    0x4(%edx),%eax
 8e0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 8e3:	39 f1                	cmp    %esi,%ecx
 8e5:	75 c0                	jne    8a7 <free+0x47>
    p->s.size += bp->s.size;
 8e7:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 8ea:	89 15 2c 0f 00 00    	mov    %edx,0xf2c
    p->s.size += bp->s.size;
 8f0:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 8f3:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 8f6:	89 0a                	mov    %ecx,(%edx)
}
 8f8:	5b                   	pop    %ebx
 8f9:	5e                   	pop    %esi
 8fa:	5f                   	pop    %edi
 8fb:	5d                   	pop    %ebp
 8fc:	c3                   	ret
 8fd:	8d 76 00             	lea    0x0(%esi),%esi

00000900 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 900:	55                   	push   %ebp
 901:	89 e5                	mov    %esp,%ebp
 903:	57                   	push   %edi
 904:	56                   	push   %esi
 905:	53                   	push   %ebx
 906:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 909:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 90c:	8b 15 2c 0f 00 00    	mov    0xf2c,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 912:	8d 78 07             	lea    0x7(%eax),%edi
 915:	c1 ef 03             	shr    $0x3,%edi
 918:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 91b:	85 d2                	test   %edx,%edx
 91d:	0f 84 8d 00 00 00    	je     9b0 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 923:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 925:	8b 48 04             	mov    0x4(%eax),%ecx
 928:	39 f9                	cmp    %edi,%ecx
 92a:	73 64                	jae    990 <malloc+0x90>
  if(nu < 4096)
 92c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 931:	39 df                	cmp    %ebx,%edi
 933:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 936:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 93d:	eb 0a                	jmp    949 <malloc+0x49>
 93f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 940:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 942:	8b 48 04             	mov    0x4(%eax),%ecx
 945:	39 f9                	cmp    %edi,%ecx
 947:	73 47                	jae    990 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 949:	89 c2                	mov    %eax,%edx
 94b:	39 05 2c 0f 00 00    	cmp    %eax,0xf2c
 951:	75 ed                	jne    940 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 953:	83 ec 0c             	sub    $0xc,%esp
 956:	56                   	push   %esi
 957:	e8 1f fc ff ff       	call   57b <sbrk>
  if(p == (char*)-1)
 95c:	83 c4 10             	add    $0x10,%esp
 95f:	83 f8 ff             	cmp    $0xffffffff,%eax
 962:	74 1c                	je     980 <malloc+0x80>
  hp->s.size = nu;
 964:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 967:	83 ec 0c             	sub    $0xc,%esp
 96a:	83 c0 08             	add    $0x8,%eax
 96d:	50                   	push   %eax
 96e:	e8 ed fe ff ff       	call   860 <free>
  return freep;
 973:	8b 15 2c 0f 00 00    	mov    0xf2c,%edx
      if((p = morecore(nunits)) == 0)
 979:	83 c4 10             	add    $0x10,%esp
 97c:	85 d2                	test   %edx,%edx
 97e:	75 c0                	jne    940 <malloc+0x40>
        return 0;
  }
}
 980:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 983:	31 c0                	xor    %eax,%eax
}
 985:	5b                   	pop    %ebx
 986:	5e                   	pop    %esi
 987:	5f                   	pop    %edi
 988:	5d                   	pop    %ebp
 989:	c3                   	ret
 98a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 990:	39 cf                	cmp    %ecx,%edi
 992:	74 4c                	je     9e0 <malloc+0xe0>
        p->s.size -= nunits;
 994:	29 f9                	sub    %edi,%ecx
 996:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 999:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 99c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 99f:	89 15 2c 0f 00 00    	mov    %edx,0xf2c
}
 9a5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 9a8:	83 c0 08             	add    $0x8,%eax
}
 9ab:	5b                   	pop    %ebx
 9ac:	5e                   	pop    %esi
 9ad:	5f                   	pop    %edi
 9ae:	5d                   	pop    %ebp
 9af:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 9b0:	c7 05 2c 0f 00 00 30 	movl   $0xf30,0xf2c
 9b7:	0f 00 00 
    base.s.size = 0;
 9ba:	b8 30 0f 00 00       	mov    $0xf30,%eax
    base.s.ptr = freep = prevp = &base;
 9bf:	c7 05 30 0f 00 00 30 	movl   $0xf30,0xf30
 9c6:	0f 00 00 
    base.s.size = 0;
 9c9:	c7 05 34 0f 00 00 00 	movl   $0x0,0xf34
 9d0:	00 00 00 
    if(p->s.size >= nunits){
 9d3:	e9 54 ff ff ff       	jmp    92c <malloc+0x2c>
 9d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 9df:	00 
        prevp->s.ptr = p->s.ptr;
 9e0:	8b 08                	mov    (%eax),%ecx
 9e2:	89 0a                	mov    %ecx,(%edx)
 9e4:	eb b9                	jmp    99f <malloc+0x9f>
