
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 90 10 00       	mov    $0x109000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc d0 54 11 80       	mov    $0x801154d0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 50 32 10 80       	mov    $0x80103250,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax
80100034:	66 90                	xchg   %ax,%ax
80100036:	66 90                	xchg   %ax,%ax
80100038:	66 90                	xchg   %ax,%ax
8010003a:	66 90                	xchg   %ax,%ax
8010003c:	66 90                	xchg   %ax,%ax
8010003e:	66 90                	xchg   %ax,%ax

80100040 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100040:	55                   	push   %ebp
80100041:	89 e5                	mov    %esp,%ebp
80100043:	53                   	push   %ebx

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100044:	bb 54 a5 10 80       	mov    $0x8010a554,%ebx
{
80100049:	83 ec 0c             	sub    $0xc,%esp
  initlock(&bcache.lock, "bcache");
8010004c:	68 a0 75 10 80       	push   $0x801075a0
80100051:	68 20 a5 10 80       	push   $0x8010a520
80100056:	e8 05 46 00 00       	call   80104660 <initlock>
  bcache.head.next = &bcache.head;
8010005b:	83 c4 10             	add    $0x10,%esp
8010005e:	b8 1c ec 10 80       	mov    $0x8010ec1c,%eax
  bcache.head.prev = &bcache.head;
80100063:	c7 05 6c ec 10 80 1c 	movl   $0x8010ec1c,0x8010ec6c
8010006a:	ec 10 80 
  bcache.head.next = &bcache.head;
8010006d:	c7 05 70 ec 10 80 1c 	movl   $0x8010ec1c,0x8010ec70
80100074:	ec 10 80 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100077:	eb 0d                	jmp    80100086 <binit+0x46>
80100079:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100080:	81 c3 5c 02 00 00    	add    $0x25c,%ebx
    b->next = bcache.head.next;
80100086:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");
80100089:	83 ec 08             	sub    $0x8,%esp
8010008c:	8d 43 0c             	lea    0xc(%ebx),%eax
    b->prev = &bcache.head;
8010008f:	c7 43 50 1c ec 10 80 	movl   $0x8010ec1c,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100096:	68 a7 75 10 80       	push   $0x801075a7
8010009b:	50                   	push   %eax
8010009c:	e8 8f 44 00 00       	call   80104530 <initsleeplock>
    bcache.head.next->prev = b;
801000a1:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000a6:	83 c4 10             	add    $0x10,%esp
    bcache.head.next->prev = b;
801000a9:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
801000ac:	89 d8                	mov    %ebx,%eax
801000ae:	89 1d 70 ec 10 80    	mov    %ebx,0x8010ec70
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000b4:	81 fb c0 e9 10 80    	cmp    $0x8010e9c0,%ebx
801000ba:	75 c4                	jne    80100080 <binit+0x40>
  }
}
801000bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000bf:	c9                   	leave
801000c0:	c3                   	ret
801000c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801000c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801000cf:	00 

801000d0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000d0:	55                   	push   %ebp
801000d1:	89 e5                	mov    %esp,%ebp
801000d3:	57                   	push   %edi
801000d4:	56                   	push   %esi
801000d5:	53                   	push   %ebx
801000d6:	83 ec 18             	sub    $0x18,%esp
801000d9:	8b 75 08             	mov    0x8(%ebp),%esi
801000dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000df:	68 20 a5 10 80       	push   $0x8010a520
801000e4:	e8 97 47 00 00       	call   80104880 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000e9:	8b 1d 70 ec 10 80    	mov    0x8010ec70,%ebx
801000ef:	83 c4 10             	add    $0x10,%esp
801000f2:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
801000f8:	75 11                	jne    8010010b <bread+0x3b>
801000fa:	eb 24                	jmp    80100120 <bread+0x50>
801000fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100100:	8b 5b 54             	mov    0x54(%ebx),%ebx
80100103:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
80100109:	74 15                	je     80100120 <bread+0x50>
    if(b->dev == dev && b->blockno == blockno){
8010010b:	3b 73 04             	cmp    0x4(%ebx),%esi
8010010e:	75 f0                	jne    80100100 <bread+0x30>
80100110:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100113:	75 eb                	jne    80100100 <bread+0x30>
      b->refcnt++;
80100115:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100119:	eb 4f                	jmp    8010016a <bread+0x9a>
8010011b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100120:	8b 1d 6c ec 10 80    	mov    0x8010ec6c,%ebx
80100126:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
8010012c:	75 1d                	jne    8010014b <bread+0x7b>
8010012e:	eb 7e                	jmp    801001ae <bread+0xde>
80100130:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100137:	00 
80100138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010013f:	00 
80100140:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100143:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
80100149:	74 63                	je     801001ae <bread+0xde>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010014b:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010014e:	85 c0                	test   %eax,%eax
80100150:	75 ee                	jne    80100140 <bread+0x70>
80100152:	f6 03 04             	testb  $0x4,(%ebx)
80100155:	75 e9                	jne    80100140 <bread+0x70>
      b->dev = dev;
80100157:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010015a:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
8010015d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100163:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010016a:	83 ec 0c             	sub    $0xc,%esp
8010016d:	68 20 a5 10 80       	push   $0x8010a520
80100172:	e8 a9 46 00 00       	call   80104820 <release>
      acquiresleep(&b->lock);
80100177:	8d 43 0c             	lea    0xc(%ebx),%eax
8010017a:	89 04 24             	mov    %eax,(%esp)
8010017d:	e8 ee 43 00 00       	call   80104570 <acquiresleep>
      return b;
80100182:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100185:	f6 03 02             	testb  $0x2,(%ebx)
80100188:	74 0e                	je     80100198 <bread+0xc8>
    iderw(b);
  }
  return b;
}
8010018a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010018d:	89 d8                	mov    %ebx,%eax
8010018f:	5b                   	pop    %ebx
80100190:	5e                   	pop    %esi
80100191:	5f                   	pop    %edi
80100192:	5d                   	pop    %ebp
80100193:	c3                   	ret
80100194:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    iderw(b);
80100198:	83 ec 0c             	sub    $0xc,%esp
8010019b:	53                   	push   %ebx
8010019c:	e8 1f 22 00 00       	call   801023c0 <iderw>
801001a1:	83 c4 10             	add    $0x10,%esp
}
801001a4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801001a7:	89 d8                	mov    %ebx,%eax
801001a9:	5b                   	pop    %ebx
801001aa:	5e                   	pop    %esi
801001ab:	5f                   	pop    %edi
801001ac:	5d                   	pop    %ebp
801001ad:	c3                   	ret
  panic("bget: no buffers");
801001ae:	83 ec 0c             	sub    $0xc,%esp
801001b1:	68 ae 75 10 80       	push   $0x801075ae
801001b6:	e8 e5 01 00 00       	call   801003a0 <panic>
801001bb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801001c0 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
801001c0:	55                   	push   %ebp
801001c1:	89 e5                	mov    %esp,%ebp
801001c3:	53                   	push   %ebx
801001c4:	83 ec 10             	sub    $0x10,%esp
801001c7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001ca:	8d 43 0c             	lea    0xc(%ebx),%eax
801001cd:	50                   	push   %eax
801001ce:	e8 3d 44 00 00       	call   80104610 <holdingsleep>
801001d3:	83 c4 10             	add    $0x10,%esp
801001d6:	85 c0                	test   %eax,%eax
801001d8:	74 0f                	je     801001e9 <bwrite+0x29>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001da:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001dd:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801001e0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001e3:	c9                   	leave
  iderw(b);
801001e4:	e9 d7 21 00 00       	jmp    801023c0 <iderw>
    panic("bwrite");
801001e9:	83 ec 0c             	sub    $0xc,%esp
801001ec:	68 bf 75 10 80       	push   $0x801075bf
801001f1:	e8 aa 01 00 00       	call   801003a0 <panic>
801001f6:	66 90                	xchg   %ax,%ax
801001f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801001ff:	00 

80100200 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
80100200:	55                   	push   %ebp
80100201:	89 e5                	mov    %esp,%ebp
80100203:	56                   	push   %esi
80100204:	53                   	push   %ebx
80100205:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
80100208:	8d 73 0c             	lea    0xc(%ebx),%esi
8010020b:	83 ec 0c             	sub    $0xc,%esp
8010020e:	56                   	push   %esi
8010020f:	e8 fc 43 00 00       	call   80104610 <holdingsleep>
80100214:	83 c4 10             	add    $0x10,%esp
80100217:	85 c0                	test   %eax,%eax
80100219:	74 63                	je     8010027e <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
8010021b:	83 ec 0c             	sub    $0xc,%esp
8010021e:	56                   	push   %esi
8010021f:	e8 ac 43 00 00       	call   801045d0 <releasesleep>

  acquire(&bcache.lock);
80100224:	c7 04 24 20 a5 10 80 	movl   $0x8010a520,(%esp)
8010022b:	e8 50 46 00 00       	call   80104880 <acquire>
  b->refcnt--;
80100230:	8b 43 4c             	mov    0x4c(%ebx),%eax
  if (b->refcnt == 0) {
80100233:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
80100236:	83 e8 01             	sub    $0x1,%eax
80100239:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
8010023c:	85 c0                	test   %eax,%eax
8010023e:	75 2c                	jne    8010026c <brelse+0x6c>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100240:	8b 53 54             	mov    0x54(%ebx),%edx
80100243:	8b 43 50             	mov    0x50(%ebx),%eax
80100246:	89 42 50             	mov    %eax,0x50(%edx)
    b->prev->next = b->next;
80100249:	8b 53 54             	mov    0x54(%ebx),%edx
8010024c:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
8010024f:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
    b->prev = &bcache.head;
80100254:	c7 43 50 1c ec 10 80 	movl   $0x8010ec1c,0x50(%ebx)
    b->next = bcache.head.next;
8010025b:	89 43 54             	mov    %eax,0x54(%ebx)
    bcache.head.next->prev = b;
8010025e:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
80100263:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
80100266:	89 1d 70 ec 10 80    	mov    %ebx,0x8010ec70
  }
  
  release(&bcache.lock);
8010026c:	c7 45 08 20 a5 10 80 	movl   $0x8010a520,0x8(%ebp)
}
80100273:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100276:	5b                   	pop    %ebx
80100277:	5e                   	pop    %esi
80100278:	5d                   	pop    %ebp
  release(&bcache.lock);
80100279:	e9 a2 45 00 00       	jmp    80104820 <release>
    panic("brelse");
8010027e:	83 ec 0c             	sub    $0xc,%esp
80100281:	68 c6 75 10 80       	push   $0x801075c6
80100286:	e8 15 01 00 00       	call   801003a0 <panic>
8010028b:	66 90                	xchg   %ax,%ax
8010028d:	66 90                	xchg   %ax,%ax
8010028f:	66 90                	xchg   %ax,%ax
80100291:	66 90                	xchg   %ax,%ax
80100293:	66 90                	xchg   %ax,%ax
80100295:	66 90                	xchg   %ax,%ax
80100297:	66 90                	xchg   %ax,%ax
80100299:	66 90                	xchg   %ax,%ax
8010029b:	66 90                	xchg   %ax,%ax
8010029d:	66 90                	xchg   %ax,%ax
8010029f:	90                   	nop

801002a0 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
801002a0:	55                   	push   %ebp
801002a1:	89 e5                	mov    %esp,%ebp
801002a3:	57                   	push   %edi
801002a4:	56                   	push   %esi
801002a5:	53                   	push   %ebx
801002a6:	83 ec 18             	sub    $0x18,%esp
801002a9:	8b 5d 10             	mov    0x10(%ebp),%ebx
801002ac:	8b 75 0c             	mov    0xc(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
801002af:	ff 75 08             	push   0x8(%ebp)
  target = n;
801002b2:	89 df                	mov    %ebx,%edi
  iunlock(ip);
801002b4:	e8 97 16 00 00       	call   80101950 <iunlock>
  acquire(&cons.lock);
801002b9:	c7 04 24 20 ef 10 80 	movl   $0x8010ef20,(%esp)
801002c0:	e8 bb 45 00 00       	call   80104880 <acquire>
  while(n > 0){
801002c5:	83 c4 10             	add    $0x10,%esp
801002c8:	85 db                	test   %ebx,%ebx
801002ca:	0f 8e 94 00 00 00    	jle    80100364 <consoleread+0xc4>
    while(input.r == input.w){
801002d0:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
801002d5:	39 05 04 ef 10 80    	cmp    %eax,0x8010ef04
801002db:	74 25                	je     80100302 <consoleread+0x62>
801002dd:	eb 59                	jmp    80100338 <consoleread+0x98>
801002df:	90                   	nop
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
801002e0:	83 ec 08             	sub    $0x8,%esp
801002e3:	68 20 ef 10 80       	push   $0x8010ef20
801002e8:	68 00 ef 10 80       	push   $0x8010ef00
801002ed:	e8 ce 3f 00 00       	call   801042c0 <sleep>
    while(input.r == input.w){
801002f2:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
801002f7:	83 c4 10             	add    $0x10,%esp
801002fa:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
80100300:	75 36                	jne    80100338 <consoleread+0x98>
      if(myproc()->killed){
80100302:	e8 d9 38 00 00       	call   80103be0 <myproc>
80100307:	8b 48 24             	mov    0x24(%eax),%ecx
8010030a:	85 c9                	test   %ecx,%ecx
8010030c:	74 d2                	je     801002e0 <consoleread+0x40>
        release(&cons.lock);
8010030e:	83 ec 0c             	sub    $0xc,%esp
80100311:	68 20 ef 10 80       	push   $0x8010ef20
80100316:	e8 05 45 00 00       	call   80104820 <release>
        ilock(ip);
8010031b:	5a                   	pop    %edx
8010031c:	ff 75 08             	push   0x8(%ebp)
8010031f:	e8 4c 15 00 00       	call   80101870 <ilock>
        return -1;
80100324:	83 c4 10             	add    $0x10,%esp
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}
80100327:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return -1;
8010032a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010032f:	5b                   	pop    %ebx
80100330:	5e                   	pop    %esi
80100331:	5f                   	pop    %edi
80100332:	5d                   	pop    %ebp
80100333:	c3                   	ret
80100334:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = input.buf[input.r++ % INPUT_BUF];
80100338:	8d 50 01             	lea    0x1(%eax),%edx
8010033b:	89 15 00 ef 10 80    	mov    %edx,0x8010ef00
80100341:	89 c2                	mov    %eax,%edx
80100343:	83 e2 7f             	and    $0x7f,%edx
80100346:	0f be 8a 80 ee 10 80 	movsbl -0x7fef1180(%edx),%ecx
    if(c == C('D')){  // EOF
8010034d:	80 f9 04             	cmp    $0x4,%cl
80100350:	74 37                	je     80100389 <consoleread+0xe9>
    *dst++ = c;
80100352:	83 c6 01             	add    $0x1,%esi
    --n;
80100355:	83 eb 01             	sub    $0x1,%ebx
    *dst++ = c;
80100358:	88 4e ff             	mov    %cl,-0x1(%esi)
    if(c == '\n')
8010035b:	83 f9 0a             	cmp    $0xa,%ecx
8010035e:	0f 85 64 ff ff ff    	jne    801002c8 <consoleread+0x28>
  release(&cons.lock);
80100364:	83 ec 0c             	sub    $0xc,%esp
80100367:	68 20 ef 10 80       	push   $0x8010ef20
8010036c:	e8 af 44 00 00       	call   80104820 <release>
  ilock(ip);
80100371:	58                   	pop    %eax
80100372:	ff 75 08             	push   0x8(%ebp)
80100375:	e8 f6 14 00 00       	call   80101870 <ilock>
  return target - n;
8010037a:	89 f8                	mov    %edi,%eax
8010037c:	83 c4 10             	add    $0x10,%esp
}
8010037f:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return target - n;
80100382:	29 d8                	sub    %ebx,%eax
}
80100384:	5b                   	pop    %ebx
80100385:	5e                   	pop    %esi
80100386:	5f                   	pop    %edi
80100387:	5d                   	pop    %ebp
80100388:	c3                   	ret
      if(n < target){
80100389:	39 fb                	cmp    %edi,%ebx
8010038b:	73 d7                	jae    80100364 <consoleread+0xc4>
        input.r--;
8010038d:	a3 00 ef 10 80       	mov    %eax,0x8010ef00
80100392:	eb d0                	jmp    80100364 <consoleread+0xc4>
80100394:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100398:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010039f:	00 

801003a0 <panic>:
{
801003a0:	55                   	push   %ebp
801003a1:	89 e5                	mov    %esp,%ebp
801003a3:	53                   	push   %ebx
801003a4:	83 ec 34             	sub    $0x34,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
801003a7:	fa                   	cli
  cons.locking = 0;
801003a8:	c7 05 54 ef 10 80 00 	movl   $0x0,0x8010ef54
801003af:	00 00 00 
  getcallerpcs(&s, pcs);
801003b2:	8d 5d d0             	lea    -0x30(%ebp),%ebx
  cprintf("lapicid %d: panic: ", lapicid());
801003b5:	e8 c6 26 00 00       	call   80102a80 <lapicid>
801003ba:	83 ec 08             	sub    $0x8,%esp
801003bd:	50                   	push   %eax
801003be:	68 cd 75 10 80       	push   $0x801075cd
801003c3:	e8 08 03 00 00       	call   801006d0 <cprintf>
  cprintf(s);
801003c8:	58                   	pop    %eax
801003c9:	ff 75 08             	push   0x8(%ebp)
801003cc:	e8 ff 02 00 00       	call   801006d0 <cprintf>
  cprintf("\n");
801003d1:	c7 04 24 4f 7a 10 80 	movl   $0x80107a4f,(%esp)
801003d8:	e8 f3 02 00 00       	call   801006d0 <cprintf>
  getcallerpcs(&s, pcs);
801003dd:	8d 45 08             	lea    0x8(%ebp),%eax
801003e0:	5a                   	pop    %edx
801003e1:	59                   	pop    %ecx
801003e2:	53                   	push   %ebx
801003e3:	50                   	push   %eax
801003e4:	e8 97 42 00 00       	call   80104680 <getcallerpcs>
  for(i=0; i<10; i++)
801003e9:	83 c4 10             	add    $0x10,%esp
801003ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf(" %p", pcs[i]);
801003f0:	83 ec 08             	sub    $0x8,%esp
801003f3:	ff 33                	push   (%ebx)
  for(i=0; i<10; i++)
801003f5:	83 c3 04             	add    $0x4,%ebx
    cprintf(" %p", pcs[i]);
801003f8:	68 e1 75 10 80       	push   $0x801075e1
801003fd:	e8 ce 02 00 00       	call   801006d0 <cprintf>
  for(i=0; i<10; i++)
80100402:	8d 45 f8             	lea    -0x8(%ebp),%eax
80100405:	83 c4 10             	add    $0x10,%esp
80100408:	39 c3                	cmp    %eax,%ebx
8010040a:	75 e4                	jne    801003f0 <panic+0x50>
  panicked = 1; // freeze other CPU
8010040c:	c7 05 58 ef 10 80 01 	movl   $0x1,0x8010ef58
80100413:	00 00 00 
  for(;;)
80100416:	eb fe                	jmp    80100416 <panic+0x76>
80100418:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010041f:	00 

80100420 <consputc.part.0>:
consputc(int c)
80100420:	55                   	push   %ebp
80100421:	89 e5                	mov    %esp,%ebp
80100423:	57                   	push   %edi
80100424:	56                   	push   %esi
80100425:	53                   	push   %ebx
80100426:	83 ec 0c             	sub    $0xc,%esp
  if(c == BACKSPACE){
80100429:	3d 00 01 00 00       	cmp    $0x100,%eax
8010042e:	0f 84 cc 00 00 00    	je     80100500 <consputc.part.0+0xe0>
    uartputc(c);
80100434:	83 ec 0c             	sub    $0xc,%esp
80100437:	89 c3                	mov    %eax,%ebx
80100439:	50                   	push   %eax
8010043a:	e8 61 5c 00 00       	call   801060a0 <uartputc>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010043f:	b8 0e 00 00 00       	mov    $0xe,%eax
80100444:	ba d4 03 00 00       	mov    $0x3d4,%edx
80100449:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010044a:	ba d5 03 00 00       	mov    $0x3d5,%edx
8010044f:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100450:	0f b6 c8             	movzbl %al,%ecx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100453:	ba d4 03 00 00       	mov    $0x3d4,%edx
80100458:	b8 0f 00 00 00       	mov    $0xf,%eax
8010045d:	c1 e1 08             	shl    $0x8,%ecx
80100460:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100461:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100466:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
80100467:	0f b6 c0             	movzbl %al,%eax
  if(c == '\n')
8010046a:	83 c4 10             	add    $0x10,%esp
  pos |= inb(CRTPORT+1);
8010046d:	09 c8                	or     %ecx,%eax
  if(c == '\n')
8010046f:	83 fb 0a             	cmp    $0xa,%ebx
80100472:	75 74                	jne    801004e8 <consputc.part.0+0xc8>
    pos += 80 - pos%80;
80100474:	ba cd cc cc cc       	mov    $0xcccccccd,%edx
80100479:	f7 e2                	mul    %edx
8010047b:	c1 ea 06             	shr    $0x6,%edx
8010047e:	8d 04 92             	lea    (%edx,%edx,4),%eax
80100481:	c1 e0 04             	shl    $0x4,%eax
80100484:	8d 78 50             	lea    0x50(%eax),%edi
  if(pos < 0 || pos > 25*80)
80100487:	81 ff d0 07 00 00    	cmp    $0x7d0,%edi
8010048d:	0f 8f 23 01 00 00    	jg     801005b6 <consputc.part.0+0x196>
  if((pos/80) >= 24){  // Scroll up.
80100493:	81 ff 7f 07 00 00    	cmp    $0x77f,%edi
80100499:	0f 8f c1 00 00 00    	jg     80100560 <consputc.part.0+0x140>
  outb(CRTPORT+1, pos>>8);
8010049f:	89 f8                	mov    %edi,%eax
  outb(CRTPORT+1, pos);
801004a1:	89 fb                	mov    %edi,%ebx
  crt[pos] = ' ' | 0x0700;
801004a3:	8d bc 3f 00 80 0b 80 	lea    -0x7ff48000(%edi,%edi,1),%edi
  outb(CRTPORT+1, pos>>8);
801004aa:	0f b6 f4             	movzbl %ah,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801004ad:	b8 0e 00 00 00       	mov    $0xe,%eax
801004b2:	ba d4 03 00 00       	mov    $0x3d4,%edx
801004b7:	ee                   	out    %al,(%dx)
801004b8:	ba d5 03 00 00       	mov    $0x3d5,%edx
801004bd:	89 f0                	mov    %esi,%eax
801004bf:	ee                   	out    %al,(%dx)
801004c0:	b8 0f 00 00 00       	mov    $0xf,%eax
801004c5:	ba d4 03 00 00       	mov    $0x3d4,%edx
801004ca:	ee                   	out    %al,(%dx)
801004cb:	ba d5 03 00 00       	mov    $0x3d5,%edx
801004d0:	89 d8                	mov    %ebx,%eax
801004d2:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004d3:	b8 20 07 00 00       	mov    $0x720,%eax
801004d8:	66 89 07             	mov    %ax,(%edi)
}
801004db:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004de:	5b                   	pop    %ebx
801004df:	5e                   	pop    %esi
801004e0:	5f                   	pop    %edi
801004e1:	5d                   	pop    %ebp
801004e2:	c3                   	ret
801004e3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
801004e8:	0f b6 db             	movzbl %bl,%ebx
801004eb:	8d 78 01             	lea    0x1(%eax),%edi
801004ee:	80 cf 07             	or     $0x7,%bh
801004f1:	66 89 9c 00 00 80 0b 	mov    %bx,-0x7ff48000(%eax,%eax,1)
801004f8:	80 
801004f9:	eb 8c                	jmp    80100487 <consputc.part.0+0x67>
801004fb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    uartputc('\b'); uartputc(' '); uartputc('\b');
80100500:	83 ec 0c             	sub    $0xc,%esp
80100503:	6a 08                	push   $0x8
80100505:	e8 96 5b 00 00       	call   801060a0 <uartputc>
8010050a:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
80100511:	e8 8a 5b 00 00       	call   801060a0 <uartputc>
80100516:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
8010051d:	e8 7e 5b 00 00       	call   801060a0 <uartputc>
80100522:	b8 0e 00 00 00       	mov    $0xe,%eax
80100527:	ba d4 03 00 00       	mov    $0x3d4,%edx
8010052c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010052d:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100532:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100533:	0f b6 d8             	movzbl %al,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100536:	ba d4 03 00 00       	mov    $0x3d4,%edx
8010053b:	b8 0f 00 00 00       	mov    $0xf,%eax
80100540:	c1 e3 08             	shl    $0x8,%ebx
80100543:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100544:	ba d5 03 00 00       	mov    $0x3d5,%edx
80100549:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
8010054a:	0f b6 c8             	movzbl %al,%ecx
    if(pos > 0) --pos;
8010054d:	83 c4 10             	add    $0x10,%esp
80100550:	09 d9                	or     %ebx,%ecx
80100552:	74 54                	je     801005a8 <consputc.part.0+0x188>
80100554:	8d 79 ff             	lea    -0x1(%ecx),%edi
80100557:	e9 2b ff ff ff       	jmp    80100487 <consputc.part.0+0x67>
8010055c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100560:	83 ec 04             	sub    $0x4,%esp
    pos -= 80;
80100563:	8d 5f b0             	lea    -0x50(%edi),%ebx
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100566:	8d bc 3f 60 7f 0b 80 	lea    -0x7ff480a0(%edi,%edi,1),%edi
  outb(CRTPORT+1, pos);
8010056d:	be 07 00 00 00       	mov    $0x7,%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100572:	68 60 0e 00 00       	push   $0xe60
80100577:	68 a0 80 0b 80       	push   $0x800b80a0
8010057c:	68 00 80 0b 80       	push   $0x800b8000
80100581:	e8 aa 44 00 00       	call   80104a30 <memmove>
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100586:	b8 80 07 00 00       	mov    $0x780,%eax
8010058b:	83 c4 0c             	add    $0xc,%esp
8010058e:	29 d8                	sub    %ebx,%eax
80100590:	01 c0                	add    %eax,%eax
80100592:	50                   	push   %eax
80100593:	6a 00                	push   $0x0
80100595:	57                   	push   %edi
80100596:	e8 05 44 00 00       	call   801049a0 <memset>
  outb(CRTPORT+1, pos);
8010059b:	83 c4 10             	add    $0x10,%esp
8010059e:	e9 0a ff ff ff       	jmp    801004ad <consputc.part.0+0x8d>
801005a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801005a8:	bf 00 80 0b 80       	mov    $0x800b8000,%edi
801005ad:	31 db                	xor    %ebx,%ebx
801005af:	31 f6                	xor    %esi,%esi
801005b1:	e9 f7 fe ff ff       	jmp    801004ad <consputc.part.0+0x8d>
    panic("pos under/overflow");
801005b6:	83 ec 0c             	sub    $0xc,%esp
801005b9:	68 e5 75 10 80       	push   $0x801075e5
801005be:	e8 dd fd ff ff       	call   801003a0 <panic>
801005c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801005c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801005cf:	00 

801005d0 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
801005d0:	55                   	push   %ebp
801005d1:	89 e5                	mov    %esp,%ebp
801005d3:	57                   	push   %edi
801005d4:	56                   	push   %esi
801005d5:	53                   	push   %ebx
801005d6:	83 ec 18             	sub    $0x18,%esp
801005d9:	8b 75 10             	mov    0x10(%ebp),%esi
  int i;

  iunlock(ip);
801005dc:	ff 75 08             	push   0x8(%ebp)
801005df:	e8 6c 13 00 00       	call   80101950 <iunlock>
  acquire(&cons.lock);
801005e4:	c7 04 24 20 ef 10 80 	movl   $0x8010ef20,(%esp)
801005eb:	e8 90 42 00 00       	call   80104880 <acquire>
  for(i = 0; i < n; i++)
801005f0:	83 c4 10             	add    $0x10,%esp
801005f3:	85 f6                	test   %esi,%esi
801005f5:	7e 28                	jle    8010061f <consolewrite+0x4f>
801005f7:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801005fa:	8d 3c 33             	lea    (%ebx,%esi,1),%edi
  if(panicked){
801005fd:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
80100603:	85 d2                	test   %edx,%edx
80100605:	74 09                	je     80100610 <consolewrite+0x40>
  asm volatile("cli");
80100607:	fa                   	cli
    for(;;)
80100608:	eb fe                	jmp    80100608 <consolewrite+0x38>
8010060a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    consputc(buf[i] & 0xff);
80100610:	0f b6 03             	movzbl (%ebx),%eax
  for(i = 0; i < n; i++)
80100613:	83 c3 01             	add    $0x1,%ebx
80100616:	e8 05 fe ff ff       	call   80100420 <consputc.part.0>
8010061b:	39 fb                	cmp    %edi,%ebx
8010061d:	75 de                	jne    801005fd <consolewrite+0x2d>
  release(&cons.lock);
8010061f:	83 ec 0c             	sub    $0xc,%esp
80100622:	68 20 ef 10 80       	push   $0x8010ef20
80100627:	e8 f4 41 00 00       	call   80104820 <release>
  ilock(ip);
8010062c:	58                   	pop    %eax
8010062d:	ff 75 08             	push   0x8(%ebp)
80100630:	e8 3b 12 00 00       	call   80101870 <ilock>

  return n;
}
80100635:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100638:	89 f0                	mov    %esi,%eax
8010063a:	5b                   	pop    %ebx
8010063b:	5e                   	pop    %esi
8010063c:	5f                   	pop    %edi
8010063d:	5d                   	pop    %ebp
8010063e:	c3                   	ret
8010063f:	90                   	nop

80100640 <printint>:
{
80100640:	55                   	push   %ebp
80100641:	89 e5                	mov    %esp,%ebp
80100643:	57                   	push   %edi
80100644:	56                   	push   %esi
80100645:	53                   	push   %ebx
80100646:	89 d3                	mov    %edx,%ebx
80100648:	83 ec 2c             	sub    $0x2c,%esp
  if(sign && (sign = xx < 0))
8010064b:	85 c0                	test   %eax,%eax
8010064d:	79 05                	jns    80100654 <printint+0x14>
8010064f:	83 e1 01             	and    $0x1,%ecx
80100652:	75 5d                	jne    801006b1 <printint+0x71>
80100654:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
8010065b:	89 c1                	mov    %eax,%ecx
  i = 0;
8010065d:	31 f6                	xor    %esi,%esi
8010065f:	90                   	nop
    buf[i++] = digits[x % base];
80100660:	89 c8                	mov    %ecx,%eax
80100662:	31 d2                	xor    %edx,%edx
80100664:	89 f7                	mov    %esi,%edi
80100666:	f7 f3                	div    %ebx
80100668:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
8010066b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
8010066d:	0f b6 92 a0 7a 10 80 	movzbl -0x7fef8560(%edx),%edx
  }while((x /= base) != 0);
80100674:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
80100676:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
8010067a:	73 e4                	jae    80100660 <printint+0x20>
  if(sign)
8010067c:	8b 55 d4             	mov    -0x2c(%ebp),%edx
8010067f:	85 d2                	test   %edx,%edx
80100681:	74 07                	je     8010068a <printint+0x4a>
    buf[i++] = '-';
80100683:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
80100688:	89 f7                	mov    %esi,%edi
  while(--i >= 0)
8010068a:	8d 5d d8             	lea    -0x28(%ebp),%ebx
8010068d:	01 df                	add    %ebx,%edi
  if(panicked){
8010068f:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
80100694:	85 c0                	test   %eax,%eax
80100696:	74 08                	je     801006a0 <printint+0x60>
80100698:	fa                   	cli
    for(;;)
80100699:	eb fe                	jmp    80100699 <printint+0x59>
8010069b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    consputc(buf[i]);
801006a0:	0f be 07             	movsbl (%edi),%eax
801006a3:	e8 78 fd ff ff       	call   80100420 <consputc.part.0>
  while(--i >= 0)
801006a8:	39 fb                	cmp    %edi,%ebx
801006aa:	74 10                	je     801006bc <printint+0x7c>
801006ac:	83 ef 01             	sub    $0x1,%edi
801006af:	eb de                	jmp    8010068f <printint+0x4f>
  if(sign && (sign = xx < 0))
801006b1:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
    x = -xx;
801006b8:	f7 d8                	neg    %eax
801006ba:	eb 9f                	jmp    8010065b <printint+0x1b>
}
801006bc:	83 c4 2c             	add    $0x2c,%esp
801006bf:	5b                   	pop    %ebx
801006c0:	5e                   	pop    %esi
801006c1:	5f                   	pop    %edi
801006c2:	5d                   	pop    %ebp
801006c3:	c3                   	ret
801006c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801006c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801006cf:	00 

801006d0 <cprintf>:
{
801006d0:	55                   	push   %ebp
801006d1:	89 e5                	mov    %esp,%ebp
801006d3:	57                   	push   %edi
801006d4:	56                   	push   %esi
801006d5:	53                   	push   %ebx
801006d6:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking;
801006d9:	8b 15 54 ef 10 80    	mov    0x8010ef54,%edx
  if (fmt == 0)
801006df:	8b 75 08             	mov    0x8(%ebp),%esi
  if(locking)
801006e2:	85 d2                	test   %edx,%edx
801006e4:	0f 85 06 01 00 00    	jne    801007f0 <cprintf+0x120>
  if (fmt == 0)
801006ea:	85 f6                	test   %esi,%esi
801006ec:	0f 84 c2 01 00 00    	je     801008b4 <cprintf+0x1e4>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006f2:	0f b6 06             	movzbl (%esi),%eax
801006f5:	85 c0                	test   %eax,%eax
801006f7:	74 57                	je     80100750 <cprintf+0x80>
801006f9:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  argp = (uint*)(void*)(&fmt + 1);
801006fc:	8d 7d 0c             	lea    0xc(%ebp),%edi
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006ff:	31 db                	xor    %ebx,%ebx
    if(c != '%'){
80100701:	83 f8 25             	cmp    $0x25,%eax
80100704:	75 5a                	jne    80100760 <cprintf+0x90>
    c = fmt[++i] & 0xff;
80100706:	83 c3 01             	add    $0x1,%ebx
80100709:	0f b6 14 1e          	movzbl (%esi,%ebx,1),%edx
    if(c == 0)
8010070d:	85 d2                	test   %edx,%edx
8010070f:	74 34                	je     80100745 <cprintf+0x75>
    switch(c){
80100711:	83 fa 70             	cmp    $0x70,%edx
80100714:	0f 84 b6 00 00 00    	je     801007d0 <cprintf+0x100>
8010071a:	7f 74                	jg     80100790 <cprintf+0xc0>
8010071c:	83 fa 25             	cmp    $0x25,%edx
8010071f:	74 4f                	je     80100770 <cprintf+0xa0>
80100721:	83 fa 64             	cmp    $0x64,%edx
80100724:	75 78                	jne    8010079e <cprintf+0xce>
      printint(*argp++, 10, 1);
80100726:	8b 07                	mov    (%edi),%eax
80100728:	b9 01 00 00 00       	mov    $0x1,%ecx
8010072d:	ba 0a 00 00 00       	mov    $0xa,%edx
80100732:	83 c7 04             	add    $0x4,%edi
80100735:	e8 06 ff ff ff       	call   80100640 <printint>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
8010073a:	83 c3 01             	add    $0x1,%ebx
8010073d:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
80100741:	85 c0                	test   %eax,%eax
80100743:	75 bc                	jne    80100701 <cprintf+0x31>
80100745:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  if(locking)
80100748:	85 d2                	test   %edx,%edx
8010074a:	0f 85 c9 00 00 00    	jne    80100819 <cprintf+0x149>
}
80100750:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100753:	5b                   	pop    %ebx
80100754:	5e                   	pop    %esi
80100755:	5f                   	pop    %edi
80100756:	5d                   	pop    %ebp
80100757:	c3                   	ret
80100758:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010075f:	00 
  if(panicked){
80100760:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
80100766:	85 c9                	test   %ecx,%ecx
80100768:	74 18                	je     80100782 <cprintf+0xb2>
8010076a:	fa                   	cli
    for(;;)
8010076b:	eb fe                	jmp    8010076b <cprintf+0x9b>
8010076d:	8d 76 00             	lea    0x0(%esi),%esi
  if(panicked){
80100770:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
80100775:	85 c0                	test   %eax,%eax
80100777:	0f 85 1b 01 00 00    	jne    80100898 <cprintf+0x1c8>
8010077d:	b8 25 00 00 00       	mov    $0x25,%eax
80100782:	e8 99 fc ff ff       	call   80100420 <consputc.part.0>
      break;
80100787:	eb b1                	jmp    8010073a <cprintf+0x6a>
80100789:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    switch(c){
80100790:	83 fa 73             	cmp    $0x73,%edx
80100793:	0f 84 95 00 00 00    	je     8010082e <cprintf+0x15e>
80100799:	83 fa 78             	cmp    $0x78,%edx
8010079c:	74 32                	je     801007d0 <cprintf+0x100>
  if(panicked){
8010079e:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
801007a4:	85 c9                	test   %ecx,%ecx
801007a6:	0f 85 e5 00 00 00    	jne    80100891 <cprintf+0x1c1>
801007ac:	b8 25 00 00 00       	mov    $0x25,%eax
801007b1:	89 55 e0             	mov    %edx,-0x20(%ebp)
801007b4:	e8 67 fc ff ff       	call   80100420 <consputc.part.0>
801007b9:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
801007be:	85 c0                	test   %eax,%eax
801007c0:	0f 84 da 00 00 00    	je     801008a0 <cprintf+0x1d0>
801007c6:	fa                   	cli
    for(;;)
801007c7:	eb fe                	jmp    801007c7 <cprintf+0xf7>
801007c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      printint(*argp++, 16, 0);
801007d0:	8b 07                	mov    (%edi),%eax
801007d2:	31 c9                	xor    %ecx,%ecx
801007d4:	ba 10 00 00 00       	mov    $0x10,%edx
801007d9:	83 c7 04             	add    $0x4,%edi
801007dc:	e8 5f fe ff ff       	call   80100640 <printint>
      break;
801007e1:	e9 54 ff ff ff       	jmp    8010073a <cprintf+0x6a>
801007e6:	66 90                	xchg   %ax,%ax
801007e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801007ef:	00 
    acquire(&cons.lock);
801007f0:	83 ec 0c             	sub    $0xc,%esp
801007f3:	89 55 e4             	mov    %edx,-0x1c(%ebp)
801007f6:	68 20 ef 10 80       	push   $0x8010ef20
801007fb:	e8 80 40 00 00       	call   80104880 <acquire>
  if (fmt == 0)
80100800:	83 c4 10             	add    $0x10,%esp
80100803:	85 f6                	test   %esi,%esi
80100805:	0f 84 a9 00 00 00    	je     801008b4 <cprintf+0x1e4>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
8010080b:	0f b6 06             	movzbl (%esi),%eax
8010080e:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80100811:	85 c0                	test   %eax,%eax
80100813:	0f 85 e0 fe ff ff    	jne    801006f9 <cprintf+0x29>
    release(&cons.lock);
80100819:	83 ec 0c             	sub    $0xc,%esp
8010081c:	68 20 ef 10 80       	push   $0x8010ef20
80100821:	e8 fa 3f 00 00       	call   80104820 <release>
80100826:	83 c4 10             	add    $0x10,%esp
80100829:	e9 22 ff ff ff       	jmp    80100750 <cprintf+0x80>
      if((s = (char*)*argp++) == 0)
8010082e:	8d 57 04             	lea    0x4(%edi),%edx
80100831:	8b 3f                	mov    (%edi),%edi
80100833:	85 ff                	test   %edi,%edi
80100835:	74 21                	je     80100858 <cprintf+0x188>
      for(; *s; s++)
80100837:	0f be 07             	movsbl (%edi),%eax
8010083a:	84 c0                	test   %al,%al
8010083c:	74 6f                	je     801008ad <cprintf+0x1dd>
8010083e:	89 5d e0             	mov    %ebx,-0x20(%ebp)
80100841:	89 fb                	mov    %edi,%ebx
80100843:	89 f7                	mov    %esi,%edi
80100845:	89 d6                	mov    %edx,%esi
  if(panicked){
80100847:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
8010084d:	85 d2                	test   %edx,%edx
8010084f:	74 22                	je     80100873 <cprintf+0x1a3>
80100851:	fa                   	cli
    for(;;)
80100852:	eb fe                	jmp    80100852 <cprintf+0x182>
80100854:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        s = "(null)";
80100858:	89 f7                	mov    %esi,%edi
8010085a:	89 d6                	mov    %edx,%esi
  if(panicked){
8010085c:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
        s = "(null)";
80100862:	89 5d e0             	mov    %ebx,-0x20(%ebp)
80100865:	b8 28 00 00 00       	mov    $0x28,%eax
8010086a:	bb f8 75 10 80       	mov    $0x801075f8,%ebx
  if(panicked){
8010086f:	85 d2                	test   %edx,%edx
80100871:	75 de                	jne    80100851 <cprintf+0x181>
80100873:	e8 a8 fb ff ff       	call   80100420 <consputc.part.0>
      for(; *s; s++)
80100878:	0f be 43 01          	movsbl 0x1(%ebx),%eax
8010087c:	83 c3 01             	add    $0x1,%ebx
8010087f:	84 c0                	test   %al,%al
80100881:	75 c4                	jne    80100847 <cprintf+0x177>
      if((s = (char*)*argp++) == 0)
80100883:	89 f2                	mov    %esi,%edx
80100885:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80100888:	89 fe                	mov    %edi,%esi
8010088a:	89 d7                	mov    %edx,%edi
8010088c:	e9 a9 fe ff ff       	jmp    8010073a <cprintf+0x6a>
80100891:	fa                   	cli
    for(;;)
80100892:	eb fe                	jmp    80100892 <cprintf+0x1c2>
80100894:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100898:	fa                   	cli
80100899:	eb fe                	jmp    80100899 <cprintf+0x1c9>
8010089b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801008a0:	8b 45 e0             	mov    -0x20(%ebp),%eax
801008a3:	e8 78 fb ff ff       	call   80100420 <consputc.part.0>
      break;
801008a8:	e9 8d fe ff ff       	jmp    8010073a <cprintf+0x6a>
      if((s = (char*)*argp++) == 0)
801008ad:	89 d7                	mov    %edx,%edi
801008af:	e9 86 fe ff ff       	jmp    8010073a <cprintf+0x6a>
    panic("null fmt");
801008b4:	83 ec 0c             	sub    $0xc,%esp
801008b7:	68 ff 75 10 80       	push   $0x801075ff
801008bc:	e8 df fa ff ff       	call   801003a0 <panic>
801008c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801008c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801008cf:	00 

801008d0 <consoleintr>:
{
801008d0:	55                   	push   %ebp
801008d1:	89 e5                	mov    %esp,%ebp
801008d3:	57                   	push   %edi
801008d4:	56                   	push   %esi
  int c, doprocdump = 0;
801008d5:	31 f6                	xor    %esi,%esi
{
801008d7:	53                   	push   %ebx
801008d8:	83 ec 28             	sub    $0x28,%esp
801008db:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&cons.lock);
801008de:	68 20 ef 10 80       	push   $0x8010ef20
801008e3:	e8 98 3f 00 00       	call   80104880 <acquire>
  while((c = getc()) >= 0){
801008e8:	83 c4 10             	add    $0x10,%esp
801008eb:	ff d3                	call   *%ebx
801008ed:	85 c0                	test   %eax,%eax
801008ef:	78 20                	js     80100911 <consoleintr+0x41>
    switch(c){
801008f1:	83 f8 15             	cmp    $0x15,%eax
801008f4:	74 42                	je     80100938 <consoleintr+0x68>
801008f6:	7f 78                	jg     80100970 <consoleintr+0xa0>
801008f8:	83 f8 08             	cmp    $0x8,%eax
801008fb:	74 78                	je     80100975 <consoleintr+0xa5>
801008fd:	83 f8 10             	cmp    $0x10,%eax
80100900:	0f 85 37 01 00 00    	jne    80100a3d <consoleintr+0x16d>
80100906:	be 01 00 00 00       	mov    $0x1,%esi
  while((c = getc()) >= 0){
8010090b:	ff d3                	call   *%ebx
8010090d:	85 c0                	test   %eax,%eax
8010090f:	79 e0                	jns    801008f1 <consoleintr+0x21>
  release(&cons.lock);
80100911:	83 ec 0c             	sub    $0xc,%esp
80100914:	68 20 ef 10 80       	push   $0x8010ef20
80100919:	e8 02 3f 00 00       	call   80104820 <release>
  if(doprocdump) {
8010091e:	83 c4 10             	add    $0x10,%esp
80100921:	85 f6                	test   %esi,%esi
80100923:	0f 85 7a 01 00 00    	jne    80100aa3 <consoleintr+0x1d3>
}
80100929:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010092c:	5b                   	pop    %ebx
8010092d:	5e                   	pop    %esi
8010092e:	5f                   	pop    %edi
8010092f:	5d                   	pop    %ebp
80100930:	c3                   	ret
80100931:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      while(input.e != input.w &&
80100938:	a1 08 ef 10 80       	mov    0x8010ef08,%eax
8010093d:	39 05 04 ef 10 80    	cmp    %eax,0x8010ef04
80100943:	74 a6                	je     801008eb <consoleintr+0x1b>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
80100945:	83 e8 01             	sub    $0x1,%eax
80100948:	89 c2                	mov    %eax,%edx
8010094a:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
8010094d:	80 ba 80 ee 10 80 0a 	cmpb   $0xa,-0x7fef1180(%edx)
80100954:	74 95                	je     801008eb <consoleintr+0x1b>
  if(panicked){
80100956:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
        input.e--;
8010095c:	a3 08 ef 10 80       	mov    %eax,0x8010ef08
  if(panicked){
80100961:	85 d2                	test   %edx,%edx
80100963:	74 3b                	je     801009a0 <consoleintr+0xd0>
80100965:	fa                   	cli
    for(;;)
80100966:	eb fe                	jmp    80100966 <consoleintr+0x96>
80100968:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010096f:	00 
    switch(c){
80100970:	83 f8 7f             	cmp    $0x7f,%eax
80100973:	75 4b                	jne    801009c0 <consoleintr+0xf0>
      if(input.e != input.w){
80100975:	a1 08 ef 10 80       	mov    0x8010ef08,%eax
8010097a:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
80100980:	0f 84 65 ff ff ff    	je     801008eb <consoleintr+0x1b>
        input.e--;
80100986:	83 e8 01             	sub    $0x1,%eax
80100989:	a3 08 ef 10 80       	mov    %eax,0x8010ef08
  if(panicked){
8010098e:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
80100993:	85 c0                	test   %eax,%eax
80100995:	0f 84 f9 00 00 00    	je     80100a94 <consoleintr+0x1c4>
8010099b:	fa                   	cli
    for(;;)
8010099c:	eb fe                	jmp    8010099c <consoleintr+0xcc>
8010099e:	66 90                	xchg   %ax,%ax
801009a0:	b8 00 01 00 00       	mov    $0x100,%eax
801009a5:	e8 76 fa ff ff       	call   80100420 <consputc.part.0>
      while(input.e != input.w &&
801009aa:	a1 08 ef 10 80       	mov    0x8010ef08,%eax
801009af:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
801009b5:	75 8e                	jne    80100945 <consoleintr+0x75>
801009b7:	e9 2f ff ff ff       	jmp    801008eb <consoleintr+0x1b>
801009bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(c != 0 && input.e-input.r < INPUT_BUF){
801009c0:	8b 15 08 ef 10 80    	mov    0x8010ef08,%edx
801009c6:	89 d1                	mov    %edx,%ecx
801009c8:	2b 0d 00 ef 10 80    	sub    0x8010ef00,%ecx
801009ce:	83 f9 7f             	cmp    $0x7f,%ecx
801009d1:	0f 87 14 ff ff ff    	ja     801008eb <consoleintr+0x1b>
  if(panicked){
801009d7:	8b 3d 58 ef 10 80    	mov    0x8010ef58,%edi
        input.buf[input.e++ % INPUT_BUF] = c;
801009dd:	8d 4a 01             	lea    0x1(%edx),%ecx
801009e0:	83 e2 7f             	and    $0x7f,%edx
801009e3:	89 0d 08 ef 10 80    	mov    %ecx,0x8010ef08
801009e9:	88 82 80 ee 10 80    	mov    %al,-0x7fef1180(%edx)
  if(panicked){
801009ef:	85 ff                	test   %edi,%edi
801009f1:	0f 85 b8 00 00 00    	jne    80100aaf <consoleintr+0x1df>
801009f7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801009fa:	e8 21 fa ff ff       	call   80100420 <consputc.part.0>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
801009ff:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100a02:	8b 15 08 ef 10 80    	mov    0x8010ef08,%edx
80100a08:	83 f8 0a             	cmp    $0xa,%eax
80100a0b:	74 15                	je     80100a22 <consoleintr+0x152>
80100a0d:	83 f8 04             	cmp    $0x4,%eax
80100a10:	74 10                	je     80100a22 <consoleintr+0x152>
80100a12:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
80100a17:	83 e8 80             	sub    $0xffffff80,%eax
80100a1a:	39 d0                	cmp    %edx,%eax
80100a1c:	0f 85 c9 fe ff ff    	jne    801008eb <consoleintr+0x1b>
          wakeup(&input.r);
80100a22:	83 ec 0c             	sub    $0xc,%esp
          input.w = input.e;
80100a25:	89 15 04 ef 10 80    	mov    %edx,0x8010ef04
          wakeup(&input.r);
80100a2b:	68 00 ef 10 80       	push   $0x8010ef00
80100a30:	e8 4b 39 00 00       	call   80104380 <wakeup>
80100a35:	83 c4 10             	add    $0x10,%esp
80100a38:	e9 ae fe ff ff       	jmp    801008eb <consoleintr+0x1b>
      if(c != 0 && input.e-input.r < INPUT_BUF){
80100a3d:	85 c0                	test   %eax,%eax
80100a3f:	0f 84 a6 fe ff ff    	je     801008eb <consoleintr+0x1b>
80100a45:	8b 15 08 ef 10 80    	mov    0x8010ef08,%edx
80100a4b:	89 d1                	mov    %edx,%ecx
80100a4d:	2b 0d 00 ef 10 80    	sub    0x8010ef00,%ecx
80100a53:	83 f9 7f             	cmp    $0x7f,%ecx
80100a56:	0f 87 8f fe ff ff    	ja     801008eb <consoleintr+0x1b>
        input.buf[input.e++ % INPUT_BUF] = c;
80100a5c:	8d 4a 01             	lea    0x1(%edx),%ecx
  if(panicked){
80100a5f:	8b 3d 58 ef 10 80    	mov    0x8010ef58,%edi
        input.buf[input.e++ % INPUT_BUF] = c;
80100a65:	83 e2 7f             	and    $0x7f,%edx
        c = (c == '\r') ? '\n' : c;
80100a68:	83 f8 0d             	cmp    $0xd,%eax
80100a6b:	0f 85 72 ff ff ff    	jne    801009e3 <consoleintr+0x113>
        input.buf[input.e++ % INPUT_BUF] = c;
80100a71:	89 0d 08 ef 10 80    	mov    %ecx,0x8010ef08
80100a77:	c6 82 80 ee 10 80 0a 	movb   $0xa,-0x7fef1180(%edx)
  if(panicked){
80100a7e:	85 ff                	test   %edi,%edi
80100a80:	75 2d                	jne    80100aaf <consoleintr+0x1df>
80100a82:	b8 0a 00 00 00       	mov    $0xa,%eax
80100a87:	e8 94 f9 ff ff       	call   80100420 <consputc.part.0>
          input.w = input.e;
80100a8c:	8b 15 08 ef 10 80    	mov    0x8010ef08,%edx
80100a92:	eb 8e                	jmp    80100a22 <consoleintr+0x152>
80100a94:	b8 00 01 00 00       	mov    $0x100,%eax
80100a99:	e8 82 f9 ff ff       	call   80100420 <consputc.part.0>
80100a9e:	e9 48 fe ff ff       	jmp    801008eb <consoleintr+0x1b>
}
80100aa3:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100aa6:	5b                   	pop    %ebx
80100aa7:	5e                   	pop    %esi
80100aa8:	5f                   	pop    %edi
80100aa9:	5d                   	pop    %ebp
    procdump();  // now call procdump() wo. cons.lock held
80100aaa:	e9 b1 39 00 00       	jmp    80104460 <procdump>
80100aaf:	fa                   	cli
    for(;;)
80100ab0:	eb fe                	jmp    80100ab0 <consoleintr+0x1e0>
80100ab2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80100ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100abf:	00 

80100ac0 <consoleinit>:

void
consoleinit(void)
{
80100ac0:	55                   	push   %ebp
80100ac1:	89 e5                	mov    %esp,%ebp
80100ac3:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
80100ac6:	68 08 76 10 80       	push   $0x80107608
80100acb:	68 20 ef 10 80       	push   $0x8010ef20
80100ad0:	e8 8b 3b 00 00       	call   80104660 <initlock>

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
80100ad5:	58                   	pop    %eax
80100ad6:	5a                   	pop    %edx
80100ad7:	6a 00                	push   $0x0
80100ad9:	6a 01                	push   $0x1
  devsw[CONSOLE].write = consolewrite;
80100adb:	c7 05 0c f9 10 80 d0 	movl   $0x801005d0,0x8010f90c
80100ae2:	05 10 80 
  devsw[CONSOLE].read = consoleread;
80100ae5:	c7 05 08 f9 10 80 a0 	movl   $0x801002a0,0x8010f908
80100aec:	02 10 80 
  cons.locking = 1;
80100aef:	c7 05 54 ef 10 80 01 	movl   $0x1,0x8010ef54
80100af6:	00 00 00 
  ioapicenable(IRQ_KBD, 0);
80100af9:	e8 82 1a 00 00       	call   80102580 <ioapicenable>
}
80100afe:	83 c4 10             	add    $0x10,%esp
80100b01:	c9                   	leave
80100b02:	c3                   	ret
80100b03:	66 90                	xchg   %ax,%ax
80100b05:	66 90                	xchg   %ax,%ax
80100b07:	66 90                	xchg   %ax,%ax
80100b09:	66 90                	xchg   %ax,%ax
80100b0b:	66 90                	xchg   %ax,%ax
80100b0d:	66 90                	xchg   %ax,%ax
80100b0f:	90                   	nop

80100b10 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100b10:	55                   	push   %ebp
80100b11:	89 e5                	mov    %esp,%ebp
80100b13:	57                   	push   %edi
80100b14:	56                   	push   %esi
80100b15:	53                   	push   %ebx
80100b16:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100b1c:	e8 bf 30 00 00       	call   80103be0 <myproc>
80100b21:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)

  begin_op();
80100b27:	e8 34 24 00 00       	call   80102f60 <begin_op>

  if((ip = namei(path)) == 0){
80100b2c:	83 ec 0c             	sub    $0xc,%esp
80100b2f:	ff 75 08             	push   0x8(%ebp)
80100b32:	e8 59 16 00 00       	call   80102190 <namei>
80100b37:	83 c4 10             	add    $0x10,%esp
80100b3a:	85 c0                	test   %eax,%eax
80100b3c:	0f 84 30 03 00 00    	je     80100e72 <exec+0x362>
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100b42:	83 ec 0c             	sub    $0xc,%esp
80100b45:	89 c7                	mov    %eax,%edi
80100b47:	50                   	push   %eax
80100b48:	e8 23 0d 00 00       	call   80101870 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100b4d:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100b53:	6a 34                	push   $0x34
80100b55:	6a 00                	push   $0x0
80100b57:	50                   	push   %eax
80100b58:	57                   	push   %edi
80100b59:	e8 32 10 00 00       	call   80101b90 <readi>
80100b5e:	83 c4 20             	add    $0x20,%esp
80100b61:	83 f8 34             	cmp    $0x34,%eax
80100b64:	0f 85 01 01 00 00    	jne    80100c6b <exec+0x15b>
    goto bad;
  if(elf.magic != ELF_MAGIC)
80100b6a:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
80100b71:	45 4c 46 
80100b74:	0f 85 f1 00 00 00    	jne    80100c6b <exec+0x15b>
    goto bad;

  if((pgdir = setupkvm()) == 0)
80100b7a:	e8 f1 66 00 00       	call   80107270 <setupkvm>
80100b7f:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)
80100b85:	85 c0                	test   %eax,%eax
80100b87:	0f 84 de 00 00 00    	je     80100c6b <exec+0x15b>
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100b8d:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
80100b94:	00 
80100b95:	0f 84 a7 02 00 00    	je     80100e42 <exec+0x332>
  sz = 0;
80100b9b:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100ba2:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100ba5:	8b 9d 40 ff ff ff    	mov    -0xc0(%ebp),%ebx
80100bab:	31 f6                	xor    %esi,%esi
80100bad:	e9 8c 00 00 00       	jmp    80100c3e <exec+0x12e>
80100bb2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
80100bb8:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100bbf:	75 6c                	jne    80100c2d <exec+0x11d>
      continue;
    if(ph.memsz < ph.filesz)
80100bc1:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100bc7:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100bcd:	0f 82 87 00 00 00    	jb     80100c5a <exec+0x14a>
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100bd3:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100bd9:	72 7f                	jb     80100c5a <exec+0x14a>
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100bdb:	83 ec 04             	sub    $0x4,%esp
80100bde:	50                   	push   %eax
80100bdf:	ff b5 f0 fe ff ff    	push   -0x110(%ebp)
80100be5:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100beb:	e8 b0 64 00 00       	call   801070a0 <allocuvm>
80100bf0:	83 c4 10             	add    $0x10,%esp
80100bf3:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100bf9:	85 c0                	test   %eax,%eax
80100bfb:	74 5d                	je     80100c5a <exec+0x14a>
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
80100bfd:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100c03:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100c08:	75 50                	jne    80100c5a <exec+0x14a>
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100c0a:	83 ec 0c             	sub    $0xc,%esp
80100c0d:	ff b5 14 ff ff ff    	push   -0xec(%ebp)
80100c13:	ff b5 08 ff ff ff    	push   -0xf8(%ebp)
80100c19:	57                   	push   %edi
80100c1a:	50                   	push   %eax
80100c1b:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100c21:	e8 aa 63 00 00       	call   80106fd0 <loaduvm>
80100c26:	83 c4 20             	add    $0x20,%esp
80100c29:	85 c0                	test   %eax,%eax
80100c2b:	78 2d                	js     80100c5a <exec+0x14a>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100c2d:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80100c34:	83 c6 01             	add    $0x1,%esi
80100c37:	83 c3 20             	add    $0x20,%ebx
80100c3a:	39 f0                	cmp    %esi,%eax
80100c3c:	7e 52                	jle    80100c90 <exec+0x180>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100c3e:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100c44:	6a 20                	push   $0x20
80100c46:	53                   	push   %ebx
80100c47:	50                   	push   %eax
80100c48:	57                   	push   %edi
80100c49:	e8 42 0f 00 00       	call   80101b90 <readi>
80100c4e:	83 c4 10             	add    $0x10,%esp
80100c51:	83 f8 20             	cmp    $0x20,%eax
80100c54:	0f 84 5e ff ff ff    	je     80100bb8 <exec+0xa8>
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
80100c5a:	83 ec 0c             	sub    $0xc,%esp
80100c5d:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100c63:	e8 88 65 00 00       	call   801071f0 <freevm>
  if(ip){
80100c68:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80100c6b:	83 ec 0c             	sub    $0xc,%esp
80100c6e:	57                   	push   %edi
80100c6f:	e8 9c 0e 00 00       	call   80101b10 <iunlockput>
    end_op();
80100c74:	e8 57 23 00 00       	call   80102fd0 <end_op>
80100c79:	83 c4 10             	add    $0x10,%esp
    return -1;
80100c7c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  }
  return -1;
}
80100c81:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100c84:	5b                   	pop    %ebx
80100c85:	5e                   	pop    %esi
80100c86:	5f                   	pop    %edi
80100c87:	5d                   	pop    %ebp
80100c88:	c3                   	ret
80100c89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  sz = PGROUNDUP(sz);
80100c90:	8b b5 f0 fe ff ff    	mov    -0x110(%ebp),%esi
80100c96:	81 c6 ff 0f 00 00    	add    $0xfff,%esi
80100c9c:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ca2:	8d 9e 00 20 00 00    	lea    0x2000(%esi),%ebx
  iunlockput(ip);
80100ca8:	83 ec 0c             	sub    $0xc,%esp
80100cab:	57                   	push   %edi
80100cac:	e8 5f 0e 00 00       	call   80101b10 <iunlockput>
  end_op();
80100cb1:	e8 1a 23 00 00       	call   80102fd0 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100cb6:	83 c4 0c             	add    $0xc,%esp
80100cb9:	53                   	push   %ebx
80100cba:	56                   	push   %esi
80100cbb:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
80100cc1:	56                   	push   %esi
80100cc2:	e8 d9 63 00 00       	call   801070a0 <allocuvm>
80100cc7:	83 c4 10             	add    $0x10,%esp
80100cca:	89 c7                	mov    %eax,%edi
80100ccc:	85 c0                	test   %eax,%eax
80100cce:	0f 84 86 00 00 00    	je     80100d5a <exec+0x24a>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100cd4:	83 ec 08             	sub    $0x8,%esp
80100cd7:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
  sp = sz;
80100cdd:	89 fb                	mov    %edi,%ebx
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100cdf:	50                   	push   %eax
80100ce0:	56                   	push   %esi
  for(argc = 0; argv[argc]; argc++) {
80100ce1:	31 f6                	xor    %esi,%esi
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100ce3:	e8 28 66 00 00       	call   80107310 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100ce8:	8b 45 0c             	mov    0xc(%ebp),%eax
80100ceb:	83 c4 10             	add    $0x10,%esp
80100cee:	8b 10                	mov    (%eax),%edx
80100cf0:	85 d2                	test   %edx,%edx
80100cf2:	0f 84 56 01 00 00    	je     80100e4e <exec+0x33e>
80100cf8:	89 bd f0 fe ff ff    	mov    %edi,-0x110(%ebp)
80100cfe:	8b 7d 0c             	mov    0xc(%ebp),%edi
80100d01:	eb 23                	jmp    80100d26 <exec+0x216>
80100d03:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100d08:	8d 46 01             	lea    0x1(%esi),%eax
    ustack[3+argc] = sp;
80100d0b:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
80100d12:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
  for(argc = 0; argv[argc]; argc++) {
80100d18:	8b 14 87             	mov    (%edi,%eax,4),%edx
80100d1b:	85 d2                	test   %edx,%edx
80100d1d:	74 51                	je     80100d70 <exec+0x260>
    if(argc >= MAXARG)
80100d1f:	83 f8 20             	cmp    $0x20,%eax
80100d22:	74 36                	je     80100d5a <exec+0x24a>
80100d24:	89 c6                	mov    %eax,%esi
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100d26:	83 ec 0c             	sub    $0xc,%esp
80100d29:	52                   	push   %edx
80100d2a:	e8 71 3e 00 00       	call   80104ba0 <strlen>
80100d2f:	29 c3                	sub    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100d31:	58                   	pop    %eax
80100d32:	ff 34 b7             	push   (%edi,%esi,4)
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100d35:	83 eb 01             	sub    $0x1,%ebx
80100d38:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100d3b:	e8 60 3e 00 00       	call   80104ba0 <strlen>
80100d40:	83 c0 01             	add    $0x1,%eax
80100d43:	50                   	push   %eax
80100d44:	ff 34 b7             	push   (%edi,%esi,4)
80100d47:	53                   	push   %ebx
80100d48:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100d4e:	e8 7d 67 00 00       	call   801074d0 <copyout>
80100d53:	83 c4 20             	add    $0x20,%esp
80100d56:	85 c0                	test   %eax,%eax
80100d58:	79 ae                	jns    80100d08 <exec+0x1f8>
    freevm(pgdir);
80100d5a:	83 ec 0c             	sub    $0xc,%esp
80100d5d:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100d63:	e8 88 64 00 00       	call   801071f0 <freevm>
80100d68:	83 c4 10             	add    $0x10,%esp
80100d6b:	e9 0c ff ff ff       	jmp    80100c7c <exec+0x16c>
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100d70:	8d 14 b5 08 00 00 00 	lea    0x8(,%esi,4),%edx
  ustack[3+argc] = 0;
80100d77:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
80100d7d:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%ebp)
80100d83:	8d 46 04             	lea    0x4(%esi),%eax
  sp -= (3+argc+1) * 4;
80100d86:	8d 72 0c             	lea    0xc(%edx),%esi
  ustack[3+argc] = 0;
80100d89:	c7 84 85 58 ff ff ff 	movl   $0x0,-0xa8(%ebp,%eax,4)
80100d90:	00 00 00 00 
  ustack[1] = argc;
80100d94:	8b 85 e8 fe ff ff    	mov    -0x118(%ebp),%eax
  ustack[0] = 0xffffffff;  // fake return PC
80100d9a:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100da1:	ff ff ff 
  ustack[1] = argc;
80100da4:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100daa:	89 d8                	mov    %ebx,%eax
  sp -= (3+argc+1) * 4;
80100dac:	29 f3                	sub    %esi,%ebx
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100dae:	29 d0                	sub    %edx,%eax
80100db0:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100db6:	56                   	push   %esi
80100db7:	51                   	push   %ecx
80100db8:	53                   	push   %ebx
80100db9:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100dbf:	e8 0c 67 00 00       	call   801074d0 <copyout>
80100dc4:	83 c4 10             	add    $0x10,%esp
80100dc7:	85 c0                	test   %eax,%eax
80100dc9:	78 8f                	js     80100d5a <exec+0x24a>
  for(last=s=path; *s; s++)
80100dcb:	8b 45 08             	mov    0x8(%ebp),%eax
80100dce:	8b 55 08             	mov    0x8(%ebp),%edx
80100dd1:	0f b6 00             	movzbl (%eax),%eax
80100dd4:	84 c0                	test   %al,%al
80100dd6:	74 17                	je     80100def <exec+0x2df>
80100dd8:	89 d1                	mov    %edx,%ecx
80100dda:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      last = s+1;
80100de0:	83 c1 01             	add    $0x1,%ecx
80100de3:	3c 2f                	cmp    $0x2f,%al
  for(last=s=path; *s; s++)
80100de5:	0f b6 01             	movzbl (%ecx),%eax
      last = s+1;
80100de8:	0f 44 d1             	cmove  %ecx,%edx
  for(last=s=path; *s; s++)
80100deb:	84 c0                	test   %al,%al
80100ded:	75 f1                	jne    80100de0 <exec+0x2d0>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100def:	83 ec 04             	sub    $0x4,%esp
80100df2:	6a 10                	push   $0x10
80100df4:	52                   	push   %edx
80100df5:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
80100dfb:	8d 46 6c             	lea    0x6c(%esi),%eax
80100dfe:	50                   	push   %eax
80100dff:	e8 4c 3d 00 00       	call   80104b50 <safestrcpy>
  curproc->pgdir = pgdir;
80100e04:	8b 8d f4 fe ff ff    	mov    -0x10c(%ebp),%ecx
  oldpgdir = curproc->pgdir;
80100e0a:	89 f0                	mov    %esi,%eax
80100e0c:	8b 76 04             	mov    0x4(%esi),%esi
  curproc->sz = sz;
80100e0f:	89 38                	mov    %edi,(%eax)
  curproc->pgdir = pgdir;
80100e11:	89 48 04             	mov    %ecx,0x4(%eax)
  curproc->tf->eip = elf.entry;  // main
80100e14:	89 c1                	mov    %eax,%ecx
80100e16:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100e1c:	8b 40 18             	mov    0x18(%eax),%eax
80100e1f:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100e22:	8b 41 18             	mov    0x18(%ecx),%eax
80100e25:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80100e28:	89 0c 24             	mov    %ecx,(%esp)
80100e2b:	e8 10 60 00 00       	call   80106e40 <switchuvm>
  freevm(oldpgdir);
80100e30:	89 34 24             	mov    %esi,(%esp)
80100e33:	e8 b8 63 00 00       	call   801071f0 <freevm>
  return 0;
80100e38:	83 c4 10             	add    $0x10,%esp
80100e3b:	31 c0                	xor    %eax,%eax
80100e3d:	e9 3f fe ff ff       	jmp    80100c81 <exec+0x171>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100e42:	bb 00 20 00 00       	mov    $0x2000,%ebx
80100e47:	31 f6                	xor    %esi,%esi
80100e49:	e9 5a fe ff ff       	jmp    80100ca8 <exec+0x198>
  for(argc = 0; argv[argc]; argc++) {
80100e4e:	be 10 00 00 00       	mov    $0x10,%esi
80100e53:	ba 04 00 00 00       	mov    $0x4,%edx
80100e58:	b8 03 00 00 00       	mov    $0x3,%eax
80100e5d:	c7 85 e8 fe ff ff 00 	movl   $0x0,-0x118(%ebp)
80100e64:	00 00 00 
80100e67:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
80100e6d:	e9 17 ff ff ff       	jmp    80100d89 <exec+0x279>
    end_op();
80100e72:	e8 59 21 00 00       	call   80102fd0 <end_op>
    cprintf("exec: fail\n");
80100e77:	83 ec 0c             	sub    $0xc,%esp
80100e7a:	68 10 76 10 80       	push   $0x80107610
80100e7f:	e8 4c f8 ff ff       	call   801006d0 <cprintf>
    return -1;
80100e84:	83 c4 10             	add    $0x10,%esp
80100e87:	e9 f0 fd ff ff       	jmp    80100c7c <exec+0x16c>
80100e8c:	66 90                	xchg   %ax,%ax
80100e8e:	66 90                	xchg   %ax,%ax
80100e90:	66 90                	xchg   %ax,%ax
80100e92:	66 90                	xchg   %ax,%ax
80100e94:	66 90                	xchg   %ax,%ax
80100e96:	66 90                	xchg   %ax,%ax
80100e98:	66 90                	xchg   %ax,%ax
80100e9a:	66 90                	xchg   %ax,%ax
80100e9c:	66 90                	xchg   %ax,%ax
80100e9e:	66 90                	xchg   %ax,%ax

80100ea0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100ea0:	55                   	push   %ebp
80100ea1:	89 e5                	mov    %esp,%ebp
80100ea3:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100ea6:	68 1c 76 10 80       	push   $0x8010761c
80100eab:	68 60 ef 10 80       	push   $0x8010ef60
80100eb0:	e8 ab 37 00 00       	call   80104660 <initlock>
}
80100eb5:	83 c4 10             	add    $0x10,%esp
80100eb8:	c9                   	leave
80100eb9:	c3                   	ret
80100eba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80100ec0 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100ec0:	55                   	push   %ebp
80100ec1:	89 e5                	mov    %esp,%ebp
80100ec3:	53                   	push   %ebx
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100ec4:	bb 94 ef 10 80       	mov    $0x8010ef94,%ebx
{
80100ec9:	83 ec 10             	sub    $0x10,%esp
  acquire(&ftable.lock);
80100ecc:	68 60 ef 10 80       	push   $0x8010ef60
80100ed1:	e8 aa 39 00 00       	call   80104880 <acquire>
80100ed6:	83 c4 10             	add    $0x10,%esp
80100ed9:	eb 10                	jmp    80100eeb <filealloc+0x2b>
80100edb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100ee0:	83 c3 18             	add    $0x18,%ebx
80100ee3:	81 fb f4 f8 10 80    	cmp    $0x8010f8f4,%ebx
80100ee9:	74 25                	je     80100f10 <filealloc+0x50>
    if(f->ref == 0){
80100eeb:	8b 43 04             	mov    0x4(%ebx),%eax
80100eee:	85 c0                	test   %eax,%eax
80100ef0:	75 ee                	jne    80100ee0 <filealloc+0x20>
      f->ref = 1;
      release(&ftable.lock);
80100ef2:	83 ec 0c             	sub    $0xc,%esp
      f->ref = 1;
80100ef5:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100efc:	68 60 ef 10 80       	push   $0x8010ef60
80100f01:	e8 1a 39 00 00       	call   80104820 <release>
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}
80100f06:	89 d8                	mov    %ebx,%eax
      return f;
80100f08:	83 c4 10             	add    $0x10,%esp
}
80100f0b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f0e:	c9                   	leave
80100f0f:	c3                   	ret
  release(&ftable.lock);
80100f10:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80100f13:	31 db                	xor    %ebx,%ebx
  release(&ftable.lock);
80100f15:	68 60 ef 10 80       	push   $0x8010ef60
80100f1a:	e8 01 39 00 00       	call   80104820 <release>
}
80100f1f:	89 d8                	mov    %ebx,%eax
  return 0;
80100f21:	83 c4 10             	add    $0x10,%esp
}
80100f24:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f27:	c9                   	leave
80100f28:	c3                   	ret
80100f29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80100f30 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100f30:	55                   	push   %ebp
80100f31:	89 e5                	mov    %esp,%ebp
80100f33:	53                   	push   %ebx
80100f34:	83 ec 10             	sub    $0x10,%esp
80100f37:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100f3a:	68 60 ef 10 80       	push   $0x8010ef60
80100f3f:	e8 3c 39 00 00       	call   80104880 <acquire>
  if(f->ref < 1)
80100f44:	8b 43 04             	mov    0x4(%ebx),%eax
80100f47:	83 c4 10             	add    $0x10,%esp
80100f4a:	85 c0                	test   %eax,%eax
80100f4c:	7e 1a                	jle    80100f68 <filedup+0x38>
    panic("filedup");
  f->ref++;
80100f4e:	83 c0 01             	add    $0x1,%eax
  release(&ftable.lock);
80100f51:	83 ec 0c             	sub    $0xc,%esp
  f->ref++;
80100f54:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100f57:	68 60 ef 10 80       	push   $0x8010ef60
80100f5c:	e8 bf 38 00 00       	call   80104820 <release>
  return f;
}
80100f61:	89 d8                	mov    %ebx,%eax
80100f63:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f66:	c9                   	leave
80100f67:	c3                   	ret
    panic("filedup");
80100f68:	83 ec 0c             	sub    $0xc,%esp
80100f6b:	68 23 76 10 80       	push   $0x80107623
80100f70:	e8 2b f4 ff ff       	call   801003a0 <panic>
80100f75:	8d 76 00             	lea    0x0(%esi),%esi
80100f78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100f7f:	00 

80100f80 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100f80:	55                   	push   %ebp
80100f81:	89 e5                	mov    %esp,%ebp
80100f83:	57                   	push   %edi
80100f84:	56                   	push   %esi
80100f85:	53                   	push   %ebx
80100f86:	83 ec 28             	sub    $0x28,%esp
80100f89:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80100f8c:	68 60 ef 10 80       	push   $0x8010ef60
80100f91:	e8 ea 38 00 00       	call   80104880 <acquire>
  if(f->ref < 1)
80100f96:	8b 43 04             	mov    0x4(%ebx),%eax
80100f99:	83 c4 10             	add    $0x10,%esp
80100f9c:	85 c0                	test   %eax,%eax
80100f9e:	0f 8e a8 00 00 00    	jle    8010104c <fileclose+0xcc>
    panic("fileclose");
  if(--f->ref > 0){
80100fa4:	83 e8 01             	sub    $0x1,%eax
80100fa7:	89 43 04             	mov    %eax,0x4(%ebx)
80100faa:	75 44                	jne    80100ff0 <fileclose+0x70>
    release(&ftable.lock);
    return;
  }
  ff = *f;
80100fac:	8b 43 0c             	mov    0xc(%ebx),%eax
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);
80100faf:	83 ec 0c             	sub    $0xc,%esp
  ff = *f;
80100fb2:	8b 33                	mov    (%ebx),%esi
  f->type = FD_NONE;
80100fb4:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  ff = *f;
80100fba:	0f b6 7b 09          	movzbl 0x9(%ebx),%edi
80100fbe:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100fc1:	8b 43 10             	mov    0x10(%ebx),%eax
80100fc4:	89 45 e0             	mov    %eax,-0x20(%ebp)
  release(&ftable.lock);
80100fc7:	68 60 ef 10 80       	push   $0x8010ef60
80100fcc:	e8 4f 38 00 00       	call   80104820 <release>

  if(ff.type == FD_PIPE)
80100fd1:	83 c4 10             	add    $0x10,%esp
80100fd4:	83 fe 01             	cmp    $0x1,%esi
80100fd7:	74 57                	je     80101030 <fileclose+0xb0>
    pipeclose(ff.pipe, ff.writable);
  else if(ff.type == FD_INODE){
80100fd9:	83 fe 02             	cmp    $0x2,%esi
80100fdc:	74 2a                	je     80101008 <fileclose+0x88>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100fde:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fe1:	5b                   	pop    %ebx
80100fe2:	5e                   	pop    %esi
80100fe3:	5f                   	pop    %edi
80100fe4:	5d                   	pop    %ebp
80100fe5:	c3                   	ret
80100fe6:	66 90                	xchg   %ax,%ax
80100fe8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100fef:	00 
    release(&ftable.lock);
80100ff0:	c7 45 08 60 ef 10 80 	movl   $0x8010ef60,0x8(%ebp)
}
80100ff7:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ffa:	5b                   	pop    %ebx
80100ffb:	5e                   	pop    %esi
80100ffc:	5f                   	pop    %edi
80100ffd:	5d                   	pop    %ebp
    release(&ftable.lock);
80100ffe:	e9 1d 38 00 00       	jmp    80104820 <release>
80101003:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    begin_op();
80101008:	e8 53 1f 00 00       	call   80102f60 <begin_op>
    iput(ff.ip);
8010100d:	83 ec 0c             	sub    $0xc,%esp
80101010:	ff 75 e0             	push   -0x20(%ebp)
80101013:	e8 88 09 00 00       	call   801019a0 <iput>
    end_op();
80101018:	83 c4 10             	add    $0x10,%esp
}
8010101b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010101e:	5b                   	pop    %ebx
8010101f:	5e                   	pop    %esi
80101020:	5f                   	pop    %edi
80101021:	5d                   	pop    %ebp
    end_op();
80101022:	e9 a9 1f 00 00       	jmp    80102fd0 <end_op>
80101027:	90                   	nop
80101028:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010102f:	00 
    pipeclose(ff.pipe, ff.writable);
80101030:	89 f8                	mov    %edi,%eax
80101032:	83 ec 08             	sub    $0x8,%esp
80101035:	0f be c0             	movsbl %al,%eax
80101038:	50                   	push   %eax
80101039:	ff 75 e4             	push   -0x1c(%ebp)
8010103c:	e8 ef 26 00 00       	call   80103730 <pipeclose>
80101041:	83 c4 10             	add    $0x10,%esp
}
80101044:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101047:	5b                   	pop    %ebx
80101048:	5e                   	pop    %esi
80101049:	5f                   	pop    %edi
8010104a:	5d                   	pop    %ebp
8010104b:	c3                   	ret
    panic("fileclose");
8010104c:	83 ec 0c             	sub    $0xc,%esp
8010104f:	68 2b 76 10 80       	push   $0x8010762b
80101054:	e8 47 f3 ff ff       	call   801003a0 <panic>
80101059:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80101060 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80101060:	55                   	push   %ebp
80101061:	89 e5                	mov    %esp,%ebp
80101063:	53                   	push   %ebx
80101064:	83 ec 04             	sub    $0x4,%esp
80101067:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
8010106a:	83 3b 02             	cmpl   $0x2,(%ebx)
8010106d:	75 31                	jne    801010a0 <filestat+0x40>
    ilock(f->ip);
8010106f:	83 ec 0c             	sub    $0xc,%esp
80101072:	ff 73 10             	push   0x10(%ebx)
80101075:	e8 f6 07 00 00       	call   80101870 <ilock>
    stati(f->ip, st);
8010107a:	58                   	pop    %eax
8010107b:	5a                   	pop    %edx
8010107c:	ff 75 0c             	push   0xc(%ebp)
8010107f:	ff 73 10             	push   0x10(%ebx)
80101082:	e8 d9 0a 00 00       	call   80101b60 <stati>
    iunlock(f->ip);
80101087:	59                   	pop    %ecx
80101088:	ff 73 10             	push   0x10(%ebx)
8010108b:	e8 c0 08 00 00       	call   80101950 <iunlock>
    return 0;
  }
  return -1;
}
80101090:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80101093:	83 c4 10             	add    $0x10,%esp
80101096:	31 c0                	xor    %eax,%eax
}
80101098:	c9                   	leave
80101099:	c3                   	ret
8010109a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801010a0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
801010a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801010a8:	c9                   	leave
801010a9:	c3                   	ret
801010aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801010b0 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
801010b0:	55                   	push   %ebp
801010b1:	89 e5                	mov    %esp,%ebp
801010b3:	57                   	push   %edi
801010b4:	56                   	push   %esi
801010b5:	53                   	push   %ebx
801010b6:	83 ec 0c             	sub    $0xc,%esp
801010b9:	8b 5d 08             	mov    0x8(%ebp),%ebx
801010bc:	8b 75 0c             	mov    0xc(%ebp),%esi
801010bf:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
801010c2:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
801010c6:	74 60                	je     80101128 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
801010c8:	8b 03                	mov    (%ebx),%eax
801010ca:	83 f8 01             	cmp    $0x1,%eax
801010cd:	74 41                	je     80101110 <fileread+0x60>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
801010cf:	83 f8 02             	cmp    $0x2,%eax
801010d2:	75 5b                	jne    8010112f <fileread+0x7f>
    ilock(f->ip);
801010d4:	83 ec 0c             	sub    $0xc,%esp
801010d7:	ff 73 10             	push   0x10(%ebx)
801010da:	e8 91 07 00 00       	call   80101870 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
801010df:	57                   	push   %edi
801010e0:	ff 73 14             	push   0x14(%ebx)
801010e3:	56                   	push   %esi
801010e4:	ff 73 10             	push   0x10(%ebx)
801010e7:	e8 a4 0a 00 00       	call   80101b90 <readi>
801010ec:	83 c4 20             	add    $0x20,%esp
801010ef:	89 c6                	mov    %eax,%esi
801010f1:	85 c0                	test   %eax,%eax
801010f3:	7e 03                	jle    801010f8 <fileread+0x48>
      f->off += r;
801010f5:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
801010f8:	83 ec 0c             	sub    $0xc,%esp
801010fb:	ff 73 10             	push   0x10(%ebx)
801010fe:	e8 4d 08 00 00       	call   80101950 <iunlock>
    return r;
80101103:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80101106:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101109:	89 f0                	mov    %esi,%eax
8010110b:	5b                   	pop    %ebx
8010110c:	5e                   	pop    %esi
8010110d:	5f                   	pop    %edi
8010110e:	5d                   	pop    %ebp
8010110f:	c3                   	ret
    return piperead(f->pipe, addr, n);
80101110:	8b 43 0c             	mov    0xc(%ebx),%eax
80101113:	89 45 08             	mov    %eax,0x8(%ebp)
}
80101116:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101119:	5b                   	pop    %ebx
8010111a:	5e                   	pop    %esi
8010111b:	5f                   	pop    %edi
8010111c:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
8010111d:	e9 be 27 00 00       	jmp    801038e0 <piperead>
80101122:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80101128:	be ff ff ff ff       	mov    $0xffffffff,%esi
8010112d:	eb d7                	jmp    80101106 <fileread+0x56>
  panic("fileread");
8010112f:	83 ec 0c             	sub    $0xc,%esp
80101132:	68 35 76 10 80       	push   $0x80107635
80101137:	e8 64 f2 ff ff       	call   801003a0 <panic>
8010113c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101140 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80101140:	55                   	push   %ebp
80101141:	89 e5                	mov    %esp,%ebp
80101143:	57                   	push   %edi
80101144:	56                   	push   %esi
80101145:	53                   	push   %ebx
80101146:	83 ec 1c             	sub    $0x1c,%esp
80101149:	8b 45 0c             	mov    0xc(%ebp),%eax
8010114c:	8b 7d 08             	mov    0x8(%ebp),%edi
8010114f:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101152:	8b 45 10             	mov    0x10(%ebp),%eax
80101155:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  int r;

  if(f->writable == 0)
80101158:	80 7f 09 00          	cmpb   $0x0,0x9(%edi)
8010115c:	0f 84 b3 00 00 00    	je     80101215 <filewrite+0xd5>
    return -1;
  if(f->type == FD_PIPE)
80101162:	8b 17                	mov    (%edi),%edx
80101164:	83 fa 01             	cmp    $0x1,%edx
80101167:	0f 84 b7 00 00 00    	je     80101224 <filewrite+0xe4>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
8010116d:	83 fa 02             	cmp    $0x2,%edx
80101170:	0f 85 c0 00 00 00    	jne    80101236 <filewrite+0xf6>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80101176:	8b 55 e4             	mov    -0x1c(%ebp),%edx
    int i = 0;
80101179:	31 f6                	xor    %esi,%esi
    while(i < n){
8010117b:	85 d2                	test   %edx,%edx
8010117d:	7f 2e                	jg     801011ad <filewrite+0x6d>
8010117f:	e9 8c 00 00 00       	jmp    80101210 <filewrite+0xd0>
80101184:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
80101188:	01 47 14             	add    %eax,0x14(%edi)
      iunlock(f->ip);
8010118b:	83 ec 0c             	sub    $0xc,%esp
        f->off += r;
8010118e:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
80101191:	51                   	push   %ecx
80101192:	e8 b9 07 00 00       	call   80101950 <iunlock>
      end_op();
80101197:	e8 34 1e 00 00       	call   80102fd0 <end_op>

      if(r < 0)
        break;
      if(r != n1)
8010119c:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010119f:	83 c4 10             	add    $0x10,%esp
801011a2:	39 d8                	cmp    %ebx,%eax
801011a4:	75 5d                	jne    80101203 <filewrite+0xc3>
        panic("short filewrite");
      i += r;
801011a6:	01 c6                	add    %eax,%esi
    while(i < n){
801011a8:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
801011ab:	7e 63                	jle    80101210 <filewrite+0xd0>
      int n1 = n - i;
801011ad:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
      if(n1 > max)
801011b0:	b8 00 06 00 00       	mov    $0x600,%eax
      int n1 = n - i;
801011b5:	29 f3                	sub    %esi,%ebx
      if(n1 > max)
801011b7:	39 c3                	cmp    %eax,%ebx
801011b9:	0f 4f d8             	cmovg  %eax,%ebx
      begin_op();
801011bc:	e8 9f 1d 00 00       	call   80102f60 <begin_op>
      ilock(f->ip);
801011c1:	83 ec 0c             	sub    $0xc,%esp
801011c4:	ff 77 10             	push   0x10(%edi)
801011c7:	e8 a4 06 00 00       	call   80101870 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
801011cc:	53                   	push   %ebx
801011cd:	ff 77 14             	push   0x14(%edi)
801011d0:	8b 45 dc             	mov    -0x24(%ebp),%eax
801011d3:	01 f0                	add    %esi,%eax
801011d5:	50                   	push   %eax
801011d6:	ff 77 10             	push   0x10(%edi)
801011d9:	e8 b2 0a 00 00       	call   80101c90 <writei>
      iunlock(f->ip);
801011de:	8b 4f 10             	mov    0x10(%edi),%ecx
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
801011e1:	83 c4 20             	add    $0x20,%esp
801011e4:	85 c0                	test   %eax,%eax
801011e6:	7f a0                	jg     80101188 <filewrite+0x48>
      iunlock(f->ip);
801011e8:	83 ec 0c             	sub    $0xc,%esp
801011eb:	89 45 e0             	mov    %eax,-0x20(%ebp)
801011ee:	51                   	push   %ecx
801011ef:	e8 5c 07 00 00       	call   80101950 <iunlock>
      end_op();
801011f4:	e8 d7 1d 00 00       	call   80102fd0 <end_op>
      if(r < 0)
801011f9:	8b 45 e0             	mov    -0x20(%ebp),%eax
801011fc:	83 c4 10             	add    $0x10,%esp
801011ff:	85 c0                	test   %eax,%eax
80101201:	75 0d                	jne    80101210 <filewrite+0xd0>
        panic("short filewrite");
80101203:	83 ec 0c             	sub    $0xc,%esp
80101206:	68 3e 76 10 80       	push   $0x8010763e
8010120b:	e8 90 f1 ff ff       	call   801003a0 <panic>
    }
    return i == n ? n : -1;
80101210:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
80101213:	74 05                	je     8010121a <filewrite+0xda>
    return -1;
80101215:	be ff ff ff ff       	mov    $0xffffffff,%esi
  }
  panic("filewrite");
}
8010121a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010121d:	89 f0                	mov    %esi,%eax
8010121f:	5b                   	pop    %ebx
80101220:	5e                   	pop    %esi
80101221:	5f                   	pop    %edi
80101222:	5d                   	pop    %ebp
80101223:	c3                   	ret
    return pipewrite(f->pipe, addr, n);
80101224:	8b 47 0c             	mov    0xc(%edi),%eax
80101227:	89 45 08             	mov    %eax,0x8(%ebp)
}
8010122a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010122d:	5b                   	pop    %ebx
8010122e:	5e                   	pop    %esi
8010122f:	5f                   	pop    %edi
80101230:	5d                   	pop    %ebp
    return pipewrite(f->pipe, addr, n);
80101231:	e9 9a 25 00 00       	jmp    801037d0 <pipewrite>
  panic("filewrite");
80101236:	83 ec 0c             	sub    $0xc,%esp
80101239:	68 44 76 10 80       	push   $0x80107644
8010123e:	e8 5d f1 ff ff       	call   801003a0 <panic>
80101243:	66 90                	xchg   %ax,%ax
80101245:	66 90                	xchg   %ax,%ax
80101247:	66 90                	xchg   %ax,%ax
80101249:	66 90                	xchg   %ax,%ax
8010124b:	66 90                	xchg   %ax,%ax
8010124d:	66 90                	xchg   %ax,%ax
8010124f:	90                   	nop

80101250 <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
80101250:	55                   	push   %ebp
80101251:	89 e5                	mov    %esp,%ebp
80101253:	57                   	push   %edi
80101254:	56                   	push   %esi
80101255:	53                   	push   %ebx
80101256:	83 ec 1c             	sub    $0x1c,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  for(b = 0; b < sb.size; b += BPB){
80101259:	8b 0d b4 15 11 80    	mov    0x801115b4,%ecx
{
8010125f:	89 45 dc             	mov    %eax,-0x24(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101262:	85 c9                	test   %ecx,%ecx
80101264:	0f 84 8a 00 00 00    	je     801012f4 <balloc+0xa4>
8010126a:	31 ff                	xor    %edi,%edi
    bp = bread(dev, BBLOCK(b, sb));
8010126c:	89 f8                	mov    %edi,%eax
8010126e:	83 ec 08             	sub    $0x8,%esp
80101271:	89 fe                	mov    %edi,%esi
80101273:	c1 f8 0c             	sar    $0xc,%eax
80101276:	03 05 cc 15 11 80    	add    0x801115cc,%eax
8010127c:	50                   	push   %eax
8010127d:	ff 75 dc             	push   -0x24(%ebp)
80101280:	e8 4b ee ff ff       	call   801000d0 <bread>
80101285:	83 c4 10             	add    $0x10,%esp
80101288:	89 7d d8             	mov    %edi,-0x28(%ebp)
8010128b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010128e:	a1 b4 15 11 80       	mov    0x801115b4,%eax
80101293:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101296:	31 c0                	xor    %eax,%eax
80101298:	eb 32                	jmp    801012cc <balloc+0x7c>
8010129a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      m = 1 << (bi % 8);
801012a0:	89 c1                	mov    %eax,%ecx
801012a2:	bb 01 00 00 00       	mov    $0x1,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801012a7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      m = 1 << (bi % 8);
801012aa:	83 e1 07             	and    $0x7,%ecx
801012ad:	d3 e3                	shl    %cl,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801012af:	89 c1                	mov    %eax,%ecx
801012b1:	c1 f9 03             	sar    $0x3,%ecx
801012b4:	0f b6 7c 0f 5c       	movzbl 0x5c(%edi,%ecx,1),%edi
801012b9:	89 fa                	mov    %edi,%edx
801012bb:	85 df                	test   %ebx,%edi
801012bd:	74 49                	je     80101308 <balloc+0xb8>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801012bf:	83 c0 01             	add    $0x1,%eax
801012c2:	83 c6 01             	add    $0x1,%esi
801012c5:	3d 00 10 00 00       	cmp    $0x1000,%eax
801012ca:	74 05                	je     801012d1 <balloc+0x81>
801012cc:	3b 75 e0             	cmp    -0x20(%ebp),%esi
801012cf:	72 cf                	jb     801012a0 <balloc+0x50>
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
801012d1:	8b 7d d8             	mov    -0x28(%ebp),%edi
801012d4:	83 ec 0c             	sub    $0xc,%esp
801012d7:	ff 75 e4             	push   -0x1c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
801012da:	81 c7 00 10 00 00    	add    $0x1000,%edi
    brelse(bp);
801012e0:	e8 1b ef ff ff       	call   80100200 <brelse>
  for(b = 0; b < sb.size; b += BPB){
801012e5:	83 c4 10             	add    $0x10,%esp
801012e8:	3b 3d b4 15 11 80    	cmp    0x801115b4,%edi
801012ee:	0f 82 78 ff ff ff    	jb     8010126c <balloc+0x1c>
  }
  panic("balloc: out of blocks");
801012f4:	83 ec 0c             	sub    $0xc,%esp
801012f7:	68 4e 76 10 80       	push   $0x8010764e
801012fc:	e8 9f f0 ff ff       	call   801003a0 <panic>
80101301:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        bp->data[bi/8] |= m;  // Mark block in use.
80101308:	8b 7d e4             	mov    -0x1c(%ebp),%edi
        log_write(bp);
8010130b:	83 ec 0c             	sub    $0xc,%esp
        bp->data[bi/8] |= m;  // Mark block in use.
8010130e:	09 da                	or     %ebx,%edx
80101310:	88 54 0f 5c          	mov    %dl,0x5c(%edi,%ecx,1)
        log_write(bp);
80101314:	57                   	push   %edi
80101315:	e8 26 1e 00 00       	call   80103140 <log_write>
        brelse(bp);
8010131a:	89 3c 24             	mov    %edi,(%esp)
8010131d:	e8 de ee ff ff       	call   80100200 <brelse>
  bp = bread(dev, bno);
80101322:	58                   	pop    %eax
80101323:	5a                   	pop    %edx
80101324:	56                   	push   %esi
80101325:	ff 75 dc             	push   -0x24(%ebp)
80101328:	e8 a3 ed ff ff       	call   801000d0 <bread>
  memset(bp->data, 0, BSIZE);
8010132d:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, bno);
80101330:	89 c3                	mov    %eax,%ebx
  memset(bp->data, 0, BSIZE);
80101332:	8d 40 5c             	lea    0x5c(%eax),%eax
80101335:	68 00 02 00 00       	push   $0x200
8010133a:	6a 00                	push   $0x0
8010133c:	50                   	push   %eax
8010133d:	e8 5e 36 00 00       	call   801049a0 <memset>
  log_write(bp);
80101342:	89 1c 24             	mov    %ebx,(%esp)
80101345:	e8 f6 1d 00 00       	call   80103140 <log_write>
  brelse(bp);
8010134a:	89 1c 24             	mov    %ebx,(%esp)
8010134d:	e8 ae ee ff ff       	call   80100200 <brelse>
}
80101352:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101355:	89 f0                	mov    %esi,%eax
80101357:	5b                   	pop    %ebx
80101358:	5e                   	pop    %esi
80101359:	5f                   	pop    %edi
8010135a:	5d                   	pop    %ebp
8010135b:	c3                   	ret
8010135c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101360 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
80101360:	55                   	push   %ebp
80101361:	89 e5                	mov    %esp,%ebp
80101363:	57                   	push   %edi
80101364:	89 d7                	mov    %edx,%edi
80101366:	56                   	push   %esi
  struct inode *ip, *empty;

  acquire(&icache.lock);

  // Is the inode already cached?
  empty = 0;
80101367:	31 f6                	xor    %esi,%esi
{
80101369:	53                   	push   %ebx
8010136a:	89 c3                	mov    %eax,%ebx
8010136c:	83 ec 28             	sub    $0x28,%esp
  acquire(&icache.lock);
8010136f:	68 60 f9 10 80       	push   $0x8010f960
80101374:	e8 07 35 00 00       	call   80104880 <acquire>
80101379:	83 c4 10             	add    $0x10,%esp
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
8010137c:	b8 94 f9 10 80       	mov    $0x8010f994,%eax
80101381:	eb 19                	jmp    8010139c <iget+0x3c>
80101383:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101388:	39 18                	cmp    %ebx,(%eax)
8010138a:	0f 84 b0 00 00 00    	je     80101440 <iget+0xe0>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101390:	05 90 00 00 00       	add    $0x90,%eax
80101395:	3d b4 15 11 80       	cmp    $0x801115b4,%eax
8010139a:	74 24                	je     801013c0 <iget+0x60>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
8010139c:	8b 50 08             	mov    0x8(%eax),%edx
8010139f:	85 d2                	test   %edx,%edx
801013a1:	7f e5                	jg     80101388 <iget+0x28>
      ip->ref++;
      release(&icache.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
801013a3:	89 c1                	mov    %eax,%ecx
801013a5:	85 f6                	test   %esi,%esi
801013a7:	75 4f                	jne    801013f8 <iget+0x98>
801013a9:	85 d2                	test   %edx,%edx
801013ab:	0f 85 be 00 00 00    	jne    8010146f <iget+0x10f>
      empty = ip;
801013b1:	89 c6                	mov    %eax,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013b3:	05 90 00 00 00       	add    $0x90,%eax
801013b8:	3d b4 15 11 80       	cmp    $0x801115b4,%eax
801013bd:	75 dd                	jne    8010139c <iget+0x3c>
801013bf:	90                   	nop
  }

  // Recycle an inode cache entry.
  if(empty == 0)
801013c0:	85 f6                	test   %esi,%esi
801013c2:	0f 84 c3 00 00 00    	je     8010148b <iget+0x12b>
  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  release(&icache.lock);
801013c8:	83 ec 0c             	sub    $0xc,%esp
  ip->dev = dev;
801013cb:	89 1e                	mov    %ebx,(%esi)
  ip->inum = inum;
801013cd:	89 7e 04             	mov    %edi,0x4(%esi)
  ip->ref = 1;
801013d0:	c7 46 08 01 00 00 00 	movl   $0x1,0x8(%esi)
  ip->valid = 0;
801013d7:	c7 46 4c 00 00 00 00 	movl   $0x0,0x4c(%esi)
  release(&icache.lock);
801013de:	68 60 f9 10 80       	push   $0x8010f960
801013e3:	e8 38 34 00 00       	call   80104820 <release>

  return ip;
801013e8:	83 c4 10             	add    $0x10,%esp
}
801013eb:	8d 65 f4             	lea    -0xc(%ebp),%esp
801013ee:	89 f0                	mov    %esi,%eax
801013f0:	5b                   	pop    %ebx
801013f1:	5e                   	pop    %esi
801013f2:	5f                   	pop    %edi
801013f3:	5d                   	pop    %ebp
801013f4:	c3                   	ret
801013f5:	8d 76 00             	lea    0x0(%esi),%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013f8:	05 90 00 00 00       	add    $0x90,%eax
801013fd:	3d b4 15 11 80       	cmp    $0x801115b4,%eax
80101402:	74 c4                	je     801013c8 <iget+0x68>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101404:	8b 50 08             	mov    0x8(%eax),%edx
80101407:	85 d2                	test   %edx,%edx
80101409:	0f 8f 79 ff ff ff    	jg     80101388 <iget+0x28>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
8010140f:	8d 81 20 01 00 00    	lea    0x120(%ecx),%eax
80101415:	81 f9 94 14 11 80    	cmp    $0x80111494,%ecx
8010141b:	74 a3                	je     801013c0 <iget+0x60>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
8010141d:	8b 50 08             	mov    0x8(%eax),%edx
80101420:	85 d2                	test   %edx,%edx
80101422:	0f 8f 60 ff ff ff    	jg     80101388 <iget+0x28>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101428:	89 c1                	mov    %eax,%ecx
8010142a:	05 90 00 00 00       	add    $0x90,%eax
8010142f:	3d b4 15 11 80       	cmp    $0x801115b4,%eax
80101434:	75 ce                	jne    80101404 <iget+0xa4>
80101436:	eb 90                	jmp    801013c8 <iget+0x68>
80101438:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010143f:	00 
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101440:	39 78 04             	cmp    %edi,0x4(%eax)
80101443:	0f 85 47 ff ff ff    	jne    80101390 <iget+0x30>
      release(&icache.lock);
80101449:	83 ec 0c             	sub    $0xc,%esp
      ip->ref++;
8010144c:	83 c2 01             	add    $0x1,%edx
8010144f:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101452:	89 50 08             	mov    %edx,0x8(%eax)
      release(&icache.lock);
80101455:	68 60 f9 10 80       	push   $0x8010f960
8010145a:	e8 c1 33 00 00       	call   80104820 <release>
      return ip;
8010145f:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101462:	83 c4 10             	add    $0x10,%esp
}
80101465:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101468:	5b                   	pop    %ebx
80101469:	89 f0                	mov    %esi,%eax
8010146b:	5e                   	pop    %esi
8010146c:	5f                   	pop    %edi
8010146d:	5d                   	pop    %ebp
8010146e:	c3                   	ret
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
8010146f:	05 90 00 00 00       	add    $0x90,%eax
80101474:	3d b4 15 11 80       	cmp    $0x801115b4,%eax
80101479:	74 10                	je     8010148b <iget+0x12b>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
8010147b:	8b 50 08             	mov    0x8(%eax),%edx
8010147e:	85 d2                	test   %edx,%edx
80101480:	0f 8f 02 ff ff ff    	jg     80101388 <iget+0x28>
80101486:	e9 1e ff ff ff       	jmp    801013a9 <iget+0x49>
    panic("iget: no inodes");
8010148b:	83 ec 0c             	sub    $0xc,%esp
8010148e:	68 64 76 10 80       	push   $0x80107664
80101493:	e8 08 ef ff ff       	call   801003a0 <panic>
80101498:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010149f:	00 

801014a0 <bfree>:
{
801014a0:	55                   	push   %ebp
801014a1:	89 c1                	mov    %eax,%ecx
  bp = bread(dev, BBLOCK(b, sb));
801014a3:	89 d0                	mov    %edx,%eax
801014a5:	c1 e8 0c             	shr    $0xc,%eax
{
801014a8:	89 e5                	mov    %esp,%ebp
801014aa:	56                   	push   %esi
801014ab:	53                   	push   %ebx
  bp = bread(dev, BBLOCK(b, sb));
801014ac:	03 05 cc 15 11 80    	add    0x801115cc,%eax
{
801014b2:	89 d3                	mov    %edx,%ebx
  bp = bread(dev, BBLOCK(b, sb));
801014b4:	83 ec 08             	sub    $0x8,%esp
801014b7:	50                   	push   %eax
801014b8:	51                   	push   %ecx
801014b9:	e8 12 ec ff ff       	call   801000d0 <bread>
  m = 1 << (bi % 8);
801014be:	89 d9                	mov    %ebx,%ecx
  if((bp->data[bi/8] & m) == 0)
801014c0:	c1 fb 03             	sar    $0x3,%ebx
801014c3:	83 c4 10             	add    $0x10,%esp
  bp = bread(dev, BBLOCK(b, sb));
801014c6:	89 c6                	mov    %eax,%esi
  m = 1 << (bi % 8);
801014c8:	83 e1 07             	and    $0x7,%ecx
801014cb:	b8 01 00 00 00       	mov    $0x1,%eax
  if((bp->data[bi/8] & m) == 0)
801014d0:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
  m = 1 << (bi % 8);
801014d6:	d3 e0                	shl    %cl,%eax
  if((bp->data[bi/8] & m) == 0)
801014d8:	0f b6 4c 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%ecx
801014dd:	85 c1                	test   %eax,%ecx
801014df:	74 23                	je     80101504 <bfree+0x64>
  bp->data[bi/8] &= ~m;
801014e1:	f7 d0                	not    %eax
  log_write(bp);
801014e3:	83 ec 0c             	sub    $0xc,%esp
  bp->data[bi/8] &= ~m;
801014e6:	21 c8                	and    %ecx,%eax
801014e8:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
801014ec:	56                   	push   %esi
801014ed:	e8 4e 1c 00 00       	call   80103140 <log_write>
  brelse(bp);
801014f2:	89 34 24             	mov    %esi,(%esp)
801014f5:	e8 06 ed ff ff       	call   80100200 <brelse>
}
801014fa:	83 c4 10             	add    $0x10,%esp
801014fd:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101500:	5b                   	pop    %ebx
80101501:	5e                   	pop    %esi
80101502:	5d                   	pop    %ebp
80101503:	c3                   	ret
    panic("freeing free block");
80101504:	83 ec 0c             	sub    $0xc,%esp
80101507:	68 74 76 10 80       	push   $0x80107674
8010150c:	e8 8f ee ff ff       	call   801003a0 <panic>
80101511:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101518:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010151f:	00 

80101520 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80101520:	55                   	push   %ebp
80101521:	89 e5                	mov    %esp,%ebp
80101523:	56                   	push   %esi
80101524:	89 c6                	mov    %eax,%esi
80101526:	53                   	push   %ebx
80101527:	83 ec 10             	sub    $0x10,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
8010152a:	83 fa 0b             	cmp    $0xb,%edx
8010152d:	0f 86 8d 00 00 00    	jbe    801015c0 <bmap+0xa0>
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    return addr;
  }
  bn -= NDIRECT;
80101533:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
80101536:	83 fb 7f             	cmp    $0x7f,%ebx
80101539:	0f 87 a8 00 00 00    	ja     801015e7 <bmap+0xc7>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
8010153f:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101545:	85 c0                	test   %eax,%eax
80101547:	74 67                	je     801015b0 <bmap+0x90>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
80101549:	83 ec 08             	sub    $0x8,%esp
8010154c:	50                   	push   %eax
8010154d:	ff 36                	push   (%esi)
8010154f:	e8 7c eb ff ff       	call   801000d0 <bread>
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
80101554:	83 c4 10             	add    $0x10,%esp
80101557:	8d 4c 98 5c          	lea    0x5c(%eax,%ebx,4),%ecx
    bp = bread(ip->dev, addr);
8010155b:	89 c2                	mov    %eax,%edx
    if((addr = a[bn]) == 0){
8010155d:	8b 19                	mov    (%ecx),%ebx
8010155f:	85 db                	test   %ebx,%ebx
80101561:	74 1d                	je     80101580 <bmap+0x60>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
80101563:	83 ec 0c             	sub    $0xc,%esp
80101566:	52                   	push   %edx
80101567:	e8 94 ec ff ff       	call   80100200 <brelse>
8010156c:	83 c4 10             	add    $0x10,%esp
    return addr;
  }

  panic("bmap: out of range");
}
8010156f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101572:	89 d8                	mov    %ebx,%eax
80101574:	5b                   	pop    %ebx
80101575:	5e                   	pop    %esi
80101576:	5d                   	pop    %ebp
80101577:	c3                   	ret
80101578:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010157f:	00 
80101580:	89 45 f4             	mov    %eax,-0xc(%ebp)
      a[bn] = addr = balloc(ip->dev);
80101583:	8b 06                	mov    (%esi),%eax
80101585:	89 4d f0             	mov    %ecx,-0x10(%ebp)
80101588:	e8 c3 fc ff ff       	call   80101250 <balloc>
8010158d:	8b 4d f0             	mov    -0x10(%ebp),%ecx
      log_write(bp);
80101590:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101593:	83 ec 0c             	sub    $0xc,%esp
      a[bn] = addr = balloc(ip->dev);
80101596:	89 c3                	mov    %eax,%ebx
80101598:	89 01                	mov    %eax,(%ecx)
      log_write(bp);
8010159a:	52                   	push   %edx
8010159b:	e8 a0 1b 00 00       	call   80103140 <log_write>
801015a0:	8b 55 f4             	mov    -0xc(%ebp),%edx
801015a3:	83 c4 10             	add    $0x10,%esp
801015a6:	eb bb                	jmp    80101563 <bmap+0x43>
801015a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801015af:	00 
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801015b0:	8b 06                	mov    (%esi),%eax
801015b2:	e8 99 fc ff ff       	call   80101250 <balloc>
801015b7:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
801015bd:	eb 8a                	jmp    80101549 <bmap+0x29>
801015bf:	90                   	nop
    if((addr = ip->addrs[bn]) == 0)
801015c0:	83 c2 14             	add    $0x14,%edx
801015c3:	8b 5c 90 0c          	mov    0xc(%eax,%edx,4),%ebx
801015c7:	85 db                	test   %ebx,%ebx
801015c9:	75 a4                	jne    8010156f <bmap+0x4f>
      ip->addrs[bn] = addr = balloc(ip->dev);
801015cb:	8b 00                	mov    (%eax),%eax
801015cd:	89 55 f4             	mov    %edx,-0xc(%ebp)
801015d0:	e8 7b fc ff ff       	call   80101250 <balloc>
801015d5:	8b 55 f4             	mov    -0xc(%ebp),%edx
801015d8:	89 c3                	mov    %eax,%ebx
801015da:	89 44 96 0c          	mov    %eax,0xc(%esi,%edx,4)
}
801015de:	8d 65 f8             	lea    -0x8(%ebp),%esp
801015e1:	89 d8                	mov    %ebx,%eax
801015e3:	5b                   	pop    %ebx
801015e4:	5e                   	pop    %esi
801015e5:	5d                   	pop    %ebp
801015e6:	c3                   	ret
  panic("bmap: out of range");
801015e7:	83 ec 0c             	sub    $0xc,%esp
801015ea:	68 87 76 10 80       	push   $0x80107687
801015ef:	e8 ac ed ff ff       	call   801003a0 <panic>
801015f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801015f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801015ff:	00 

80101600 <readsb>:
{
80101600:	55                   	push   %ebp
80101601:	89 e5                	mov    %esp,%ebp
80101603:	56                   	push   %esi
80101604:	53                   	push   %ebx
80101605:	8b 75 0c             	mov    0xc(%ebp),%esi
  bp = bread(dev, 1);
80101608:	83 ec 08             	sub    $0x8,%esp
8010160b:	6a 01                	push   $0x1
8010160d:	ff 75 08             	push   0x8(%ebp)
80101610:	e8 bb ea ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
80101615:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
80101618:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
8010161a:	8d 40 5c             	lea    0x5c(%eax),%eax
8010161d:	6a 1c                	push   $0x1c
8010161f:	50                   	push   %eax
80101620:	56                   	push   %esi
80101621:	e8 0a 34 00 00       	call   80104a30 <memmove>
  brelse(bp);
80101626:	83 c4 10             	add    $0x10,%esp
80101629:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010162c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010162f:	5b                   	pop    %ebx
80101630:	5e                   	pop    %esi
80101631:	5d                   	pop    %ebp
  brelse(bp);
80101632:	e9 c9 eb ff ff       	jmp    80100200 <brelse>
80101637:	90                   	nop
80101638:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010163f:	00 

80101640 <iinit>:
{
80101640:	55                   	push   %ebp
80101641:	89 e5                	mov    %esp,%ebp
80101643:	53                   	push   %ebx
80101644:	bb a0 f9 10 80       	mov    $0x8010f9a0,%ebx
80101649:	83 ec 0c             	sub    $0xc,%esp
  initlock(&icache.lock, "icache");
8010164c:	68 9a 76 10 80       	push   $0x8010769a
80101651:	68 60 f9 10 80       	push   $0x8010f960
80101656:	e8 05 30 00 00       	call   80104660 <initlock>
  for(i = 0; i < NINODE; i++) {
8010165b:	83 c4 10             	add    $0x10,%esp
8010165e:	66 90                	xchg   %ax,%ax
    initsleeplock(&icache.inode[i].lock, "inode");
80101660:	83 ec 08             	sub    $0x8,%esp
80101663:	68 a1 76 10 80       	push   $0x801076a1
80101668:	53                   	push   %ebx
  for(i = 0; i < NINODE; i++) {
80101669:	81 c3 90 00 00 00    	add    $0x90,%ebx
    initsleeplock(&icache.inode[i].lock, "inode");
8010166f:	e8 bc 2e 00 00       	call   80104530 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
80101674:	83 c4 10             	add    $0x10,%esp
80101677:	81 fb c0 15 11 80    	cmp    $0x801115c0,%ebx
8010167d:	75 e1                	jne    80101660 <iinit+0x20>
  bp = bread(dev, 1);
8010167f:	83 ec 08             	sub    $0x8,%esp
80101682:	6a 01                	push   $0x1
80101684:	ff 75 08             	push   0x8(%ebp)
80101687:	e8 44 ea ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
8010168c:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
8010168f:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
80101691:	8d 40 5c             	lea    0x5c(%eax),%eax
80101694:	6a 1c                	push   $0x1c
80101696:	50                   	push   %eax
80101697:	68 b4 15 11 80       	push   $0x801115b4
8010169c:	e8 8f 33 00 00       	call   80104a30 <memmove>
  brelse(bp);
801016a1:	89 1c 24             	mov    %ebx,(%esp)
801016a4:	e8 57 eb ff ff       	call   80100200 <brelse>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
801016a9:	ff 35 cc 15 11 80    	push   0x801115cc
801016af:	ff 35 c8 15 11 80    	push   0x801115c8
801016b5:	ff 35 c4 15 11 80    	push   0x801115c4
801016bb:	ff 35 c0 15 11 80    	push   0x801115c0
801016c1:	ff 35 bc 15 11 80    	push   0x801115bc
801016c7:	ff 35 b8 15 11 80    	push   0x801115b8
801016cd:	ff 35 b4 15 11 80    	push   0x801115b4
801016d3:	68 b4 7a 10 80       	push   $0x80107ab4
801016d8:	e8 f3 ef ff ff       	call   801006d0 <cprintf>
}
801016dd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801016e0:	83 c4 30             	add    $0x30,%esp
801016e3:	c9                   	leave
801016e4:	c3                   	ret
801016e5:	8d 76 00             	lea    0x0(%esi),%esi
801016e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801016ef:	00 

801016f0 <ialloc>:
{
801016f0:	55                   	push   %ebp
801016f1:	89 e5                	mov    %esp,%ebp
801016f3:	57                   	push   %edi
801016f4:	56                   	push   %esi
801016f5:	53                   	push   %ebx
801016f6:	83 ec 1c             	sub    $0x1c,%esp
801016f9:	8b 45 0c             	mov    0xc(%ebp),%eax
801016fc:	8b 75 08             	mov    0x8(%ebp),%esi
801016ff:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
80101702:	83 3d bc 15 11 80 01 	cmpl   $0x1,0x801115bc
80101709:	0f 86 91 00 00 00    	jbe    801017a0 <ialloc+0xb0>
8010170f:	bf 01 00 00 00       	mov    $0x1,%edi
80101714:	eb 21                	jmp    80101737 <ialloc+0x47>
80101716:	66 90                	xchg   %ax,%ax
80101718:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010171f:	00 
    brelse(bp);
80101720:	83 ec 0c             	sub    $0xc,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
80101723:	83 c7 01             	add    $0x1,%edi
    brelse(bp);
80101726:	53                   	push   %ebx
80101727:	e8 d4 ea ff ff       	call   80100200 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
8010172c:	83 c4 10             	add    $0x10,%esp
8010172f:	3b 3d bc 15 11 80    	cmp    0x801115bc,%edi
80101735:	73 69                	jae    801017a0 <ialloc+0xb0>
    bp = bread(dev, IBLOCK(inum, sb));
80101737:	89 f8                	mov    %edi,%eax
80101739:	83 ec 08             	sub    $0x8,%esp
8010173c:	c1 e8 03             	shr    $0x3,%eax
8010173f:	03 05 c8 15 11 80    	add    0x801115c8,%eax
80101745:	50                   	push   %eax
80101746:	56                   	push   %esi
80101747:	e8 84 e9 ff ff       	call   801000d0 <bread>
    if(dip->type == 0){  // a free inode
8010174c:	83 c4 10             	add    $0x10,%esp
    bp = bread(dev, IBLOCK(inum, sb));
8010174f:	89 c3                	mov    %eax,%ebx
    dip = (struct dinode*)bp->data + inum%IPB;
80101751:	89 f8                	mov    %edi,%eax
80101753:	83 e0 07             	and    $0x7,%eax
80101756:	c1 e0 06             	shl    $0x6,%eax
80101759:	8d 4c 03 5c          	lea    0x5c(%ebx,%eax,1),%ecx
    if(dip->type == 0){  // a free inode
8010175d:	66 83 39 00          	cmpw   $0x0,(%ecx)
80101761:	75 bd                	jne    80101720 <ialloc+0x30>
      memset(dip, 0, sizeof(*dip));
80101763:	83 ec 04             	sub    $0x4,%esp
80101766:	6a 40                	push   $0x40
80101768:	6a 00                	push   $0x0
8010176a:	51                   	push   %ecx
8010176b:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010176e:	e8 2d 32 00 00       	call   801049a0 <memset>
      dip->type = type;
80101773:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
80101777:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010177a:	66 89 01             	mov    %ax,(%ecx)
      log_write(bp);   // mark it allocated on the disk
8010177d:	89 1c 24             	mov    %ebx,(%esp)
80101780:	e8 bb 19 00 00       	call   80103140 <log_write>
      brelse(bp);
80101785:	89 1c 24             	mov    %ebx,(%esp)
80101788:	e8 73 ea ff ff       	call   80100200 <brelse>
      return iget(dev, inum);
8010178d:	83 c4 10             	add    $0x10,%esp
}
80101790:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return iget(dev, inum);
80101793:	89 fa                	mov    %edi,%edx
}
80101795:	5b                   	pop    %ebx
      return iget(dev, inum);
80101796:	89 f0                	mov    %esi,%eax
}
80101798:	5e                   	pop    %esi
80101799:	5f                   	pop    %edi
8010179a:	5d                   	pop    %ebp
      return iget(dev, inum);
8010179b:	e9 c0 fb ff ff       	jmp    80101360 <iget>
  panic("ialloc: no inodes");
801017a0:	83 ec 0c             	sub    $0xc,%esp
801017a3:	68 a7 76 10 80       	push   $0x801076a7
801017a8:	e8 f3 eb ff ff       	call   801003a0 <panic>
801017ad:	8d 76 00             	lea    0x0(%esi),%esi

801017b0 <iupdate>:
{
801017b0:	55                   	push   %ebp
801017b1:	89 e5                	mov    %esp,%ebp
801017b3:	56                   	push   %esi
801017b4:	53                   	push   %ebx
801017b5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017b8:	8b 43 04             	mov    0x4(%ebx),%eax
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017bb:	83 c3 5c             	add    $0x5c,%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017be:	83 ec 08             	sub    $0x8,%esp
801017c1:	c1 e8 03             	shr    $0x3,%eax
801017c4:	03 05 c8 15 11 80    	add    0x801115c8,%eax
801017ca:	50                   	push   %eax
801017cb:	ff 73 a4             	push   -0x5c(%ebx)
801017ce:	e8 fd e8 ff ff       	call   801000d0 <bread>
  dip->type = ip->type;
801017d3:	0f b7 53 f4          	movzwl -0xc(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801017d7:	83 c4 0c             	add    $0xc,%esp
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017da:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
801017dc:	8b 43 a8             	mov    -0x58(%ebx),%eax
801017df:	83 e0 07             	and    $0x7,%eax
801017e2:	c1 e0 06             	shl    $0x6,%eax
  dip->type = ip->type;
801017e5:	66 89 54 06 5c       	mov    %dx,0x5c(%esi,%eax,1)
  dip->major = ip->major;
801017ea:	0f b7 53 f6          	movzwl -0xa(%ebx),%edx
801017ee:	66 89 54 06 5e       	mov    %dx,0x5e(%esi,%eax,1)
  dip->minor = ip->minor;
801017f3:	0f b7 53 f8          	movzwl -0x8(%ebx),%edx
801017f7:	66 89 54 06 60       	mov    %dx,0x60(%esi,%eax,1)
  dip->nlink = ip->nlink;
801017fc:	0f b7 53 fa          	movzwl -0x6(%ebx),%edx
80101800:	66 89 54 06 62       	mov    %dx,0x62(%esi,%eax,1)
  dip->size = ip->size;
80101805:	8b 53 fc             	mov    -0x4(%ebx),%edx
80101808:	89 54 06 64          	mov    %edx,0x64(%esi,%eax,1)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010180c:	8d 44 06 68          	lea    0x68(%esi,%eax,1),%eax
80101810:	6a 34                	push   $0x34
80101812:	53                   	push   %ebx
80101813:	50                   	push   %eax
80101814:	e8 17 32 00 00       	call   80104a30 <memmove>
  log_write(bp);
80101819:	89 34 24             	mov    %esi,(%esp)
8010181c:	e8 1f 19 00 00       	call   80103140 <log_write>
  brelse(bp);
80101821:	83 c4 10             	add    $0x10,%esp
80101824:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101827:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010182a:	5b                   	pop    %ebx
8010182b:	5e                   	pop    %esi
8010182c:	5d                   	pop    %ebp
  brelse(bp);
8010182d:	e9 ce e9 ff ff       	jmp    80100200 <brelse>
80101832:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101838:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010183f:	00 

80101840 <idup>:
{
80101840:	55                   	push   %ebp
80101841:	89 e5                	mov    %esp,%ebp
80101843:	53                   	push   %ebx
80101844:	83 ec 10             	sub    $0x10,%esp
80101847:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
8010184a:	68 60 f9 10 80       	push   $0x8010f960
8010184f:	e8 2c 30 00 00       	call   80104880 <acquire>
  ip->ref++;
80101854:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
80101858:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
8010185f:	e8 bc 2f 00 00       	call   80104820 <release>
}
80101864:	89 d8                	mov    %ebx,%eax
80101866:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101869:	c9                   	leave
8010186a:	c3                   	ret
8010186b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101870 <ilock>:
{
80101870:	55                   	push   %ebp
80101871:	89 e5                	mov    %esp,%ebp
80101873:	53                   	push   %ebx
80101874:	83 ec 14             	sub    $0x14,%esp
80101877:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
8010187a:	85 db                	test   %ebx,%ebx
8010187c:	0f 84 bb 00 00 00    	je     8010193d <ilock+0xcd>
80101882:	8b 53 08             	mov    0x8(%ebx),%edx
80101885:	85 d2                	test   %edx,%edx
80101887:	0f 8e b0 00 00 00    	jle    8010193d <ilock+0xcd>
  acquiresleep(&ip->lock);
8010188d:	83 ec 0c             	sub    $0xc,%esp
80101890:	8d 43 0c             	lea    0xc(%ebx),%eax
80101893:	50                   	push   %eax
80101894:	e8 d7 2c 00 00       	call   80104570 <acquiresleep>
  if(ip->valid == 0){
80101899:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010189c:	83 c4 10             	add    $0x10,%esp
8010189f:	85 c0                	test   %eax,%eax
801018a1:	74 0d                	je     801018b0 <ilock+0x40>
}
801018a3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801018a6:	c9                   	leave
801018a7:	c3                   	ret
801018a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801018af:	00 
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801018b0:	8b 43 04             	mov    0x4(%ebx),%eax
801018b3:	83 ec 08             	sub    $0x8,%esp
801018b6:	c1 e8 03             	shr    $0x3,%eax
801018b9:	03 05 c8 15 11 80    	add    0x801115c8,%eax
801018bf:	50                   	push   %eax
801018c0:	ff 33                	push   (%ebx)
801018c2:	e8 09 e8 ff ff       	call   801000d0 <bread>
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018c7:	83 c4 0c             	add    $0xc,%esp
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801018ca:	89 c2                	mov    %eax,%edx
    dip = (struct dinode*)bp->data + ip->inum%IPB;
801018cc:	8b 43 04             	mov    0x4(%ebx),%eax
801018cf:	89 55 f4             	mov    %edx,-0xc(%ebp)
801018d2:	83 e0 07             	and    $0x7,%eax
801018d5:	c1 e0 06             	shl    $0x6,%eax
801018d8:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    ip->type = dip->type;
801018dc:	0f b7 08             	movzwl (%eax),%ecx
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801018df:	83 c0 0c             	add    $0xc,%eax
    ip->type = dip->type;
801018e2:	66 89 4b 50          	mov    %cx,0x50(%ebx)
    ip->major = dip->major;
801018e6:	0f b7 48 f6          	movzwl -0xa(%eax),%ecx
801018ea:	66 89 4b 52          	mov    %cx,0x52(%ebx)
    ip->minor = dip->minor;
801018ee:	0f b7 48 f8          	movzwl -0x8(%eax),%ecx
801018f2:	66 89 4b 54          	mov    %cx,0x54(%ebx)
    ip->nlink = dip->nlink;
801018f6:	0f b7 48 fa          	movzwl -0x6(%eax),%ecx
801018fa:	66 89 4b 56          	mov    %cx,0x56(%ebx)
    ip->size = dip->size;
801018fe:	8b 48 fc             	mov    -0x4(%eax),%ecx
80101901:	89 4b 58             	mov    %ecx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
80101904:	6a 34                	push   $0x34
80101906:	50                   	push   %eax
80101907:	8d 43 5c             	lea    0x5c(%ebx),%eax
8010190a:	50                   	push   %eax
8010190b:	e8 20 31 00 00       	call   80104a30 <memmove>
    brelse(bp);
80101910:	8b 55 f4             	mov    -0xc(%ebp),%edx
80101913:	89 14 24             	mov    %edx,(%esp)
80101916:	e8 e5 e8 ff ff       	call   80100200 <brelse>
    ip->valid = 1;
8010191b:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
80101922:	83 c4 10             	add    $0x10,%esp
80101925:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
8010192a:	0f 85 73 ff ff ff    	jne    801018a3 <ilock+0x33>
      panic("ilock: no type");
80101930:	83 ec 0c             	sub    $0xc,%esp
80101933:	68 bf 76 10 80       	push   $0x801076bf
80101938:	e8 63 ea ff ff       	call   801003a0 <panic>
    panic("ilock");
8010193d:	83 ec 0c             	sub    $0xc,%esp
80101940:	68 b9 76 10 80       	push   $0x801076b9
80101945:	e8 56 ea ff ff       	call   801003a0 <panic>
8010194a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101950 <iunlock>:
{
80101950:	55                   	push   %ebp
80101951:	89 e5                	mov    %esp,%ebp
80101953:	56                   	push   %esi
80101954:	53                   	push   %ebx
80101955:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101958:	85 db                	test   %ebx,%ebx
8010195a:	74 28                	je     80101984 <iunlock+0x34>
8010195c:	83 ec 0c             	sub    $0xc,%esp
8010195f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101962:	56                   	push   %esi
80101963:	e8 a8 2c 00 00       	call   80104610 <holdingsleep>
80101968:	83 c4 10             	add    $0x10,%esp
8010196b:	85 c0                	test   %eax,%eax
8010196d:	74 15                	je     80101984 <iunlock+0x34>
8010196f:	8b 43 08             	mov    0x8(%ebx),%eax
80101972:	85 c0                	test   %eax,%eax
80101974:	7e 0e                	jle    80101984 <iunlock+0x34>
  releasesleep(&ip->lock);
80101976:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101979:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010197c:	5b                   	pop    %ebx
8010197d:	5e                   	pop    %esi
8010197e:	5d                   	pop    %ebp
  releasesleep(&ip->lock);
8010197f:	e9 4c 2c 00 00       	jmp    801045d0 <releasesleep>
    panic("iunlock");
80101984:	83 ec 0c             	sub    $0xc,%esp
80101987:	68 ce 76 10 80       	push   $0x801076ce
8010198c:	e8 0f ea ff ff       	call   801003a0 <panic>
80101991:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101998:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010199f:	00 

801019a0 <iput>:
{
801019a0:	55                   	push   %ebp
801019a1:	89 e5                	mov    %esp,%ebp
801019a3:	57                   	push   %edi
801019a4:	56                   	push   %esi
801019a5:	53                   	push   %ebx
801019a6:	83 ec 28             	sub    $0x28,%esp
801019a9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquiresleep(&ip->lock);
801019ac:	8d 73 0c             	lea    0xc(%ebx),%esi
801019af:	56                   	push   %esi
801019b0:	e8 bb 2b 00 00       	call   80104570 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
801019b5:	8b 53 4c             	mov    0x4c(%ebx),%edx
801019b8:	83 c4 10             	add    $0x10,%esp
801019bb:	85 d2                	test   %edx,%edx
801019bd:	74 07                	je     801019c6 <iput+0x26>
801019bf:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
801019c4:	74 32                	je     801019f8 <iput+0x58>
  releasesleep(&ip->lock);
801019c6:	83 ec 0c             	sub    $0xc,%esp
801019c9:	56                   	push   %esi
801019ca:	e8 01 2c 00 00       	call   801045d0 <releasesleep>
  acquire(&icache.lock);
801019cf:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
801019d6:	e8 a5 2e 00 00       	call   80104880 <acquire>
  ip->ref--;
801019db:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
801019df:	83 c4 10             	add    $0x10,%esp
801019e2:	c7 45 08 60 f9 10 80 	movl   $0x8010f960,0x8(%ebp)
}
801019e9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801019ec:	5b                   	pop    %ebx
801019ed:	5e                   	pop    %esi
801019ee:	5f                   	pop    %edi
801019ef:	5d                   	pop    %ebp
  release(&icache.lock);
801019f0:	e9 2b 2e 00 00       	jmp    80104820 <release>
801019f5:	8d 76 00             	lea    0x0(%esi),%esi
    acquire(&icache.lock);
801019f8:	83 ec 0c             	sub    $0xc,%esp
801019fb:	68 60 f9 10 80       	push   $0x8010f960
80101a00:	e8 7b 2e 00 00       	call   80104880 <acquire>
    int r = ip->ref;
80101a05:	8b 7b 08             	mov    0x8(%ebx),%edi
    release(&icache.lock);
80101a08:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
80101a0f:	e8 0c 2e 00 00       	call   80104820 <release>
    if(r == 1){
80101a14:	83 c4 10             	add    $0x10,%esp
80101a17:	83 ff 01             	cmp    $0x1,%edi
80101a1a:	75 aa                	jne    801019c6 <iput+0x26>
80101a1c:	89 f7                	mov    %esi,%edi
80101a1e:	89 d9                	mov    %ebx,%ecx
80101a20:	8d b3 8c 00 00 00    	lea    0x8c(%ebx),%esi
80101a26:	83 c3 5c             	add    $0x5c,%ebx
80101a29:	eb 0c                	jmp    80101a37 <iput+0x97>
80101a2b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101a30:	83 c3 04             	add    $0x4,%ebx
80101a33:	39 f3                	cmp    %esi,%ebx
80101a35:	74 21                	je     80101a58 <iput+0xb8>
    if(ip->addrs[i]){
80101a37:	8b 13                	mov    (%ebx),%edx
80101a39:	85 d2                	test   %edx,%edx
80101a3b:	74 f3                	je     80101a30 <iput+0x90>
      bfree(ip->dev, ip->addrs[i]);
80101a3d:	8b 01                	mov    (%ecx),%eax
80101a3f:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80101a42:	e8 59 fa ff ff       	call   801014a0 <bfree>
      ip->addrs[i] = 0;
80101a47:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80101a4d:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101a50:	eb de                	jmp    80101a30 <iput+0x90>
80101a52:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80101a58:	8b 81 8c 00 00 00    	mov    0x8c(%ecx),%eax
80101a5e:	89 fe                	mov    %edi,%esi
80101a60:	89 cb                	mov    %ecx,%ebx
80101a62:	85 c0                	test   %eax,%eax
80101a64:	75 2d                	jne    80101a93 <iput+0xf3>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
  iupdate(ip);
80101a66:	83 ec 0c             	sub    $0xc,%esp
  ip->size = 0;
80101a69:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
80101a70:	53                   	push   %ebx
80101a71:	e8 3a fd ff ff       	call   801017b0 <iupdate>
      ip->type = 0;
80101a76:	31 c0                	xor    %eax,%eax
80101a78:	66 89 43 50          	mov    %ax,0x50(%ebx)
      iupdate(ip);
80101a7c:	89 1c 24             	mov    %ebx,(%esp)
80101a7f:	e8 2c fd ff ff       	call   801017b0 <iupdate>
      ip->valid = 0;
80101a84:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
80101a8b:	83 c4 10             	add    $0x10,%esp
80101a8e:	e9 33 ff ff ff       	jmp    801019c6 <iput+0x26>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
80101a93:	83 ec 08             	sub    $0x8,%esp
80101a96:	50                   	push   %eax
80101a97:	ff 31                	push   (%ecx)
80101a99:	e8 32 e6 ff ff       	call   801000d0 <bread>
    for(j = 0; j < NINDIRECT; j++){
80101a9e:	83 c4 10             	add    $0x10,%esp
80101aa1:	89 d9                	mov    %ebx,%ecx
80101aa3:	89 7d e0             	mov    %edi,-0x20(%ebp)
80101aa6:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101aa9:	8d 70 5c             	lea    0x5c(%eax),%esi
80101aac:	8d 98 5c 02 00 00    	lea    0x25c(%eax),%ebx
80101ab2:	eb 13                	jmp    80101ac7 <iput+0x127>
80101ab4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101abf:	00 
80101ac0:	83 c6 04             	add    $0x4,%esi
80101ac3:	39 de                	cmp    %ebx,%esi
80101ac5:	74 15                	je     80101adc <iput+0x13c>
      if(a[j])
80101ac7:	8b 16                	mov    (%esi),%edx
80101ac9:	85 d2                	test   %edx,%edx
80101acb:	74 f3                	je     80101ac0 <iput+0x120>
        bfree(ip->dev, a[j]);
80101acd:	8b 01                	mov    (%ecx),%eax
80101acf:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80101ad2:	e8 c9 f9 ff ff       	call   801014a0 <bfree>
80101ad7:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101ada:	eb e4                	jmp    80101ac0 <iput+0x120>
    brelse(bp);
80101adc:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101adf:	83 ec 0c             	sub    $0xc,%esp
80101ae2:	8b 75 e0             	mov    -0x20(%ebp),%esi
80101ae5:	89 cb                	mov    %ecx,%ebx
80101ae7:	50                   	push   %eax
80101ae8:	e8 13 e7 ff ff       	call   80100200 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101aed:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
80101af3:	8b 03                	mov    (%ebx),%eax
80101af5:	e8 a6 f9 ff ff       	call   801014a0 <bfree>
    ip->addrs[NDIRECT] = 0;
80101afa:	83 c4 10             	add    $0x10,%esp
80101afd:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
80101b04:	00 00 00 
80101b07:	e9 5a ff ff ff       	jmp    80101a66 <iput+0xc6>
80101b0c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101b10 <iunlockput>:
{
80101b10:	55                   	push   %ebp
80101b11:	89 e5                	mov    %esp,%ebp
80101b13:	56                   	push   %esi
80101b14:	53                   	push   %ebx
80101b15:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101b18:	85 db                	test   %ebx,%ebx
80101b1a:	74 34                	je     80101b50 <iunlockput+0x40>
80101b1c:	83 ec 0c             	sub    $0xc,%esp
80101b1f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101b22:	56                   	push   %esi
80101b23:	e8 e8 2a 00 00       	call   80104610 <holdingsleep>
80101b28:	83 c4 10             	add    $0x10,%esp
80101b2b:	85 c0                	test   %eax,%eax
80101b2d:	74 21                	je     80101b50 <iunlockput+0x40>
80101b2f:	8b 43 08             	mov    0x8(%ebx),%eax
80101b32:	85 c0                	test   %eax,%eax
80101b34:	7e 1a                	jle    80101b50 <iunlockput+0x40>
  releasesleep(&ip->lock);
80101b36:	83 ec 0c             	sub    $0xc,%esp
80101b39:	56                   	push   %esi
80101b3a:	e8 91 2a 00 00       	call   801045d0 <releasesleep>
  iput(ip);
80101b3f:	83 c4 10             	add    $0x10,%esp
80101b42:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80101b45:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101b48:	5b                   	pop    %ebx
80101b49:	5e                   	pop    %esi
80101b4a:	5d                   	pop    %ebp
  iput(ip);
80101b4b:	e9 50 fe ff ff       	jmp    801019a0 <iput>
    panic("iunlock");
80101b50:	83 ec 0c             	sub    $0xc,%esp
80101b53:	68 ce 76 10 80       	push   $0x801076ce
80101b58:	e8 43 e8 ff ff       	call   801003a0 <panic>
80101b5d:	8d 76 00             	lea    0x0(%esi),%esi

80101b60 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80101b60:	55                   	push   %ebp
80101b61:	89 e5                	mov    %esp,%ebp
80101b63:	8b 55 08             	mov    0x8(%ebp),%edx
80101b66:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101b69:	8b 0a                	mov    (%edx),%ecx
80101b6b:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
80101b6e:	8b 4a 04             	mov    0x4(%edx),%ecx
80101b71:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80101b74:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80101b78:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
80101b7b:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
80101b7f:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80101b83:	8b 52 58             	mov    0x58(%edx),%edx
80101b86:	89 50 10             	mov    %edx,0x10(%eax)
}
80101b89:	5d                   	pop    %ebp
80101b8a:	c3                   	ret
80101b8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101b90 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
80101b90:	55                   	push   %ebp
80101b91:	89 e5                	mov    %esp,%ebp
80101b93:	57                   	push   %edi
80101b94:	56                   	push   %esi
80101b95:	53                   	push   %ebx
80101b96:	83 ec 1c             	sub    $0x1c,%esp
80101b99:	8b 45 0c             	mov    0xc(%ebp),%eax
80101b9c:	8b 75 08             	mov    0x8(%ebp),%esi
80101b9f:	8b 7d 10             	mov    0x10(%ebp),%edi
80101ba2:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101ba5:	8b 45 14             	mov    0x14(%ebp),%eax
80101ba8:	89 75 d8             	mov    %esi,-0x28(%ebp)
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101bab:	66 83 7e 50 03       	cmpw   $0x3,0x50(%esi)
80101bb0:	0f 84 aa 00 00 00    	je     80101c60 <readi+0xd0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80101bb6:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101bb9:	8b 56 58             	mov    0x58(%esi),%edx
80101bbc:	39 fa                	cmp    %edi,%edx
80101bbe:	0f 82 bd 00 00 00    	jb     80101c81 <readi+0xf1>
80101bc4:	89 f9                	mov    %edi,%ecx
80101bc6:	31 db                	xor    %ebx,%ebx
80101bc8:	01 c1                	add    %eax,%ecx
80101bca:	0f 92 c3             	setb   %bl
80101bcd:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80101bd0:	0f 82 ab 00 00 00    	jb     80101c81 <readi+0xf1>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
80101bd6:	89 d3                	mov    %edx,%ebx
80101bd8:	29 fb                	sub    %edi,%ebx
80101bda:	39 ca                	cmp    %ecx,%edx
80101bdc:	0f 42 c3             	cmovb  %ebx,%eax

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101bdf:	85 c0                	test   %eax,%eax
80101be1:	74 73                	je     80101c56 <readi+0xc6>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101be3:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101be6:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101be9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101bf0:	8b 5d d8             	mov    -0x28(%ebp),%ebx
80101bf3:	89 fa                	mov    %edi,%edx
80101bf5:	c1 ea 09             	shr    $0x9,%edx
80101bf8:	89 d8                	mov    %ebx,%eax
80101bfa:	e8 21 f9 ff ff       	call   80101520 <bmap>
80101bff:	83 ec 08             	sub    $0x8,%esp
80101c02:	50                   	push   %eax
80101c03:	ff 33                	push   (%ebx)
80101c05:	e8 c6 e4 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101c0a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101c0d:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101c12:	89 c2                	mov    %eax,%edx
    m = min(n - tot, BSIZE - off%BSIZE);
80101c14:	89 f8                	mov    %edi,%eax
80101c16:	25 ff 01 00 00       	and    $0x1ff,%eax
80101c1b:	29 f3                	sub    %esi,%ebx
80101c1d:	29 c1                	sub    %eax,%ecx
    memmove(dst, bp->data + off%BSIZE, m);
80101c1f:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101c23:	39 d9                	cmp    %ebx,%ecx
80101c25:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
80101c28:	83 c4 0c             	add    $0xc,%esp
80101c2b:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101c2c:	01 de                	add    %ebx,%esi
80101c2e:	01 df                	add    %ebx,%edi
    memmove(dst, bp->data + off%BSIZE, m);
80101c30:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101c33:	50                   	push   %eax
80101c34:	ff 75 e0             	push   -0x20(%ebp)
80101c37:	e8 f4 2d 00 00       	call   80104a30 <memmove>
    brelse(bp);
80101c3c:	8b 55 dc             	mov    -0x24(%ebp),%edx
80101c3f:	89 14 24             	mov    %edx,(%esp)
80101c42:	e8 b9 e5 ff ff       	call   80100200 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101c47:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101c4a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101c4d:	83 c4 10             	add    $0x10,%esp
80101c50:	39 de                	cmp    %ebx,%esi
80101c52:	72 9c                	jb     80101bf0 <readi+0x60>
80101c54:	89 d8                	mov    %ebx,%eax
  }
  return n;
}
80101c56:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c59:	5b                   	pop    %ebx
80101c5a:	5e                   	pop    %esi
80101c5b:	5f                   	pop    %edi
80101c5c:	5d                   	pop    %ebp
80101c5d:	c3                   	ret
80101c5e:	66 90                	xchg   %ax,%ax
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101c60:	0f bf 56 52          	movswl 0x52(%esi),%edx
80101c64:	66 83 fa 09          	cmp    $0x9,%dx
80101c68:	77 17                	ja     80101c81 <readi+0xf1>
80101c6a:	8b 14 d5 00 f9 10 80 	mov    -0x7fef0700(,%edx,8),%edx
80101c71:	85 d2                	test   %edx,%edx
80101c73:	74 0c                	je     80101c81 <readi+0xf1>
    return devsw[ip->major].read(ip, dst, n);
80101c75:	89 45 10             	mov    %eax,0x10(%ebp)
}
80101c78:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c7b:	5b                   	pop    %ebx
80101c7c:	5e                   	pop    %esi
80101c7d:	5f                   	pop    %edi
80101c7e:	5d                   	pop    %ebp
    return devsw[ip->major].read(ip, dst, n);
80101c7f:	ff e2                	jmp    *%edx
      return -1;
80101c81:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101c86:	eb ce                	jmp    80101c56 <readi+0xc6>
80101c88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101c8f:	00 

80101c90 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80101c90:	55                   	push   %ebp
80101c91:	89 e5                	mov    %esp,%ebp
80101c93:	57                   	push   %edi
80101c94:	56                   	push   %esi
80101c95:	53                   	push   %ebx
80101c96:	83 ec 1c             	sub    $0x1c,%esp
80101c99:	8b 7d 0c             	mov    0xc(%ebp),%edi
80101c9c:	8b 75 14             	mov    0x14(%ebp),%esi
80101c9f:	8b 45 08             	mov    0x8(%ebp),%eax
80101ca2:	89 7d dc             	mov    %edi,-0x24(%ebp)
80101ca5:	8b 7d 10             	mov    0x10(%ebp),%edi
80101ca8:	89 75 e0             	mov    %esi,-0x20(%ebp)
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101cab:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
80101cb0:	0f 84 ba 00 00 00    	je     80101d70 <writei+0xe0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80101cb6:	39 78 58             	cmp    %edi,0x58(%eax)
80101cb9:	0f 82 ea 00 00 00    	jb     80101da9 <writei+0x119>
    return -1;
  if(off + n > MAXFILE*BSIZE)
80101cbf:	8b 75 e0             	mov    -0x20(%ebp),%esi
80101cc2:	89 f2                	mov    %esi,%edx
80101cc4:	01 fa                	add    %edi,%edx
80101cc6:	0f 82 dd 00 00 00    	jb     80101da9 <writei+0x119>
80101ccc:	81 fa 00 18 01 00    	cmp    $0x11800,%edx
80101cd2:	0f 87 d1 00 00 00    	ja     80101da9 <writei+0x119>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101cd8:	85 f6                	test   %esi,%esi
80101cda:	0f 84 81 00 00 00    	je     80101d61 <writei+0xd1>
80101ce0:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101ce7:	89 45 d8             	mov    %eax,-0x28(%ebp)
80101cea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101cf0:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101cf3:	89 fa                	mov    %edi,%edx
80101cf5:	c1 ea 09             	shr    $0x9,%edx
80101cf8:	89 f0                	mov    %esi,%eax
80101cfa:	e8 21 f8 ff ff       	call   80101520 <bmap>
80101cff:	83 ec 08             	sub    $0x8,%esp
80101d02:	50                   	push   %eax
80101d03:	ff 36                	push   (%esi)
80101d05:	e8 c6 e3 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101d0a:	b9 00 02 00 00       	mov    $0x200,%ecx
80101d0f:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101d12:	2b 5d e4             	sub    -0x1c(%ebp),%ebx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101d15:	89 c6                	mov    %eax,%esi
    m = min(n - tot, BSIZE - off%BSIZE);
80101d17:	89 f8                	mov    %edi,%eax
80101d19:	25 ff 01 00 00       	and    $0x1ff,%eax
80101d1e:	29 c1                	sub    %eax,%ecx
    memmove(bp->data + off%BSIZE, src, m);
80101d20:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101d24:	39 d9                	cmp    %ebx,%ecx
80101d26:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
80101d29:	83 c4 0c             	add    $0xc,%esp
80101d2c:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101d2d:	01 df                	add    %ebx,%edi
    memmove(bp->data + off%BSIZE, src, m);
80101d2f:	ff 75 dc             	push   -0x24(%ebp)
80101d32:	50                   	push   %eax
80101d33:	e8 f8 2c 00 00       	call   80104a30 <memmove>
    log_write(bp);
80101d38:	89 34 24             	mov    %esi,(%esp)
80101d3b:	e8 00 14 00 00       	call   80103140 <log_write>
    brelse(bp);
80101d40:	89 34 24             	mov    %esi,(%esp)
80101d43:	e8 b8 e4 ff ff       	call   80100200 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101d48:	01 5d e4             	add    %ebx,-0x1c(%ebp)
80101d4b:	83 c4 10             	add    $0x10,%esp
80101d4e:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101d51:	01 5d dc             	add    %ebx,-0x24(%ebp)
80101d54:	3b 45 e0             	cmp    -0x20(%ebp),%eax
80101d57:	72 97                	jb     80101cf0 <writei+0x60>
  }

  if(n > 0 && off > ip->size){
80101d59:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101d5c:	39 78 58             	cmp    %edi,0x58(%eax)
80101d5f:	72 37                	jb     80101d98 <writei+0x108>
    ip->size = off;
    iupdate(ip);
  }
  return n;
80101d61:	8b 45 e0             	mov    -0x20(%ebp),%eax
}
80101d64:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d67:	5b                   	pop    %ebx
80101d68:	5e                   	pop    %esi
80101d69:	5f                   	pop    %edi
80101d6a:	5d                   	pop    %ebp
80101d6b:	c3                   	ret
80101d6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
80101d70:	0f bf 40 52          	movswl 0x52(%eax),%eax
80101d74:	66 83 f8 09          	cmp    $0x9,%ax
80101d78:	77 2f                	ja     80101da9 <writei+0x119>
80101d7a:	8b 04 c5 04 f9 10 80 	mov    -0x7fef06fc(,%eax,8),%eax
80101d81:	85 c0                	test   %eax,%eax
80101d83:	74 24                	je     80101da9 <writei+0x119>
    return devsw[ip->major].write(ip, src, n);
80101d85:	89 75 10             	mov    %esi,0x10(%ebp)
}
80101d88:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d8b:	5b                   	pop    %ebx
80101d8c:	5e                   	pop    %esi
80101d8d:	5f                   	pop    %edi
80101d8e:	5d                   	pop    %ebp
    return devsw[ip->major].write(ip, src, n);
80101d8f:	ff e0                	jmp    *%eax
80101d91:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    iupdate(ip);
80101d98:	83 ec 0c             	sub    $0xc,%esp
    ip->size = off;
80101d9b:	89 78 58             	mov    %edi,0x58(%eax)
    iupdate(ip);
80101d9e:	50                   	push   %eax
80101d9f:	e8 0c fa ff ff       	call   801017b0 <iupdate>
80101da4:	83 c4 10             	add    $0x10,%esp
80101da7:	eb b8                	jmp    80101d61 <writei+0xd1>
      return -1;
80101da9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101dae:	eb b4                	jmp    80101d64 <writei+0xd4>

80101db0 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80101db0:	55                   	push   %ebp
80101db1:	89 e5                	mov    %esp,%ebp
80101db3:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
80101db6:	6a 0e                	push   $0xe
80101db8:	ff 75 0c             	push   0xc(%ebp)
80101dbb:	ff 75 08             	push   0x8(%ebp)
80101dbe:	e8 dd 2c 00 00       	call   80104aa0 <strncmp>
}
80101dc3:	c9                   	leave
80101dc4:	c3                   	ret
80101dc5:	8d 76 00             	lea    0x0(%esi),%esi
80101dc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101dcf:	00 

80101dd0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
80101dd0:	55                   	push   %ebp
80101dd1:	89 e5                	mov    %esp,%ebp
80101dd3:	57                   	push   %edi
80101dd4:	56                   	push   %esi
80101dd5:	53                   	push   %ebx
80101dd6:	83 ec 1c             	sub    $0x1c,%esp
80101dd9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
80101ddc:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80101de1:	0f 85 8d 00 00 00    	jne    80101e74 <dirlookup+0xa4>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
80101de7:	8b 53 58             	mov    0x58(%ebx),%edx
80101dea:	31 ff                	xor    %edi,%edi
80101dec:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101def:	85 d2                	test   %edx,%edx
80101df1:	74 46                	je     80101e39 <dirlookup+0x69>
80101df3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101df8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101dff:	00 
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101e00:	6a 10                	push   $0x10
80101e02:	57                   	push   %edi
80101e03:	56                   	push   %esi
80101e04:	53                   	push   %ebx
80101e05:	e8 86 fd ff ff       	call   80101b90 <readi>
80101e0a:	83 c4 10             	add    $0x10,%esp
80101e0d:	83 f8 10             	cmp    $0x10,%eax
80101e10:	75 55                	jne    80101e67 <dirlookup+0x97>
      panic("dirlookup read");
    if(de.inum == 0)
80101e12:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101e17:	74 18                	je     80101e31 <dirlookup+0x61>
  return strncmp(s, t, DIRSIZ);
80101e19:	83 ec 04             	sub    $0x4,%esp
80101e1c:	8d 45 da             	lea    -0x26(%ebp),%eax
80101e1f:	6a 0e                	push   $0xe
80101e21:	50                   	push   %eax
80101e22:	ff 75 0c             	push   0xc(%ebp)
80101e25:	e8 76 2c 00 00       	call   80104aa0 <strncmp>
      continue;
    if(namecmp(name, de.name) == 0){
80101e2a:	83 c4 10             	add    $0x10,%esp
80101e2d:	85 c0                	test   %eax,%eax
80101e2f:	74 17                	je     80101e48 <dirlookup+0x78>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101e31:	83 c7 10             	add    $0x10,%edi
80101e34:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101e37:	72 c7                	jb     80101e00 <dirlookup+0x30>
      return iget(dp->dev, inum);
    }
  }

  return 0;
}
80101e39:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80101e3c:	31 c0                	xor    %eax,%eax
}
80101e3e:	5b                   	pop    %ebx
80101e3f:	5e                   	pop    %esi
80101e40:	5f                   	pop    %edi
80101e41:	5d                   	pop    %ebp
80101e42:	c3                   	ret
80101e43:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(poff)
80101e48:	8b 45 10             	mov    0x10(%ebp),%eax
80101e4b:	85 c0                	test   %eax,%eax
80101e4d:	74 05                	je     80101e54 <dirlookup+0x84>
        *poff = off;
80101e4f:	8b 45 10             	mov    0x10(%ebp),%eax
80101e52:	89 38                	mov    %edi,(%eax)
      inum = de.inum;
80101e54:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80101e58:	8b 03                	mov    (%ebx),%eax
80101e5a:	e8 01 f5 ff ff       	call   80101360 <iget>
}
80101e5f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101e62:	5b                   	pop    %ebx
80101e63:	5e                   	pop    %esi
80101e64:	5f                   	pop    %edi
80101e65:	5d                   	pop    %ebp
80101e66:	c3                   	ret
      panic("dirlookup read");
80101e67:	83 ec 0c             	sub    $0xc,%esp
80101e6a:	68 e8 76 10 80       	push   $0x801076e8
80101e6f:	e8 2c e5 ff ff       	call   801003a0 <panic>
    panic("dirlookup not DIR");
80101e74:	83 ec 0c             	sub    $0xc,%esp
80101e77:	68 d6 76 10 80       	push   $0x801076d6
80101e7c:	e8 1f e5 ff ff       	call   801003a0 <panic>
80101e81:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101e88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101e8f:	00 

80101e90 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80101e90:	55                   	push   %ebp
80101e91:	89 e5                	mov    %esp,%ebp
80101e93:	57                   	push   %edi
80101e94:	56                   	push   %esi
80101e95:	53                   	push   %ebx
80101e96:	89 c3                	mov    %eax,%ebx
80101e98:	83 ec 1c             	sub    $0x1c,%esp
80101e9b:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101e9e:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  struct inode *ip, *next;

  if(*path == '/')
80101ea1:	80 38 2f             	cmpb   $0x2f,(%eax)
80101ea4:	0f 84 bc 01 00 00    	je     80102066 <namex+0x1d6>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80101eaa:	e8 31 1d 00 00       	call   80103be0 <myproc>
  acquire(&icache.lock);
80101eaf:	83 ec 0c             	sub    $0xc,%esp
    ip = idup(myproc()->cwd);
80101eb2:	8b 70 68             	mov    0x68(%eax),%esi
  acquire(&icache.lock);
80101eb5:	68 60 f9 10 80       	push   $0x8010f960
80101eba:	e8 c1 29 00 00       	call   80104880 <acquire>
  ip->ref++;
80101ebf:	83 46 08 01          	addl   $0x1,0x8(%esi)
  release(&icache.lock);
80101ec3:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
80101eca:	e8 51 29 00 00       	call   80104820 <release>
80101ecf:	83 c4 10             	add    $0x10,%esp
80101ed2:	eb 0f                	jmp    80101ee3 <namex+0x53>
80101ed4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101ed8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101edf:	00 
    path++;
80101ee0:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101ee3:	0f b6 03             	movzbl (%ebx),%eax
80101ee6:	3c 2f                	cmp    $0x2f,%al
80101ee8:	74 f6                	je     80101ee0 <namex+0x50>
  if(*path == 0)
80101eea:	84 c0                	test   %al,%al
80101eec:	0f 84 16 01 00 00    	je     80102008 <namex+0x178>
  while(*path != '/' && *path != 0)
80101ef2:	0f b6 03             	movzbl (%ebx),%eax
80101ef5:	84 c0                	test   %al,%al
80101ef7:	0f 84 23 01 00 00    	je     80102020 <namex+0x190>
80101efd:	89 df                	mov    %ebx,%edi
80101eff:	3c 2f                	cmp    $0x2f,%al
80101f01:	0f 84 19 01 00 00    	je     80102020 <namex+0x190>
80101f07:	90                   	nop
80101f08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101f0f:	00 
80101f10:	0f b6 47 01          	movzbl 0x1(%edi),%eax
    path++;
80101f14:	83 c7 01             	add    $0x1,%edi
  while(*path != '/' && *path != 0)
80101f17:	3c 2f                	cmp    $0x2f,%al
80101f19:	74 04                	je     80101f1f <namex+0x8f>
80101f1b:	84 c0                	test   %al,%al
80101f1d:	75 f1                	jne    80101f10 <namex+0x80>
  len = path - s;
80101f1f:	89 f8                	mov    %edi,%eax
80101f21:	29 d8                	sub    %ebx,%eax
  if(len >= DIRSIZ)
80101f23:	83 f8 0d             	cmp    $0xd,%eax
80101f26:	0f 8e b4 00 00 00    	jle    80101fe0 <namex+0x150>
    memmove(name, s, DIRSIZ);
80101f2c:	83 ec 04             	sub    $0x4,%esp
80101f2f:	6a 0e                	push   $0xe
80101f31:	53                   	push   %ebx
80101f32:	89 fb                	mov    %edi,%ebx
80101f34:	ff 75 e4             	push   -0x1c(%ebp)
80101f37:	e8 f4 2a 00 00       	call   80104a30 <memmove>
80101f3c:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101f3f:	80 3f 2f             	cmpb   $0x2f,(%edi)
80101f42:	75 14                	jne    80101f58 <namex+0xc8>
80101f44:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80101f48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101f4f:	00 
    path++;
80101f50:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101f53:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101f56:	74 f8                	je     80101f50 <namex+0xc0>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
80101f58:	83 ec 0c             	sub    $0xc,%esp
80101f5b:	56                   	push   %esi
80101f5c:	e8 0f f9 ff ff       	call   80101870 <ilock>
    if(ip->type != T_DIR){
80101f61:	83 c4 10             	add    $0x10,%esp
80101f64:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80101f69:	0f 85 bd 00 00 00    	jne    8010202c <namex+0x19c>
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
80101f6f:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101f72:	85 c0                	test   %eax,%eax
80101f74:	74 09                	je     80101f7f <namex+0xef>
80101f76:	80 3b 00             	cmpb   $0x0,(%ebx)
80101f79:	0f 84 fd 00 00 00    	je     8010207c <namex+0x1ec>
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
80101f7f:	83 ec 04             	sub    $0x4,%esp
80101f82:	6a 00                	push   $0x0
80101f84:	ff 75 e4             	push   -0x1c(%ebp)
80101f87:	56                   	push   %esi
80101f88:	e8 43 fe ff ff       	call   80101dd0 <dirlookup>
80101f8d:	83 c4 10             	add    $0x10,%esp
80101f90:	89 c7                	mov    %eax,%edi
80101f92:	85 c0                	test   %eax,%eax
80101f94:	0f 84 92 00 00 00    	je     8010202c <namex+0x19c>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101f9a:	83 ec 0c             	sub    $0xc,%esp
80101f9d:	8d 4e 0c             	lea    0xc(%esi),%ecx
80101fa0:	51                   	push   %ecx
80101fa1:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80101fa4:	e8 67 26 00 00       	call   80104610 <holdingsleep>
80101fa9:	83 c4 10             	add    $0x10,%esp
80101fac:	85 c0                	test   %eax,%eax
80101fae:	0f 84 08 01 00 00    	je     801020bc <namex+0x22c>
80101fb4:	8b 56 08             	mov    0x8(%esi),%edx
80101fb7:	85 d2                	test   %edx,%edx
80101fb9:	0f 8e fd 00 00 00    	jle    801020bc <namex+0x22c>
  releasesleep(&ip->lock);
80101fbf:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101fc2:	83 ec 0c             	sub    $0xc,%esp
80101fc5:	51                   	push   %ecx
80101fc6:	e8 05 26 00 00       	call   801045d0 <releasesleep>
  iput(ip);
80101fcb:	89 34 24             	mov    %esi,(%esp)
      iunlockput(ip);
      return 0;
    }
    iunlockput(ip);
    ip = next;
80101fce:	89 fe                	mov    %edi,%esi
  iput(ip);
80101fd0:	e8 cb f9 ff ff       	call   801019a0 <iput>
80101fd5:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101fd8:	e9 06 ff ff ff       	jmp    80101ee3 <namex+0x53>
80101fdd:	8d 76 00             	lea    0x0(%esi),%esi
    name[len] = 0;
80101fe0:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101fe3:	01 c2                	add    %eax,%edx
80101fe5:	89 55 e0             	mov    %edx,-0x20(%ebp)
    memmove(name, s, len);
80101fe8:	83 ec 04             	sub    $0x4,%esp
80101feb:	50                   	push   %eax
80101fec:	53                   	push   %ebx
    name[len] = 0;
80101fed:	89 fb                	mov    %edi,%ebx
    memmove(name, s, len);
80101fef:	ff 75 e4             	push   -0x1c(%ebp)
80101ff2:	e8 39 2a 00 00       	call   80104a30 <memmove>
    name[len] = 0;
80101ff7:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101ffa:	83 c4 10             	add    $0x10,%esp
80101ffd:	c6 00 00             	movb   $0x0,(%eax)
80102000:	e9 3a ff ff ff       	jmp    80101f3f <namex+0xaf>
80102005:	8d 76 00             	lea    0x0(%esi),%esi
  }
  if(nameiparent){
80102008:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010200b:	85 c0                	test   %eax,%eax
8010200d:	0f 85 99 00 00 00    	jne    801020ac <namex+0x21c>
    iput(ip);
    return 0;
  }
  return ip;
}
80102013:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102016:	89 f0                	mov    %esi,%eax
80102018:	5b                   	pop    %ebx
80102019:	5e                   	pop    %esi
8010201a:	5f                   	pop    %edi
8010201b:	5d                   	pop    %ebp
8010201c:	c3                   	ret
8010201d:	8d 76 00             	lea    0x0(%esi),%esi
  while(*path != '/' && *path != 0)
80102020:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80102023:	89 df                	mov    %ebx,%edi
80102025:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102028:	31 c0                	xor    %eax,%eax
8010202a:	eb bc                	jmp    80101fe8 <namex+0x158>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
8010202c:	83 ec 0c             	sub    $0xc,%esp
8010202f:	8d 5e 0c             	lea    0xc(%esi),%ebx
80102032:	53                   	push   %ebx
80102033:	e8 d8 25 00 00       	call   80104610 <holdingsleep>
80102038:	83 c4 10             	add    $0x10,%esp
8010203b:	85 c0                	test   %eax,%eax
8010203d:	74 7d                	je     801020bc <namex+0x22c>
8010203f:	8b 4e 08             	mov    0x8(%esi),%ecx
80102042:	85 c9                	test   %ecx,%ecx
80102044:	7e 76                	jle    801020bc <namex+0x22c>
  releasesleep(&ip->lock);
80102046:	83 ec 0c             	sub    $0xc,%esp
80102049:	53                   	push   %ebx
8010204a:	e8 81 25 00 00       	call   801045d0 <releasesleep>
  iput(ip);
8010204f:	89 34 24             	mov    %esi,(%esp)
      return 0;
80102052:	31 f6                	xor    %esi,%esi
  iput(ip);
80102054:	e8 47 f9 ff ff       	call   801019a0 <iput>
      return 0;
80102059:	83 c4 10             	add    $0x10,%esp
}
8010205c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010205f:	89 f0                	mov    %esi,%eax
80102061:	5b                   	pop    %ebx
80102062:	5e                   	pop    %esi
80102063:	5f                   	pop    %edi
80102064:	5d                   	pop    %ebp
80102065:	c3                   	ret
    ip = iget(ROOTDEV, ROOTINO);
80102066:	ba 01 00 00 00       	mov    $0x1,%edx
8010206b:	b8 01 00 00 00       	mov    $0x1,%eax
80102070:	e8 eb f2 ff ff       	call   80101360 <iget>
80102075:	89 c6                	mov    %eax,%esi
80102077:	e9 67 fe ff ff       	jmp    80101ee3 <namex+0x53>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
8010207c:	83 ec 0c             	sub    $0xc,%esp
8010207f:	8d 5e 0c             	lea    0xc(%esi),%ebx
80102082:	53                   	push   %ebx
80102083:	e8 88 25 00 00       	call   80104610 <holdingsleep>
80102088:	83 c4 10             	add    $0x10,%esp
8010208b:	85 c0                	test   %eax,%eax
8010208d:	74 2d                	je     801020bc <namex+0x22c>
8010208f:	8b 7e 08             	mov    0x8(%esi),%edi
80102092:	85 ff                	test   %edi,%edi
80102094:	7e 26                	jle    801020bc <namex+0x22c>
  releasesleep(&ip->lock);
80102096:	83 ec 0c             	sub    $0xc,%esp
80102099:	53                   	push   %ebx
8010209a:	e8 31 25 00 00       	call   801045d0 <releasesleep>
}
8010209f:	83 c4 10             	add    $0x10,%esp
}
801020a2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801020a5:	89 f0                	mov    %esi,%eax
801020a7:	5b                   	pop    %ebx
801020a8:	5e                   	pop    %esi
801020a9:	5f                   	pop    %edi
801020aa:	5d                   	pop    %ebp
801020ab:	c3                   	ret
    iput(ip);
801020ac:	83 ec 0c             	sub    $0xc,%esp
801020af:	56                   	push   %esi
      return 0;
801020b0:	31 f6                	xor    %esi,%esi
    iput(ip);
801020b2:	e8 e9 f8 ff ff       	call   801019a0 <iput>
    return 0;
801020b7:	83 c4 10             	add    $0x10,%esp
801020ba:	eb a0                	jmp    8010205c <namex+0x1cc>
    panic("iunlock");
801020bc:	83 ec 0c             	sub    $0xc,%esp
801020bf:	68 ce 76 10 80       	push   $0x801076ce
801020c4:	e8 d7 e2 ff ff       	call   801003a0 <panic>
801020c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801020d0 <dirlink>:
{
801020d0:	55                   	push   %ebp
801020d1:	89 e5                	mov    %esp,%ebp
801020d3:	57                   	push   %edi
801020d4:	56                   	push   %esi
801020d5:	53                   	push   %ebx
801020d6:	83 ec 20             	sub    $0x20,%esp
801020d9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if((ip = dirlookup(dp, name, 0)) != 0){
801020dc:	6a 00                	push   $0x0
801020de:	ff 75 0c             	push   0xc(%ebp)
801020e1:	53                   	push   %ebx
801020e2:	e8 e9 fc ff ff       	call   80101dd0 <dirlookup>
801020e7:	83 c4 10             	add    $0x10,%esp
801020ea:	85 c0                	test   %eax,%eax
801020ec:	75 67                	jne    80102155 <dirlink+0x85>
  for(off = 0; off < dp->size; off += sizeof(de)){
801020ee:	8b 7b 58             	mov    0x58(%ebx),%edi
801020f1:	8d 75 d8             	lea    -0x28(%ebp),%esi
801020f4:	85 ff                	test   %edi,%edi
801020f6:	74 29                	je     80102121 <dirlink+0x51>
801020f8:	31 ff                	xor    %edi,%edi
801020fa:	8d 75 d8             	lea    -0x28(%ebp),%esi
801020fd:	eb 09                	jmp    80102108 <dirlink+0x38>
801020ff:	90                   	nop
80102100:	83 c7 10             	add    $0x10,%edi
80102103:	3b 7b 58             	cmp    0x58(%ebx),%edi
80102106:	73 19                	jae    80102121 <dirlink+0x51>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102108:	6a 10                	push   $0x10
8010210a:	57                   	push   %edi
8010210b:	56                   	push   %esi
8010210c:	53                   	push   %ebx
8010210d:	e8 7e fa ff ff       	call   80101b90 <readi>
80102112:	83 c4 10             	add    $0x10,%esp
80102115:	83 f8 10             	cmp    $0x10,%eax
80102118:	75 4e                	jne    80102168 <dirlink+0x98>
    if(de.inum == 0)
8010211a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
8010211f:	75 df                	jne    80102100 <dirlink+0x30>
  strncpy(de.name, name, DIRSIZ);
80102121:	83 ec 04             	sub    $0x4,%esp
80102124:	8d 45 da             	lea    -0x26(%ebp),%eax
80102127:	6a 0e                	push   $0xe
80102129:	ff 75 0c             	push   0xc(%ebp)
8010212c:	50                   	push   %eax
8010212d:	e8 be 29 00 00       	call   80104af0 <strncpy>
  de.inum = inum;
80102132:	8b 45 10             	mov    0x10(%ebp),%eax
80102135:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102139:	6a 10                	push   $0x10
8010213b:	57                   	push   %edi
8010213c:	56                   	push   %esi
8010213d:	53                   	push   %ebx
8010213e:	e8 4d fb ff ff       	call   80101c90 <writei>
80102143:	83 c4 20             	add    $0x20,%esp
80102146:	83 f8 10             	cmp    $0x10,%eax
80102149:	75 2a                	jne    80102175 <dirlink+0xa5>
  return 0;
8010214b:	31 c0                	xor    %eax,%eax
}
8010214d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102150:	5b                   	pop    %ebx
80102151:	5e                   	pop    %esi
80102152:	5f                   	pop    %edi
80102153:	5d                   	pop    %ebp
80102154:	c3                   	ret
    iput(ip);
80102155:	83 ec 0c             	sub    $0xc,%esp
80102158:	50                   	push   %eax
80102159:	e8 42 f8 ff ff       	call   801019a0 <iput>
    return -1;
8010215e:	83 c4 10             	add    $0x10,%esp
80102161:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102166:	eb e5                	jmp    8010214d <dirlink+0x7d>
      panic("dirlink read");
80102168:	83 ec 0c             	sub    $0xc,%esp
8010216b:	68 f7 76 10 80       	push   $0x801076f7
80102170:	e8 2b e2 ff ff       	call   801003a0 <panic>
    panic("dirlink");
80102175:	83 ec 0c             	sub    $0xc,%esp
80102178:	68 53 79 10 80       	push   $0x80107953
8010217d:	e8 1e e2 ff ff       	call   801003a0 <panic>
80102182:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102188:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010218f:	00 

80102190 <namei>:

struct inode*
namei(char *path)
{
80102190:	55                   	push   %ebp
  char name[DIRSIZ];
  return namex(path, 0, name);
80102191:	31 d2                	xor    %edx,%edx
{
80102193:	89 e5                	mov    %esp,%ebp
80102195:	83 ec 18             	sub    $0x18,%esp
  return namex(path, 0, name);
80102198:	8b 45 08             	mov    0x8(%ebp),%eax
8010219b:	8d 4d ea             	lea    -0x16(%ebp),%ecx
8010219e:	e8 ed fc ff ff       	call   80101e90 <namex>
}
801021a3:	c9                   	leave
801021a4:	c3                   	ret
801021a5:	8d 76 00             	lea    0x0(%esi),%esi
801021a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801021af:	00 

801021b0 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
801021b0:	55                   	push   %ebp
  return namex(path, 1, name);
801021b1:	ba 01 00 00 00       	mov    $0x1,%edx
{
801021b6:	89 e5                	mov    %esp,%ebp
  return namex(path, 1, name);
801021b8:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801021bb:	8b 45 08             	mov    0x8(%ebp),%eax
}
801021be:	5d                   	pop    %ebp
  return namex(path, 1, name);
801021bf:	e9 cc fc ff ff       	jmp    80101e90 <namex>
801021c4:	66 90                	xchg   %ax,%ax
801021c6:	66 90                	xchg   %ax,%ax
801021c8:	66 90                	xchg   %ax,%ax
801021ca:	66 90                	xchg   %ax,%ax
801021cc:	66 90                	xchg   %ax,%ax
801021ce:	66 90                	xchg   %ax,%ax

801021d0 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
801021d0:	55                   	push   %ebp
801021d1:	89 e5                	mov    %esp,%ebp
801021d3:	57                   	push   %edi
801021d4:	56                   	push   %esi
801021d5:	53                   	push   %ebx
801021d6:	83 ec 0c             	sub    $0xc,%esp
  if(b == 0)
801021d9:	85 c0                	test   %eax,%eax
801021db:	0f 84 ac 00 00 00    	je     8010228d <idestart+0xbd>
    panic("idestart");
  if(b->blockno >= FSSIZE)
801021e1:	8b 70 08             	mov    0x8(%eax),%esi
801021e4:	89 c3                	mov    %eax,%ebx
801021e6:	81 fe e7 03 00 00    	cmp    $0x3e7,%esi
801021ec:	0f 87 8e 00 00 00    	ja     80102280 <idestart+0xb0>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801021f2:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
801021f7:	90                   	nop
801021f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801021ff:	00 
80102200:	89 ca                	mov    %ecx,%edx
80102202:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102203:	83 e0 c0             	and    $0xffffffc0,%eax
80102206:	3c 40                	cmp    $0x40,%al
80102208:	75 f6                	jne    80102200 <idestart+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010220a:	ba f6 03 00 00       	mov    $0x3f6,%edx
8010220f:	31 c0                	xor    %eax,%eax
80102211:	ee                   	out    %al,(%dx)
80102212:	b8 01 00 00 00       	mov    $0x1,%eax
80102217:	ba f2 01 00 00       	mov    $0x1f2,%edx
8010221c:	ee                   	out    %al,(%dx)
8010221d:	ba f3 01 00 00       	mov    $0x1f3,%edx
80102222:	89 f0                	mov    %esi,%eax
80102224:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80102225:	89 f0                	mov    %esi,%eax
80102227:	ba f4 01 00 00       	mov    $0x1f4,%edx
8010222c:	c1 f8 08             	sar    $0x8,%eax
8010222f:	ee                   	out    %al,(%dx)
80102230:	ba f5 01 00 00       	mov    $0x1f5,%edx
80102235:	31 c0                	xor    %eax,%eax
80102237:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
80102238:	0f b6 43 04          	movzbl 0x4(%ebx),%eax
8010223c:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102241:	c1 e0 04             	shl    $0x4,%eax
80102244:	83 e0 10             	and    $0x10,%eax
80102247:	83 c8 e0             	or     $0xffffffe0,%eax
8010224a:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
8010224b:	f6 03 04             	testb  $0x4,(%ebx)
8010224e:	75 10                	jne    80102260 <idestart+0x90>
80102250:	b8 20 00 00 00       	mov    $0x20,%eax
80102255:	89 ca                	mov    %ecx,%edx
80102257:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
80102258:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010225b:	5b                   	pop    %ebx
8010225c:	5e                   	pop    %esi
8010225d:	5f                   	pop    %edi
8010225e:	5d                   	pop    %ebp
8010225f:	c3                   	ret
80102260:	b8 30 00 00 00       	mov    $0x30,%eax
80102265:	89 ca                	mov    %ecx,%edx
80102267:	ee                   	out    %al,(%dx)
  asm volatile("cld; rep outsl" :
80102268:	b9 80 00 00 00       	mov    $0x80,%ecx
    outsl(0x1f0, b->data, BSIZE/4);
8010226d:	8d 73 5c             	lea    0x5c(%ebx),%esi
80102270:	ba f0 01 00 00       	mov    $0x1f0,%edx
80102275:	fc                   	cld
80102276:	f3 6f                	rep outsl %ds:(%esi),(%dx)
}
80102278:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010227b:	5b                   	pop    %ebx
8010227c:	5e                   	pop    %esi
8010227d:	5f                   	pop    %edi
8010227e:	5d                   	pop    %ebp
8010227f:	c3                   	ret
    panic("incorrect blockno");
80102280:	83 ec 0c             	sub    $0xc,%esp
80102283:	68 0d 77 10 80       	push   $0x8010770d
80102288:	e8 13 e1 ff ff       	call   801003a0 <panic>
    panic("idestart");
8010228d:	83 ec 0c             	sub    $0xc,%esp
80102290:	68 04 77 10 80       	push   $0x80107704
80102295:	e8 06 e1 ff ff       	call   801003a0 <panic>
8010229a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801022a0 <ideinit>:
{
801022a0:	55                   	push   %ebp
801022a1:	89 e5                	mov    %esp,%ebp
801022a3:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
801022a6:	68 1f 77 10 80       	push   $0x8010771f
801022ab:	68 00 16 11 80       	push   $0x80111600
801022b0:	e8 ab 23 00 00       	call   80104660 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
801022b5:	58                   	pop    %eax
801022b6:	a1 84 17 11 80       	mov    0x80111784,%eax
801022bb:	5a                   	pop    %edx
801022bc:	83 e8 01             	sub    $0x1,%eax
801022bf:	50                   	push   %eax
801022c0:	6a 0e                	push   $0xe
801022c2:	e8 b9 02 00 00       	call   80102580 <ioapicenable>
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801022c7:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022ca:	ba f7 01 00 00       	mov    $0x1f7,%edx
801022cf:	90                   	nop
801022d0:	ec                   	in     (%dx),%al
801022d1:	83 e0 c0             	and    $0xffffffc0,%eax
801022d4:	3c 40                	cmp    $0x40,%al
801022d6:	75 f8                	jne    801022d0 <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022d8:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
801022dd:	ba f6 01 00 00       	mov    $0x1f6,%edx
801022e2:	ee                   	out    %al,(%dx)
801022e3:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022e8:	ba f7 01 00 00       	mov    $0x1f7,%edx
801022ed:	eb 06                	jmp    801022f5 <ideinit+0x55>
801022ef:	90                   	nop
  for(i=0; i<1000; i++){
801022f0:	83 e9 01             	sub    $0x1,%ecx
801022f3:	74 0f                	je     80102304 <ideinit+0x64>
801022f5:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
801022f6:	84 c0                	test   %al,%al
801022f8:	74 f6                	je     801022f0 <ideinit+0x50>
      havedisk1 = 1;
801022fa:	c7 05 e0 15 11 80 01 	movl   $0x1,0x801115e0
80102301:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102304:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80102309:	ba f6 01 00 00       	mov    $0x1f6,%edx
8010230e:	ee                   	out    %al,(%dx)
}
8010230f:	c9                   	leave
80102310:	c3                   	ret
80102311:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102318:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010231f:	00 

80102320 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102320:	55                   	push   %ebp
80102321:	89 e5                	mov    %esp,%ebp
80102323:	57                   	push   %edi
80102324:	56                   	push   %esi
80102325:	53                   	push   %ebx
80102326:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102329:	68 00 16 11 80       	push   $0x80111600
8010232e:	e8 4d 25 00 00       	call   80104880 <acquire>

  if((b = idequeue) == 0){
80102333:	8b 1d e4 15 11 80    	mov    0x801115e4,%ebx
80102339:	83 c4 10             	add    $0x10,%esp
8010233c:	85 db                	test   %ebx,%ebx
8010233e:	74 63                	je     801023a3 <ideintr+0x83>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80102340:	8b 43 58             	mov    0x58(%ebx),%eax
80102343:	a3 e4 15 11 80       	mov    %eax,0x801115e4

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80102348:	8b 33                	mov    (%ebx),%esi
8010234a:	f7 c6 04 00 00 00    	test   $0x4,%esi
80102350:	75 2f                	jne    80102381 <ideintr+0x61>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102352:	ba f7 01 00 00       	mov    $0x1f7,%edx
80102357:	90                   	nop
80102358:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010235f:	00 
80102360:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102361:	89 c1                	mov    %eax,%ecx
80102363:	83 e1 c0             	and    $0xffffffc0,%ecx
80102366:	80 f9 40             	cmp    $0x40,%cl
80102369:	75 f5                	jne    80102360 <ideintr+0x40>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
8010236b:	a8 21                	test   $0x21,%al
8010236d:	75 12                	jne    80102381 <ideintr+0x61>
  asm volatile("cld; rep insl" :
8010236f:	b9 80 00 00 00       	mov    $0x80,%ecx
80102374:	ba f0 01 00 00       	mov    $0x1f0,%edx
80102379:	8d 7b 5c             	lea    0x5c(%ebx),%edi
8010237c:	fc                   	cld
8010237d:	f3 6d                	rep insl (%dx),%es:(%edi)
    insl(0x1f0, b->data, BSIZE/4);

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
8010237f:	8b 33                	mov    (%ebx),%esi
  b->flags &= ~B_DIRTY;
80102381:	83 e6 fb             	and    $0xfffffffb,%esi
  wakeup(b);
80102384:	83 ec 0c             	sub    $0xc,%esp
  b->flags &= ~B_DIRTY;
80102387:	83 ce 02             	or     $0x2,%esi
8010238a:	89 33                	mov    %esi,(%ebx)
  wakeup(b);
8010238c:	53                   	push   %ebx
8010238d:	e8 ee 1f 00 00       	call   80104380 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
80102392:	a1 e4 15 11 80       	mov    0x801115e4,%eax
80102397:	83 c4 10             	add    $0x10,%esp
8010239a:	85 c0                	test   %eax,%eax
8010239c:	74 05                	je     801023a3 <ideintr+0x83>
    idestart(idequeue);
8010239e:	e8 2d fe ff ff       	call   801021d0 <idestart>
    release(&idelock);
801023a3:	83 ec 0c             	sub    $0xc,%esp
801023a6:	68 00 16 11 80       	push   $0x80111600
801023ab:	e8 70 24 00 00       	call   80104820 <release>

  release(&idelock);
}
801023b0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801023b3:	5b                   	pop    %ebx
801023b4:	5e                   	pop    %esi
801023b5:	5f                   	pop    %edi
801023b6:	5d                   	pop    %ebp
801023b7:	c3                   	ret
801023b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801023bf:	00 

801023c0 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
801023c0:	55                   	push   %ebp
801023c1:	89 e5                	mov    %esp,%ebp
801023c3:	53                   	push   %ebx
801023c4:	83 ec 10             	sub    $0x10,%esp
801023c7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
801023ca:	8d 43 0c             	lea    0xc(%ebx),%eax
801023cd:	50                   	push   %eax
801023ce:	e8 3d 22 00 00       	call   80104610 <holdingsleep>
801023d3:	83 c4 10             	add    $0x10,%esp
801023d6:	85 c0                	test   %eax,%eax
801023d8:	0f 84 c3 00 00 00    	je     801024a1 <iderw+0xe1>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
801023de:	8b 03                	mov    (%ebx),%eax
801023e0:	83 e0 06             	and    $0x6,%eax
801023e3:	83 f8 02             	cmp    $0x2,%eax
801023e6:	0f 84 a8 00 00 00    	je     80102494 <iderw+0xd4>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
801023ec:	8b 53 04             	mov    0x4(%ebx),%edx
801023ef:	85 d2                	test   %edx,%edx
801023f1:	74 0d                	je     80102400 <iderw+0x40>
801023f3:	a1 e0 15 11 80       	mov    0x801115e0,%eax
801023f8:	85 c0                	test   %eax,%eax
801023fa:	0f 84 87 00 00 00    	je     80102487 <iderw+0xc7>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80102400:	83 ec 0c             	sub    $0xc,%esp
80102403:	68 00 16 11 80       	push   $0x80111600
80102408:	e8 73 24 00 00       	call   80104880 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
8010240d:	a1 e4 15 11 80       	mov    0x801115e4,%eax
  b->qnext = 0;
80102412:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102419:	83 c4 10             	add    $0x10,%esp
8010241c:	85 c0                	test   %eax,%eax
8010241e:	74 60                	je     80102480 <iderw+0xc0>
80102420:	89 c2                	mov    %eax,%edx
80102422:	8b 40 58             	mov    0x58(%eax),%eax
80102425:	85 c0                	test   %eax,%eax
80102427:	75 f7                	jne    80102420 <iderw+0x60>
80102429:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
8010242c:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
8010242e:	39 1d e4 15 11 80    	cmp    %ebx,0x801115e4
80102434:	74 3a                	je     80102470 <iderw+0xb0>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102436:	8b 03                	mov    (%ebx),%eax
80102438:	83 e0 06             	and    $0x6,%eax
8010243b:	83 f8 02             	cmp    $0x2,%eax
8010243e:	74 1b                	je     8010245b <iderw+0x9b>
    sleep(b, &idelock);
80102440:	83 ec 08             	sub    $0x8,%esp
80102443:	68 00 16 11 80       	push   $0x80111600
80102448:	53                   	push   %ebx
80102449:	e8 72 1e 00 00       	call   801042c0 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
8010244e:	8b 03                	mov    (%ebx),%eax
80102450:	83 c4 10             	add    $0x10,%esp
80102453:	83 e0 06             	and    $0x6,%eax
80102456:	83 f8 02             	cmp    $0x2,%eax
80102459:	75 e5                	jne    80102440 <iderw+0x80>
  }


  release(&idelock);
8010245b:	c7 45 08 00 16 11 80 	movl   $0x80111600,0x8(%ebp)
}
80102462:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102465:	c9                   	leave
  release(&idelock);
80102466:	e9 b5 23 00 00       	jmp    80104820 <release>
8010246b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    idestart(b);
80102470:	89 d8                	mov    %ebx,%eax
80102472:	e8 59 fd ff ff       	call   801021d0 <idestart>
80102477:	eb bd                	jmp    80102436 <iderw+0x76>
80102479:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102480:	ba e4 15 11 80       	mov    $0x801115e4,%edx
80102485:	eb a5                	jmp    8010242c <iderw+0x6c>
    panic("iderw: ide disk 1 not present");
80102487:	83 ec 0c             	sub    $0xc,%esp
8010248a:	68 4e 77 10 80       	push   $0x8010774e
8010248f:	e8 0c df ff ff       	call   801003a0 <panic>
    panic("iderw: nothing to do");
80102494:	83 ec 0c             	sub    $0xc,%esp
80102497:	68 39 77 10 80       	push   $0x80107739
8010249c:	e8 ff de ff ff       	call   801003a0 <panic>
    panic("iderw: buf not locked");
801024a1:	83 ec 0c             	sub    $0xc,%esp
801024a4:	68 23 77 10 80       	push   $0x80107723
801024a9:	e8 f2 de ff ff       	call   801003a0 <panic>
801024ae:	66 90                	xchg   %ax,%ax
801024b0:	66 90                	xchg   %ax,%ax
801024b2:	66 90                	xchg   %ax,%ax
801024b4:	66 90                	xchg   %ax,%ax
801024b6:	66 90                	xchg   %ax,%ax
801024b8:	66 90                	xchg   %ax,%ax
801024ba:	66 90                	xchg   %ax,%ax
801024bc:	66 90                	xchg   %ax,%ax
801024be:	66 90                	xchg   %ax,%ax

801024c0 <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
801024c0:	55                   	push   %ebp
801024c1:	89 e5                	mov    %esp,%ebp
801024c3:	56                   	push   %esi
801024c4:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
801024c5:	c7 05 34 16 11 80 00 	movl   $0xfec00000,0x80111634
801024cc:	00 c0 fe 
  ioapic->reg = reg;
801024cf:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
801024d6:	00 00 00 
  return ioapic->data;
801024d9:	8b 15 34 16 11 80    	mov    0x80111634,%edx
801024df:	8b 72 10             	mov    0x10(%edx),%esi
  ioapic->reg = reg;
801024e2:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
  return ioapic->data;
801024e8:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
801024ee:	0f b6 15 80 17 11 80 	movzbl 0x80111780,%edx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
801024f5:	c1 ee 10             	shr    $0x10,%esi
801024f8:	89 f0                	mov    %esi,%eax
801024fa:	0f b6 f0             	movzbl %al,%esi
  return ioapic->data;
801024fd:	8b 43 10             	mov    0x10(%ebx),%eax
  id = ioapicread(REG_ID) >> 24;
80102500:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80102503:	39 c2                	cmp    %eax,%edx
80102505:	74 16                	je     8010251d <ioapicinit+0x5d>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80102507:	83 ec 0c             	sub    $0xc,%esp
8010250a:	68 08 7b 10 80       	push   $0x80107b08
8010250f:	e8 bc e1 ff ff       	call   801006d0 <cprintf>
  ioapic->reg = reg;
80102514:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
8010251a:	83 c4 10             	add    $0x10,%esp
{
8010251d:	ba 10 00 00 00       	mov    $0x10,%edx
80102522:	31 c0                	xor    %eax,%eax
80102524:	eb 1a                	jmp    80102540 <ioapicinit+0x80>
80102526:	66 90                	xchg   %ax,%ax
80102528:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010252f:	00 
80102530:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102537:	00 
80102538:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010253f:	00 
  ioapic->reg = reg;
80102540:	89 13                	mov    %edx,(%ebx)
80102542:	8d 48 20             	lea    0x20(%eax),%ecx
  ioapic->data = data;
80102545:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
8010254b:	83 c0 01             	add    $0x1,%eax
8010254e:	81 c9 00 00 01 00    	or     $0x10000,%ecx
  ioapic->data = data;
80102554:	89 4b 10             	mov    %ecx,0x10(%ebx)
  ioapic->reg = reg;
80102557:	8d 4a 01             	lea    0x1(%edx),%ecx
  for(i = 0; i <= maxintr; i++){
8010255a:	83 c2 02             	add    $0x2,%edx
  ioapic->reg = reg;
8010255d:	89 0b                	mov    %ecx,(%ebx)
  ioapic->data = data;
8010255f:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
80102565:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
  for(i = 0; i <= maxintr; i++){
8010256c:	39 c6                	cmp    %eax,%esi
8010256e:	7d d0                	jge    80102540 <ioapicinit+0x80>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
80102570:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102573:	5b                   	pop    %ebx
80102574:	5e                   	pop    %esi
80102575:	5d                   	pop    %ebp
80102576:	c3                   	ret
80102577:	90                   	nop
80102578:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010257f:	00 

80102580 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102580:	55                   	push   %ebp
  ioapic->reg = reg;
80102581:	8b 0d 34 16 11 80    	mov    0x80111634,%ecx
{
80102587:	89 e5                	mov    %esp,%ebp
80102589:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
8010258c:	8d 50 20             	lea    0x20(%eax),%edx
8010258f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102593:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102595:	8b 0d 34 16 11 80    	mov    0x80111634,%ecx
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010259b:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
8010259e:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
801025a1:	8b 55 0c             	mov    0xc(%ebp),%edx
  ioapic->reg = reg;
801025a4:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
801025a6:	a1 34 16 11 80       	mov    0x80111634,%eax
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
801025ab:	c1 e2 18             	shl    $0x18,%edx
  ioapic->data = data;
801025ae:	89 50 10             	mov    %edx,0x10(%eax)
}
801025b1:	5d                   	pop    %ebp
801025b2:	c3                   	ret
801025b3:	66 90                	xchg   %ax,%ax
801025b5:	66 90                	xchg   %ax,%ax
801025b7:	66 90                	xchg   %ax,%ax
801025b9:	66 90                	xchg   %ax,%ax
801025bb:	66 90                	xchg   %ax,%ax
801025bd:	66 90                	xchg   %ax,%ax
801025bf:	90                   	nop

801025c0 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
801025c0:	55                   	push   %ebp
801025c1:	89 e5                	mov    %esp,%ebp
801025c3:	53                   	push   %ebx
801025c4:	83 ec 04             	sub    $0x4,%esp
801025c7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
801025ca:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
801025d0:	0f 85 82 00 00 00    	jne    80102658 <kfree+0x98>
801025d6:	81 fb d0 54 11 80    	cmp    $0x801154d0,%ebx
801025dc:	72 7a                	jb     80102658 <kfree+0x98>
801025de:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801025e4:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
801025e9:	77 6d                	ja     80102658 <kfree+0x98>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
801025eb:	83 ec 04             	sub    $0x4,%esp
801025ee:	68 00 10 00 00       	push   $0x1000
801025f3:	6a 01                	push   $0x1
801025f5:	53                   	push   %ebx
801025f6:	e8 a5 23 00 00       	call   801049a0 <memset>

  if(kmem.use_lock)
801025fb:	8b 15 74 16 11 80    	mov    0x80111674,%edx
80102601:	83 c4 10             	add    $0x10,%esp
80102604:	85 d2                	test   %edx,%edx
80102606:	75 28                	jne    80102630 <kfree+0x70>
    acquire(&kmem.lock);

  r = (struct run*)v;
  r->next = kmem.freelist;
80102608:	a1 78 16 11 80       	mov    0x80111678,%eax
8010260d:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;

  // Update the number of free physical pages.
  kmem.free_pages++;

  if(kmem.use_lock)
8010260f:	a1 74 16 11 80       	mov    0x80111674,%eax
  kmem.free_pages++;
80102614:	83 05 7c 16 11 80 01 	addl   $0x1,0x8011167c
  kmem.freelist = r;
8010261b:	89 1d 78 16 11 80    	mov    %ebx,0x80111678
  if(kmem.use_lock)
80102621:	85 c0                	test   %eax,%eax
80102623:	75 23                	jne    80102648 <kfree+0x88>
    release(&kmem.lock);
}
80102625:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102628:	c9                   	leave
80102629:	c3                   	ret
8010262a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    acquire(&kmem.lock);
80102630:	83 ec 0c             	sub    $0xc,%esp
80102633:	68 40 16 11 80       	push   $0x80111640
80102638:	e8 43 22 00 00       	call   80104880 <acquire>
8010263d:	83 c4 10             	add    $0x10,%esp
80102640:	eb c6                	jmp    80102608 <kfree+0x48>
80102642:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    release(&kmem.lock);
80102648:	c7 45 08 40 16 11 80 	movl   $0x80111640,0x8(%ebp)
}
8010264f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102652:	c9                   	leave
    release(&kmem.lock);
80102653:	e9 c8 21 00 00       	jmp    80104820 <release>
    panic("kfree");
80102658:	83 ec 0c             	sub    $0xc,%esp
8010265b:	68 6c 77 10 80       	push   $0x8010776c
80102660:	e8 3b dd ff ff       	call   801003a0 <panic>
80102665:	8d 76 00             	lea    0x0(%esi),%esi
80102668:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010266f:	00 

80102670 <freerange>:
{
80102670:	55                   	push   %ebp
80102671:	89 e5                	mov    %esp,%ebp
80102673:	56                   	push   %esi
80102674:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80102675:	8b 45 08             	mov    0x8(%ebp),%eax
{
80102678:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
8010267b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102681:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102687:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010268d:	39 de                	cmp    %ebx,%esi
8010268f:	72 2b                	jb     801026bc <freerange+0x4c>
80102691:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102698:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010269f:	00 
    kfree(p);
801026a0:	83 ec 0c             	sub    $0xc,%esp
801026a3:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801026a9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
801026af:	50                   	push   %eax
801026b0:	e8 0b ff ff ff       	call   801025c0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801026b5:	83 c4 10             	add    $0x10,%esp
801026b8:	39 de                	cmp    %ebx,%esi
801026ba:	73 e4                	jae    801026a0 <freerange+0x30>
}
801026bc:	8d 65 f8             	lea    -0x8(%ebp),%esp
801026bf:	5b                   	pop    %ebx
801026c0:	5e                   	pop    %esi
801026c1:	5d                   	pop    %ebp
801026c2:	c3                   	ret
801026c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801026c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801026cf:	00 

801026d0 <kinit2>:
{
801026d0:	55                   	push   %ebp
801026d1:	89 e5                	mov    %esp,%ebp
801026d3:	56                   	push   %esi
801026d4:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
801026d5:	8b 45 08             	mov    0x8(%ebp),%eax
{
801026d8:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801026db:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801026e1:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801026e7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801026ed:	39 de                	cmp    %ebx,%esi
801026ef:	72 2b                	jb     8010271c <kinit2+0x4c>
801026f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801026f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801026ff:	00 
    kfree(p);
80102700:	83 ec 0c             	sub    $0xc,%esp
80102703:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102709:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
8010270f:	50                   	push   %eax
80102710:	e8 ab fe ff ff       	call   801025c0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102715:	83 c4 10             	add    $0x10,%esp
80102718:	39 de                	cmp    %ebx,%esi
8010271a:	73 e4                	jae    80102700 <kinit2+0x30>
  kmem.use_lock = 1;
8010271c:	c7 05 74 16 11 80 01 	movl   $0x1,0x80111674
80102723:	00 00 00 
}
80102726:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102729:	5b                   	pop    %ebx
8010272a:	5e                   	pop    %esi
8010272b:	5d                   	pop    %ebp
8010272c:	c3                   	ret
8010272d:	8d 76 00             	lea    0x0(%esi),%esi

80102730 <kinit1>:
{
80102730:	55                   	push   %ebp
80102731:	89 e5                	mov    %esp,%ebp
80102733:	56                   	push   %esi
80102734:	53                   	push   %ebx
80102735:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
80102738:	83 ec 08             	sub    $0x8,%esp
8010273b:	68 72 77 10 80       	push   $0x80107772
80102740:	68 40 16 11 80       	push   $0x80111640
80102745:	e8 16 1f 00 00       	call   80104660 <initlock>
  p = (char*)PGROUNDUP((uint)vstart);
8010274a:	8b 45 08             	mov    0x8(%ebp),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010274d:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
80102750:	c7 05 74 16 11 80 00 	movl   $0x0,0x80111674
80102757:	00 00 00 
  kmem.free_pages = 0;
8010275a:	c7 05 7c 16 11 80 00 	movl   $0x0,0x8011167c
80102761:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
80102764:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
8010276a:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102770:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102776:	39 de                	cmp    %ebx,%esi
80102778:	72 22                	jb     8010279c <kinit1+0x6c>
8010277a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    kfree(p);
80102780:	83 ec 0c             	sub    $0xc,%esp
80102783:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102789:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
8010278f:	50                   	push   %eax
80102790:	e8 2b fe ff ff       	call   801025c0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102795:	83 c4 10             	add    $0x10,%esp
80102798:	39 de                	cmp    %ebx,%esi
8010279a:	73 e4                	jae    80102780 <kinit1+0x50>
}
8010279c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010279f:	5b                   	pop    %ebx
801027a0:	5e                   	pop    %esi
801027a1:	5d                   	pop    %ebp
801027a2:	c3                   	ret
801027a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801027a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801027af:	00 

801027b0 <kalloc>:
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
801027b0:	a1 74 16 11 80       	mov    0x80111674,%eax
801027b5:	85 c0                	test   %eax,%eax
801027b7:	75 27                	jne    801027e0 <kalloc+0x30>
    acquire(&kmem.lock);

  r = kmem.freelist;
801027b9:	a1 78 16 11 80       	mov    0x80111678,%eax
  if(r){
801027be:	85 c0                	test   %eax,%eax
801027c0:	74 16                	je     801027d8 <kalloc+0x28>
    kmem.freelist = r->next;
801027c2:	8b 10                	mov    (%eax),%edx

    // Update the number of free physical pages.
    kmem.free_pages--;
801027c4:	83 2d 7c 16 11 80 01 	subl   $0x1,0x8011167c
    kmem.freelist = r->next;
801027cb:	89 15 78 16 11 80    	mov    %edx,0x80111678
  }

  if(kmem.use_lock)
801027d1:	c3                   	ret
801027d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    release(&kmem.lock);

  return (char*)r;
}
801027d8:	c3                   	ret
801027d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
{
801027e0:	55                   	push   %ebp
801027e1:	89 e5                	mov    %esp,%ebp
801027e3:	83 ec 24             	sub    $0x24,%esp
    acquire(&kmem.lock);
801027e6:	68 40 16 11 80       	push   $0x80111640
801027eb:	e8 90 20 00 00       	call   80104880 <acquire>
  r = kmem.freelist;
801027f0:	a1 78 16 11 80       	mov    0x80111678,%eax
  if(kmem.use_lock)
801027f5:	8b 15 74 16 11 80    	mov    0x80111674,%edx
  if(r){
801027fb:	83 c4 10             	add    $0x10,%esp
801027fe:	85 c0                	test   %eax,%eax
80102800:	74 0f                	je     80102811 <kalloc+0x61>
    kmem.freelist = r->next;
80102802:	8b 08                	mov    (%eax),%ecx
    kmem.free_pages--;
80102804:	83 2d 7c 16 11 80 01 	subl   $0x1,0x8011167c
    kmem.freelist = r->next;
8010280b:	89 0d 78 16 11 80    	mov    %ecx,0x80111678
  if(kmem.use_lock)
80102811:	85 d2                	test   %edx,%edx
80102813:	74 16                	je     8010282b <kalloc+0x7b>
    release(&kmem.lock);
80102815:	83 ec 0c             	sub    $0xc,%esp
80102818:	89 45 f4             	mov    %eax,-0xc(%ebp)
8010281b:	68 40 16 11 80       	push   $0x80111640
80102820:	e8 fb 1f 00 00       	call   80104820 <release>
80102825:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102828:	83 c4 10             	add    $0x10,%esp
}
8010282b:	c9                   	leave
8010282c:	c3                   	ret
8010282d:	8d 76 00             	lea    0x0(%esi),%esi

80102830 <freepages_count>:
int
freepages_count(void)
{
  int count;

  if(kmem.use_lock)
80102830:	8b 0d 74 16 11 80    	mov    0x80111674,%ecx
    acquire(&kmem.lock);

  count = kmem.free_pages;
80102836:	a1 7c 16 11 80       	mov    0x8011167c,%eax
  if(kmem.use_lock)
8010283b:	85 c9                	test   %ecx,%ecx
8010283d:	75 01                	jne    80102840 <freepages_count+0x10>

  if(kmem.use_lock)
    release(&kmem.lock);

  return count;
}
8010283f:	c3                   	ret
{
80102840:	55                   	push   %ebp
80102841:	89 e5                	mov    %esp,%ebp
80102843:	83 ec 24             	sub    $0x24,%esp
    acquire(&kmem.lock);
80102846:	68 40 16 11 80       	push   $0x80111640
8010284b:	e8 30 20 00 00       	call   80104880 <acquire>
  if(kmem.use_lock)
80102850:	8b 15 74 16 11 80    	mov    0x80111674,%edx
  count = kmem.free_pages;
80102856:	a1 7c 16 11 80       	mov    0x8011167c,%eax
  if(kmem.use_lock)
8010285b:	83 c4 10             	add    $0x10,%esp
8010285e:	85 d2                	test   %edx,%edx
80102860:	74 16                	je     80102878 <freepages_count+0x48>
    release(&kmem.lock);
80102862:	83 ec 0c             	sub    $0xc,%esp
80102865:	89 45 f4             	mov    %eax,-0xc(%ebp)
80102868:	68 40 16 11 80       	push   $0x80111640
8010286d:	e8 ae 1f 00 00       	call   80104820 <release>
80102872:	8b 45 f4             	mov    -0xc(%ebp),%eax
80102875:	83 c4 10             	add    $0x10,%esp
}
80102878:	c9                   	leave
80102879:	c3                   	ret
8010287a:	66 90                	xchg   %ax,%ax
8010287c:	66 90                	xchg   %ax,%ax
8010287e:	66 90                	xchg   %ax,%ax

80102880 <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102880:	ba 64 00 00 00       	mov    $0x64,%edx
80102885:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80102886:	a8 01                	test   $0x1,%al
80102888:	0f 84 c2 00 00 00    	je     80102950 <kbdgetc+0xd0>
{
8010288e:	55                   	push   %ebp
8010288f:	ba 60 00 00 00       	mov    $0x60,%edx
80102894:	89 e5                	mov    %esp,%ebp
80102896:	53                   	push   %ebx
80102897:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);

  if(data == 0xE0){
    shift |= E0ESC;
80102898:	8b 1d 80 16 11 80    	mov    0x80111680,%ebx
  data = inb(KBDATAP);
8010289e:	0f b6 c8             	movzbl %al,%ecx
  if(data == 0xE0){
801028a1:	3c e0                	cmp    $0xe0,%al
801028a3:	74 53                	je     801028f8 <kbdgetc+0x78>
    return 0;
  } else if(data & 0x80){
801028a5:	84 c0                	test   %al,%al
801028a7:	78 67                	js     80102910 <kbdgetc+0x90>
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
801028a9:	f6 c3 40             	test   $0x40,%bl
801028ac:	74 09                	je     801028b7 <kbdgetc+0x37>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
801028ae:	83 c8 80             	or     $0xffffff80,%eax
    shift &= ~E0ESC;
801028b1:	83 e3 bf             	and    $0xffffffbf,%ebx
    data |= 0x80;
801028b4:	0f b6 c8             	movzbl %al,%ecx
  }

  shift |= shiftcode[data];
801028b7:	0f b6 91 60 7d 10 80 	movzbl -0x7fef82a0(%ecx),%edx
  shift ^= togglecode[data];
801028be:	0f b6 81 60 7c 10 80 	movzbl -0x7fef83a0(%ecx),%eax
  shift |= shiftcode[data];
801028c5:	09 da                	or     %ebx,%edx
  shift ^= togglecode[data];
801028c7:	31 c2                	xor    %eax,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801028c9:	89 d0                	mov    %edx,%eax
  shift ^= togglecode[data];
801028cb:	89 15 80 16 11 80    	mov    %edx,0x80111680
  c = charcode[shift & (CTL | SHIFT)][data];
801028d1:	83 e0 03             	and    $0x3,%eax
  if(shift & CAPSLOCK){
801028d4:	83 e2 08             	and    $0x8,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801028d7:	8b 04 85 40 7c 10 80 	mov    -0x7fef83c0(,%eax,4),%eax
801028de:	0f b6 04 08          	movzbl (%eax,%ecx,1),%eax
  if(shift & CAPSLOCK){
801028e2:	74 0b                	je     801028ef <kbdgetc+0x6f>
    if('a' <= c && c <= 'z')
801028e4:	8d 50 9f             	lea    -0x61(%eax),%edx
801028e7:	83 fa 19             	cmp    $0x19,%edx
801028ea:	77 4c                	ja     80102938 <kbdgetc+0xb8>
      c += 'A' - 'a';
801028ec:	83 e8 20             	sub    $0x20,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
801028ef:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801028f2:	c9                   	leave
801028f3:	c3                   	ret
801028f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    shift |= E0ESC;
801028f8:	83 cb 40             	or     $0x40,%ebx
    return 0;
801028fb:	31 c0                	xor    %eax,%eax
    shift |= E0ESC;
801028fd:	89 1d 80 16 11 80    	mov    %ebx,0x80111680
}
80102903:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102906:	c9                   	leave
80102907:	c3                   	ret
80102908:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010290f:	00 
    data = (shift & E0ESC ? data : data & 0x7F);
80102910:	83 e0 7f             	and    $0x7f,%eax
80102913:	f6 c3 40             	test   $0x40,%bl
80102916:	0f 44 c8             	cmove  %eax,%ecx
    shift &= ~(shiftcode[data] | E0ESC);
80102919:	0f b6 81 60 7d 10 80 	movzbl -0x7fef82a0(%ecx),%eax
80102920:	83 c8 40             	or     $0x40,%eax
80102923:	0f b6 c0             	movzbl %al,%eax
80102926:	f7 d0                	not    %eax
80102928:	21 d8                	and    %ebx,%eax
8010292a:	a3 80 16 11 80       	mov    %eax,0x80111680
    return 0;
8010292f:	31 c0                	xor    %eax,%eax
80102931:	eb d0                	jmp    80102903 <kbdgetc+0x83>
80102933:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    else if('A' <= c && c <= 'Z')
80102938:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010293b:	8d 50 20             	lea    0x20(%eax),%edx
}
8010293e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102941:	c9                   	leave
      c += 'a' - 'A';
80102942:	83 f9 1a             	cmp    $0x1a,%ecx
80102945:	0f 42 c2             	cmovb  %edx,%eax
}
80102948:	c3                   	ret
80102949:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80102950:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80102955:	c3                   	ret
80102956:	66 90                	xchg   %ax,%ax
80102958:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010295f:	00 

80102960 <kbdintr>:

void
kbdintr(void)
{
80102960:	55                   	push   %ebp
80102961:	89 e5                	mov    %esp,%ebp
80102963:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102966:	68 80 28 10 80       	push   $0x80102880
8010296b:	e8 60 df ff ff       	call   801008d0 <consoleintr>
}
80102970:	83 c4 10             	add    $0x10,%esp
80102973:	c9                   	leave
80102974:	c3                   	ret
80102975:	66 90                	xchg   %ax,%ax
80102977:	66 90                	xchg   %ax,%ax
80102979:	66 90                	xchg   %ax,%ax
8010297b:	66 90                	xchg   %ax,%ax
8010297d:	66 90                	xchg   %ax,%ax
8010297f:	90                   	nop

80102980 <lapicinit>:
}

void
lapicinit(void)
{
  if(!lapic)
80102980:	a1 84 16 11 80       	mov    0x80111684,%eax
80102985:	85 c0                	test   %eax,%eax
80102987:	0f 84 cb 00 00 00    	je     80102a58 <lapicinit+0xd8>
  lapic[index] = value;
8010298d:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
80102994:	01 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102997:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010299a:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
801029a1:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029a4:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029a7:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
801029ae:	00 02 00 
  lapic[ID];  // wait for write to finish, by reading
801029b1:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029b4:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
801029bb:	96 98 00 
  lapic[ID];  // wait for write to finish, by reading
801029be:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029c1:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
801029c8:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801029cb:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029ce:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
801029d5:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801029d8:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(LINT0, MASKED);
  lapicw(LINT1, MASKED);

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
801029db:	8b 50 30             	mov    0x30(%eax),%edx
801029de:	81 e2 00 00 fc 00    	and    $0xfc0000,%edx
801029e4:	75 7a                	jne    80102a60 <lapicinit+0xe0>
  lapic[index] = value;
801029e6:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
801029ed:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029f0:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801029f3:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801029fa:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029fd:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a00:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
80102a07:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a0a:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a0d:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102a14:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a17:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a1a:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
80102a21:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a24:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a27:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
80102a2e:	85 08 00 
  lapic[ID];  // wait for write to finish, by reading
80102a31:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(EOI, 0);

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  while(lapic[ICRLO] & DELIVS)
80102a34:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102a38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a3f:	00 
80102a40:	8b 90 00 03 00 00    	mov    0x300(%eax),%edx
80102a46:	80 e6 10             	and    $0x10,%dh
80102a49:	75 f5                	jne    80102a40 <lapicinit+0xc0>
  lapic[index] = value;
80102a4b:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
80102a52:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102a55:	8b 40 20             	mov    0x20(%eax),%eax
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
}
80102a58:	c3                   	ret
80102a59:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  lapic[index] = value;
80102a60:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
80102a67:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102a6a:	8b 50 20             	mov    0x20(%eax),%edx
}
80102a6d:	e9 74 ff ff ff       	jmp    801029e6 <lapicinit+0x66>
80102a72:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102a78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a7f:	00 

80102a80 <lapicid>:

int
lapicid(void)
{
  if (!lapic)
80102a80:	a1 84 16 11 80       	mov    0x80111684,%eax
80102a85:	85 c0                	test   %eax,%eax
80102a87:	74 07                	je     80102a90 <lapicid+0x10>
    return 0;
  return lapic[ID] >> 24;
80102a89:	8b 40 20             	mov    0x20(%eax),%eax
80102a8c:	c1 e8 18             	shr    $0x18,%eax
80102a8f:	c3                   	ret
80102a90:	31 c0                	xor    %eax,%eax
}
80102a92:	c3                   	ret
80102a93:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102a9f:	00 

80102aa0 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  if(lapic)
80102aa0:	a1 84 16 11 80       	mov    0x80111684,%eax
80102aa5:	85 c0                	test   %eax,%eax
80102aa7:	74 0d                	je     80102ab6 <lapiceoi+0x16>
  lapic[index] = value;
80102aa9:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102ab0:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102ab3:	8b 40 20             	mov    0x20(%eax),%eax
    lapicw(EOI, 0);
}
80102ab6:	c3                   	ret
80102ab7:	90                   	nop
80102ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102abf:	00 

80102ac0 <microdelay>:
// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
}
80102ac0:	c3                   	ret
80102ac1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102ac8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102acf:	00 

80102ad0 <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
80102ad0:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ad1:	b8 0f 00 00 00       	mov    $0xf,%eax
80102ad6:	ba 70 00 00 00       	mov    $0x70,%edx
80102adb:	89 e5                	mov    %esp,%ebp
80102add:	56                   	push   %esi
80102ade:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80102ae1:	53                   	push   %ebx
80102ae2:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102ae5:	ee                   	out    %al,(%dx)
80102ae6:	b8 0a 00 00 00       	mov    $0xa,%eax
80102aeb:	ba 71 00 00 00       	mov    $0x71,%edx
80102af0:	ee                   	out    %al,(%dx)
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
  outb(CMOS_PORT+1, 0x0A);
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
  wrv[0] = 0;
80102af1:	31 c0                	xor    %eax,%eax
  lapic[index] = value;
80102af3:	c1 e3 18             	shl    $0x18,%ebx
  wrv[0] = 0;
80102af6:	66 a3 67 04 00 80    	mov    %ax,0x80000467
  wrv[1] = addr >> 4;
80102afc:	89 c8                	mov    %ecx,%eax
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
    lapicw(ICRHI, apicid<<24);
    lapicw(ICRLO, STARTUP | (addr>>12));
80102afe:	c1 e9 0c             	shr    $0xc,%ecx
  wrv[1] = addr >> 4;
80102b01:	c1 e8 04             	shr    $0x4,%eax
    lapicw(ICRLO, STARTUP | (addr>>12));
80102b04:	80 cd 06             	or     $0x6,%ch
  wrv[1] = addr >> 4;
80102b07:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapic[index] = value;
80102b0d:	a1 84 16 11 80       	mov    0x80111684,%eax
80102b12:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b18:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102b1b:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
80102b22:	c5 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102b25:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102b28:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
80102b2f:	85 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102b32:	8b 50 20             	mov    0x20(%eax),%edx
    lapicw(ICRLO, STARTUP | (addr>>12));
80102b35:	ba 02 00 00 00       	mov    $0x2,%edx
  lapic[index] = value;
80102b3a:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b40:	8b 70 20             	mov    0x20(%eax),%esi
  lapic[index] = value;
80102b43:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102b49:	8b 70 20             	mov    0x20(%eax),%esi
  for(i = 0; i < 2; i++){
80102b4c:	83 fa 01             	cmp    $0x1,%edx
80102b4f:	75 07                	jne    80102b58 <lapicstartap+0x88>
    microdelay(200);
  }
}
80102b51:	5b                   	pop    %ebx
80102b52:	5e                   	pop    %esi
80102b53:	5d                   	pop    %ebp
80102b54:	c3                   	ret
80102b55:	8d 76 00             	lea    0x0(%esi),%esi
80102b58:	ba 01 00 00 00       	mov    $0x1,%edx
80102b5d:	eb db                	jmp    80102b3a <lapicstartap+0x6a>
80102b5f:	90                   	nop

80102b60 <cmostime>:
}

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80102b60:	55                   	push   %ebp
80102b61:	b8 0b 00 00 00       	mov    $0xb,%eax
80102b66:	ba 70 00 00 00       	mov    $0x70,%edx
80102b6b:	89 e5                	mov    %esp,%ebp
80102b6d:	57                   	push   %edi
80102b6e:	56                   	push   %esi
80102b6f:	53                   	push   %ebx
80102b70:	83 ec 4c             	sub    $0x4c,%esp
80102b73:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b74:	ba 71 00 00 00       	mov    $0x71,%edx
80102b79:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b7a:	88 45 b4             	mov    %al,-0x4c(%ebp)
80102b7d:	8d 76 00             	lea    0x0(%esi),%esi
80102b80:	31 c0                	xor    %eax,%eax
80102b82:	ba 70 00 00 00       	mov    $0x70,%edx
80102b87:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b88:	ba 71 00 00 00       	mov    $0x71,%edx
80102b8d:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b8e:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b93:	88 45 b7             	mov    %al,-0x49(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b96:	b8 02 00 00 00       	mov    $0x2,%eax
80102b9b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b9c:	ba 71 00 00 00       	mov    $0x71,%edx
80102ba1:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ba2:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102ba7:	88 45 b6             	mov    %al,-0x4a(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102baa:	b8 04 00 00 00       	mov    $0x4,%eax
80102baf:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bb0:	ba 71 00 00 00       	mov    $0x71,%edx
80102bb5:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bb6:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bbb:	88 45 b5             	mov    %al,-0x4b(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bbe:	b8 07 00 00 00       	mov    $0x7,%eax
80102bc3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bc4:	ba 71 00 00 00       	mov    $0x71,%edx
80102bc9:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bca:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bcf:	89 c7                	mov    %eax,%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bd1:	b8 08 00 00 00       	mov    $0x8,%eax
80102bd6:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bd7:	ba 71 00 00 00       	mov    $0x71,%edx
80102bdc:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bdd:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102be2:	89 c6                	mov    %eax,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102be4:	b8 09 00 00 00       	mov    $0x9,%eax
80102be9:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bea:	ba 71 00 00 00       	mov    $0x71,%edx
80102bef:	ec                   	in     (%dx),%al
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bf0:	ba 70 00 00 00       	mov    $0x70,%edx
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bf5:	0f b6 d8             	movzbl %al,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102bf8:	b8 0a 00 00 00       	mov    $0xa,%eax
80102bfd:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102bfe:	ba 71 00 00 00       	mov    $0x71,%edx
80102c03:	ec                   	in     (%dx),%al
  bcd = (sb & (1 << 2)) == 0;

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80102c04:	84 c0                	test   %al,%al
80102c06:	0f 88 74 ff ff ff    	js     80102b80 <cmostime+0x20>
  return inb(CMOS_RETURN);
80102c0c:	0f b6 45 b7          	movzbl -0x49(%ebp),%eax
80102c10:	89 fa                	mov    %edi,%edx
80102c12:	89 5d cc             	mov    %ebx,-0x34(%ebp)
80102c15:	0f b6 fa             	movzbl %dl,%edi
80102c18:	89 f2                	mov    %esi,%edx
80102c1a:	89 45 b8             	mov    %eax,-0x48(%ebp)
80102c1d:	0f b6 45 b6          	movzbl -0x4a(%ebp),%eax
80102c21:	0f b6 f2             	movzbl %dl,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c24:	ba 70 00 00 00       	mov    $0x70,%edx
80102c29:	89 7d c4             	mov    %edi,-0x3c(%ebp)
80102c2c:	89 45 bc             	mov    %eax,-0x44(%ebp)
80102c2f:	0f b6 45 b5          	movzbl -0x4b(%ebp),%eax
80102c33:	89 75 c8             	mov    %esi,-0x38(%ebp)
80102c36:	89 45 c0             	mov    %eax,-0x40(%ebp)
80102c39:	31 c0                	xor    %eax,%eax
80102c3b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c3c:	ba 71 00 00 00       	mov    $0x71,%edx
80102c41:	ec                   	in     (%dx),%al
80102c42:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c45:	ba 70 00 00 00       	mov    $0x70,%edx
80102c4a:	89 45 d0             	mov    %eax,-0x30(%ebp)
80102c4d:	b8 02 00 00 00       	mov    $0x2,%eax
80102c52:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c53:	ba 71 00 00 00       	mov    $0x71,%edx
80102c58:	ec                   	in     (%dx),%al
80102c59:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c5c:	ba 70 00 00 00       	mov    $0x70,%edx
80102c61:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80102c64:	b8 04 00 00 00       	mov    $0x4,%eax
80102c69:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c6a:	ba 71 00 00 00       	mov    $0x71,%edx
80102c6f:	ec                   	in     (%dx),%al
80102c70:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c73:	ba 70 00 00 00       	mov    $0x70,%edx
80102c78:	89 45 d8             	mov    %eax,-0x28(%ebp)
80102c7b:	b8 07 00 00 00       	mov    $0x7,%eax
80102c80:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c81:	ba 71 00 00 00       	mov    $0x71,%edx
80102c86:	ec                   	in     (%dx),%al
80102c87:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102c8a:	ba 70 00 00 00       	mov    $0x70,%edx
80102c8f:	89 45 dc             	mov    %eax,-0x24(%ebp)
80102c92:	b8 08 00 00 00       	mov    $0x8,%eax
80102c97:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102c98:	ba 71 00 00 00       	mov    $0x71,%edx
80102c9d:	ec                   	in     (%dx),%al
80102c9e:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ca1:	ba 70 00 00 00       	mov    $0x70,%edx
80102ca6:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102ca9:	b8 09 00 00 00       	mov    $0x9,%eax
80102cae:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102caf:	ba 71 00 00 00       	mov    $0x71,%edx
80102cb4:	ec                   	in     (%dx),%al
80102cb5:	0f b6 c0             	movzbl %al,%eax
        continue;
    fill_rtcdate(&t2);
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102cb8:	83 ec 04             	sub    $0x4,%esp
  return inb(CMOS_RETURN);
80102cbb:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102cbe:	8d 45 d0             	lea    -0x30(%ebp),%eax
80102cc1:	6a 18                	push   $0x18
80102cc3:	50                   	push   %eax
80102cc4:	8d 45 b8             	lea    -0x48(%ebp),%eax
80102cc7:	50                   	push   %eax
80102cc8:	e8 13 1d 00 00       	call   801049e0 <memcmp>
80102ccd:	83 c4 10             	add    $0x10,%esp
80102cd0:	85 c0                	test   %eax,%eax
80102cd2:	0f 85 a8 fe ff ff    	jne    80102b80 <cmostime+0x20>
      break;
  }

  // convert
  if(bcd) {
80102cd8:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102cdb:	f6 45 b4 04          	testb  $0x4,-0x4c(%ebp)
80102cdf:	75 78                	jne    80102d59 <cmostime+0x1f9>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
80102ce1:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102ce4:	89 c2                	mov    %eax,%edx
80102ce6:	83 e0 0f             	and    $0xf,%eax
80102ce9:	c1 ea 04             	shr    $0x4,%edx
80102cec:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102cef:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102cf2:	89 45 b8             	mov    %eax,-0x48(%ebp)
    CONV(minute);
80102cf5:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102cf8:	89 c2                	mov    %eax,%edx
80102cfa:	83 e0 0f             	and    $0xf,%eax
80102cfd:	c1 ea 04             	shr    $0x4,%edx
80102d00:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d03:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d06:	89 45 bc             	mov    %eax,-0x44(%ebp)
    CONV(hour  );
80102d09:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102d0c:	89 c2                	mov    %eax,%edx
80102d0e:	83 e0 0f             	and    $0xf,%eax
80102d11:	c1 ea 04             	shr    $0x4,%edx
80102d14:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d17:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d1a:	89 45 c0             	mov    %eax,-0x40(%ebp)
    CONV(day   );
80102d1d:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102d20:	89 c2                	mov    %eax,%edx
80102d22:	83 e0 0f             	and    $0xf,%eax
80102d25:	c1 ea 04             	shr    $0x4,%edx
80102d28:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d2b:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d2e:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    CONV(month );
80102d31:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102d34:	89 c2                	mov    %eax,%edx
80102d36:	83 e0 0f             	and    $0xf,%eax
80102d39:	c1 ea 04             	shr    $0x4,%edx
80102d3c:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d3f:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d42:	89 45 c8             	mov    %eax,-0x38(%ebp)
    CONV(year  );
80102d45:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102d48:	89 c2                	mov    %eax,%edx
80102d4a:	83 e0 0f             	and    $0xf,%eax
80102d4d:	c1 ea 04             	shr    $0x4,%edx
80102d50:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102d53:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102d56:	89 45 cc             	mov    %eax,-0x34(%ebp)
#undef     CONV
  }

  *r = t1;
80102d59:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102d5c:	89 03                	mov    %eax,(%ebx)
80102d5e:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102d61:	89 43 04             	mov    %eax,0x4(%ebx)
80102d64:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102d67:	89 43 08             	mov    %eax,0x8(%ebx)
80102d6a:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102d6d:	89 43 0c             	mov    %eax,0xc(%ebx)
80102d70:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102d73:	89 43 10             	mov    %eax,0x10(%ebx)
80102d76:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102d79:	89 43 14             	mov    %eax,0x14(%ebx)
  r->year += 2000;
80102d7c:	81 43 14 d0 07 00 00 	addl   $0x7d0,0x14(%ebx)
}
80102d83:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102d86:	5b                   	pop    %ebx
80102d87:	5e                   	pop    %esi
80102d88:	5f                   	pop    %edi
80102d89:	5d                   	pop    %ebp
80102d8a:	c3                   	ret
80102d8b:	66 90                	xchg   %ax,%ax
80102d8d:	66 90                	xchg   %ax,%ax
80102d8f:	66 90                	xchg   %ax,%ax
80102d91:	66 90                	xchg   %ax,%ax
80102d93:	66 90                	xchg   %ax,%ax
80102d95:	66 90                	xchg   %ax,%ax
80102d97:	66 90                	xchg   %ax,%ax
80102d99:	66 90                	xchg   %ax,%ax
80102d9b:	66 90                	xchg   %ax,%ax
80102d9d:	66 90                	xchg   %ax,%ax
80102d9f:	90                   	nop

80102da0 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80102da0:	8b 0d e8 16 11 80    	mov    0x801116e8,%ecx
80102da6:	85 c9                	test   %ecx,%ecx
80102da8:	0f 8e 8a 00 00 00    	jle    80102e38 <install_trans+0x98>
{
80102dae:	55                   	push   %ebp
80102daf:	89 e5                	mov    %esp,%ebp
80102db1:	57                   	push   %edi
  for (tail = 0; tail < log.lh.n; tail++) {
80102db2:	31 ff                	xor    %edi,%edi
{
80102db4:	56                   	push   %esi
80102db5:	53                   	push   %ebx
80102db6:	83 ec 0c             	sub    $0xc,%esp
80102db9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80102dc0:	a1 d4 16 11 80       	mov    0x801116d4,%eax
80102dc5:	83 ec 08             	sub    $0x8,%esp
80102dc8:	8d 44 38 01          	lea    0x1(%eax,%edi,1),%eax
80102dcc:	50                   	push   %eax
80102dcd:	ff 35 e4 16 11 80    	push   0x801116e4
80102dd3:	e8 f8 d2 ff ff       	call   801000d0 <bread>
80102dd8:	89 c6                	mov    %eax,%esi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102dda:	58                   	pop    %eax
80102ddb:	5a                   	pop    %edx
80102ddc:	ff 34 bd ec 16 11 80 	push   -0x7feee914(,%edi,4)
80102de3:	ff 35 e4 16 11 80    	push   0x801116e4
  for (tail = 0; tail < log.lh.n; tail++) {
80102de9:	83 c7 01             	add    $0x1,%edi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102dec:	e8 df d2 ff ff       	call   801000d0 <bread>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102df1:	83 c4 0c             	add    $0xc,%esp
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102df4:	89 c3                	mov    %eax,%ebx
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102df6:	8d 46 5c             	lea    0x5c(%esi),%eax
80102df9:	68 00 02 00 00       	push   $0x200
80102dfe:	50                   	push   %eax
80102dff:	8d 43 5c             	lea    0x5c(%ebx),%eax
80102e02:	50                   	push   %eax
80102e03:	e8 28 1c 00 00       	call   80104a30 <memmove>
    bwrite(dbuf);  // write dst to disk
80102e08:	89 1c 24             	mov    %ebx,(%esp)
80102e0b:	e8 b0 d3 ff ff       	call   801001c0 <bwrite>
    brelse(lbuf);
80102e10:	89 34 24             	mov    %esi,(%esp)
80102e13:	e8 e8 d3 ff ff       	call   80100200 <brelse>
    brelse(dbuf);
80102e18:	89 1c 24             	mov    %ebx,(%esp)
80102e1b:	e8 e0 d3 ff ff       	call   80100200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80102e20:	83 c4 10             	add    $0x10,%esp
80102e23:	39 3d e8 16 11 80    	cmp    %edi,0x801116e8
80102e29:	7f 95                	jg     80102dc0 <install_trans+0x20>
  }
}
80102e2b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102e2e:	5b                   	pop    %ebx
80102e2f:	5e                   	pop    %esi
80102e30:	5f                   	pop    %edi
80102e31:	5d                   	pop    %ebp
80102e32:	c3                   	ret
80102e33:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e38:	c3                   	ret
80102e39:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102e40 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
80102e40:	55                   	push   %ebp
80102e41:	89 e5                	mov    %esp,%ebp
80102e43:	53                   	push   %ebx
80102e44:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
80102e47:	ff 35 d4 16 11 80    	push   0x801116d4
80102e4d:	ff 35 e4 16 11 80    	push   0x801116e4
80102e53:	e8 78 d2 ff ff       	call   801000d0 <bread>
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
  for (i = 0; i < log.lh.n; i++) {
80102e58:	83 c4 10             	add    $0x10,%esp
  struct buf *buf = bread(log.dev, log.start);
80102e5b:	89 c3                	mov    %eax,%ebx
  hb->n = log.lh.n;
80102e5d:	a1 e8 16 11 80       	mov    0x801116e8,%eax
80102e62:	89 43 5c             	mov    %eax,0x5c(%ebx)
  for (i = 0; i < log.lh.n; i++) {
80102e65:	85 c0                	test   %eax,%eax
80102e67:	7e 29                	jle    80102e92 <write_head+0x52>
80102e69:	31 d2                	xor    %edx,%edx
80102e6b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e70:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e77:	00 
80102e78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e7f:	00 
    hb->block[i] = log.lh.block[i];
80102e80:	8b 0c 95 ec 16 11 80 	mov    -0x7feee914(,%edx,4),%ecx
80102e87:	89 4c 93 60          	mov    %ecx,0x60(%ebx,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102e8b:	83 c2 01             	add    $0x1,%edx
80102e8e:	39 d0                	cmp    %edx,%eax
80102e90:	75 ee                	jne    80102e80 <write_head+0x40>
  }
  bwrite(buf);
80102e92:	83 ec 0c             	sub    $0xc,%esp
80102e95:	53                   	push   %ebx
80102e96:	e8 25 d3 ff ff       	call   801001c0 <bwrite>
  brelse(buf);
80102e9b:	89 1c 24             	mov    %ebx,(%esp)
80102e9e:	e8 5d d3 ff ff       	call   80100200 <brelse>
}
80102ea3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102ea6:	83 c4 10             	add    $0x10,%esp
80102ea9:	c9                   	leave
80102eaa:	c3                   	ret
80102eab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102eb0 <initlog>:
{
80102eb0:	55                   	push   %ebp
80102eb1:	89 e5                	mov    %esp,%ebp
80102eb3:	53                   	push   %ebx
80102eb4:	83 ec 2c             	sub    $0x2c,%esp
80102eb7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
80102eba:	68 77 77 10 80       	push   $0x80107777
80102ebf:	68 a0 16 11 80       	push   $0x801116a0
80102ec4:	e8 97 17 00 00       	call   80104660 <initlock>
  readsb(dev, &sb);
80102ec9:	58                   	pop    %eax
80102eca:	8d 45 dc             	lea    -0x24(%ebp),%eax
80102ecd:	5a                   	pop    %edx
80102ece:	50                   	push   %eax
80102ecf:	53                   	push   %ebx
80102ed0:	e8 2b e7 ff ff       	call   80101600 <readsb>
  log.start = sb.logstart;
80102ed5:	8b 45 ec             	mov    -0x14(%ebp),%eax
  struct buf *buf = bread(log.dev, log.start);
80102ed8:	59                   	pop    %ecx
  log.dev = dev;
80102ed9:	89 1d e4 16 11 80    	mov    %ebx,0x801116e4
  log.size = sb.nlog;
80102edf:	8b 55 e8             	mov    -0x18(%ebp),%edx
  log.start = sb.logstart;
80102ee2:	a3 d4 16 11 80       	mov    %eax,0x801116d4
  log.size = sb.nlog;
80102ee7:	89 15 d8 16 11 80    	mov    %edx,0x801116d8
  struct buf *buf = bread(log.dev, log.start);
80102eed:	5a                   	pop    %edx
80102eee:	50                   	push   %eax
80102eef:	53                   	push   %ebx
80102ef0:	e8 db d1 ff ff       	call   801000d0 <bread>
  for (i = 0; i < log.lh.n; i++) {
80102ef5:	83 c4 10             	add    $0x10,%esp
  log.lh.n = lh->n;
80102ef8:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102efb:	89 1d e8 16 11 80    	mov    %ebx,0x801116e8
  for (i = 0; i < log.lh.n; i++) {
80102f01:	85 db                	test   %ebx,%ebx
80102f03:	7e 2d                	jle    80102f32 <initlog+0x82>
80102f05:	31 d2                	xor    %edx,%edx
80102f07:	eb 17                	jmp    80102f20 <initlog+0x70>
80102f09:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80102f10:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f17:	00 
80102f18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f1f:	00 
    log.lh.block[i] = lh->block[i];
80102f20:	8b 4c 90 60          	mov    0x60(%eax,%edx,4),%ecx
80102f24:	89 0c 95 ec 16 11 80 	mov    %ecx,-0x7feee914(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102f2b:	83 c2 01             	add    $0x1,%edx
80102f2e:	39 d3                	cmp    %edx,%ebx
80102f30:	75 ee                	jne    80102f20 <initlog+0x70>
  brelse(buf);
80102f32:	83 ec 0c             	sub    $0xc,%esp
80102f35:	50                   	push   %eax
80102f36:	e8 c5 d2 ff ff       	call   80100200 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
80102f3b:	e8 60 fe ff ff       	call   80102da0 <install_trans>
  log.lh.n = 0;
80102f40:	c7 05 e8 16 11 80 00 	movl   $0x0,0x801116e8
80102f47:	00 00 00 
  write_head(); // clear the log
80102f4a:	e8 f1 fe ff ff       	call   80102e40 <write_head>
}
80102f4f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102f52:	83 c4 10             	add    $0x10,%esp
80102f55:	c9                   	leave
80102f56:	c3                   	ret
80102f57:	90                   	nop
80102f58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f5f:	00 

80102f60 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
80102f60:	55                   	push   %ebp
80102f61:	89 e5                	mov    %esp,%ebp
80102f63:	83 ec 14             	sub    $0x14,%esp
  acquire(&log.lock);
80102f66:	68 a0 16 11 80       	push   $0x801116a0
80102f6b:	e8 10 19 00 00       	call   80104880 <acquire>
80102f70:	83 c4 10             	add    $0x10,%esp
80102f73:	eb 18                	jmp    80102f8d <begin_op+0x2d>
80102f75:	8d 76 00             	lea    0x0(%esi),%esi
  while(1){
    if(log.committing){
      sleep(&log, &log.lock);
80102f78:	83 ec 08             	sub    $0x8,%esp
80102f7b:	68 a0 16 11 80       	push   $0x801116a0
80102f80:	68 a0 16 11 80       	push   $0x801116a0
80102f85:	e8 36 13 00 00       	call   801042c0 <sleep>
80102f8a:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
80102f8d:	a1 e0 16 11 80       	mov    0x801116e0,%eax
80102f92:	85 c0                	test   %eax,%eax
80102f94:	75 e2                	jne    80102f78 <begin_op+0x18>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80102f96:	a1 dc 16 11 80       	mov    0x801116dc,%eax
80102f9b:	8b 15 e8 16 11 80    	mov    0x801116e8,%edx
80102fa1:	83 c0 01             	add    $0x1,%eax
80102fa4:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
80102fa7:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
80102faa:	83 fa 1e             	cmp    $0x1e,%edx
80102fad:	7f c9                	jg     80102f78 <begin_op+0x18>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
80102faf:	83 ec 0c             	sub    $0xc,%esp
      log.outstanding += 1;
80102fb2:	a3 dc 16 11 80       	mov    %eax,0x801116dc
      release(&log.lock);
80102fb7:	68 a0 16 11 80       	push   $0x801116a0
80102fbc:	e8 5f 18 00 00       	call   80104820 <release>
      break;
    }
  }
}
80102fc1:	83 c4 10             	add    $0x10,%esp
80102fc4:	c9                   	leave
80102fc5:	c3                   	ret
80102fc6:	66 90                	xchg   %ax,%ax
80102fc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102fcf:	00 

80102fd0 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80102fd0:	55                   	push   %ebp
80102fd1:	89 e5                	mov    %esp,%ebp
80102fd3:	57                   	push   %edi
80102fd4:	56                   	push   %esi
80102fd5:	53                   	push   %ebx
80102fd6:	83 ec 18             	sub    $0x18,%esp
  int do_commit = 0;

  acquire(&log.lock);
80102fd9:	68 a0 16 11 80       	push   $0x801116a0
80102fde:	e8 9d 18 00 00       	call   80104880 <acquire>
  log.outstanding -= 1;
80102fe3:	a1 dc 16 11 80       	mov    0x801116dc,%eax
  if(log.committing)
80102fe8:	8b 35 e0 16 11 80    	mov    0x801116e0,%esi
80102fee:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
80102ff1:	8d 58 ff             	lea    -0x1(%eax),%ebx
80102ff4:	89 1d dc 16 11 80    	mov    %ebx,0x801116dc
  if(log.committing)
80102ffa:	85 f6                	test   %esi,%esi
80102ffc:	0f 85 22 01 00 00    	jne    80103124 <end_op+0x154>
    panic("log.committing");
  if(log.outstanding == 0){
80103002:	85 db                	test   %ebx,%ebx
80103004:	0f 85 f6 00 00 00    	jne    80103100 <end_op+0x130>
    do_commit = 1;
    log.committing = 1;
8010300a:	c7 05 e0 16 11 80 01 	movl   $0x1,0x801116e0
80103011:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
80103014:	83 ec 0c             	sub    $0xc,%esp
80103017:	68 a0 16 11 80       	push   $0x801116a0
8010301c:	e8 ff 17 00 00       	call   80104820 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80103021:	8b 0d e8 16 11 80    	mov    0x801116e8,%ecx
80103027:	83 c4 10             	add    $0x10,%esp
8010302a:	85 c9                	test   %ecx,%ecx
8010302c:	7f 42                	jg     80103070 <end_op+0xa0>
    acquire(&log.lock);
8010302e:	83 ec 0c             	sub    $0xc,%esp
80103031:	68 a0 16 11 80       	push   $0x801116a0
80103036:	e8 45 18 00 00       	call   80104880 <acquire>
    log.committing = 0;
8010303b:	c7 05 e0 16 11 80 00 	movl   $0x0,0x801116e0
80103042:	00 00 00 
    wakeup(&log);
80103045:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
8010304c:	e8 2f 13 00 00       	call   80104380 <wakeup>
    release(&log.lock);
80103051:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
80103058:	e8 c3 17 00 00       	call   80104820 <release>
8010305d:	83 c4 10             	add    $0x10,%esp
}
80103060:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103063:	5b                   	pop    %ebx
80103064:	5e                   	pop    %esi
80103065:	5f                   	pop    %edi
80103066:	5d                   	pop    %ebp
80103067:	c3                   	ret
80103068:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010306f:	00 
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80103070:	a1 d4 16 11 80       	mov    0x801116d4,%eax
80103075:	83 ec 08             	sub    $0x8,%esp
80103078:	8d 44 18 01          	lea    0x1(%eax,%ebx,1),%eax
8010307c:	50                   	push   %eax
8010307d:	ff 35 e4 16 11 80    	push   0x801116e4
80103083:	e8 48 d0 ff ff       	call   801000d0 <bread>
80103088:	89 c6                	mov    %eax,%esi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010308a:	58                   	pop    %eax
8010308b:	5a                   	pop    %edx
8010308c:	ff 34 9d ec 16 11 80 	push   -0x7feee914(,%ebx,4)
80103093:	ff 35 e4 16 11 80    	push   0x801116e4
  for (tail = 0; tail < log.lh.n; tail++) {
80103099:	83 c3 01             	add    $0x1,%ebx
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010309c:	e8 2f d0 ff ff       	call   801000d0 <bread>
    memmove(to->data, from->data, BSIZE);
801030a1:	83 c4 0c             	add    $0xc,%esp
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
801030a4:	89 c7                	mov    %eax,%edi
    memmove(to->data, from->data, BSIZE);
801030a6:	8d 40 5c             	lea    0x5c(%eax),%eax
801030a9:	68 00 02 00 00       	push   $0x200
801030ae:	50                   	push   %eax
801030af:	8d 46 5c             	lea    0x5c(%esi),%eax
801030b2:	50                   	push   %eax
801030b3:	e8 78 19 00 00       	call   80104a30 <memmove>
    bwrite(to);  // write the log
801030b8:	89 34 24             	mov    %esi,(%esp)
801030bb:	e8 00 d1 ff ff       	call   801001c0 <bwrite>
    brelse(from);
801030c0:	89 3c 24             	mov    %edi,(%esp)
801030c3:	e8 38 d1 ff ff       	call   80100200 <brelse>
    brelse(to);
801030c8:	89 34 24             	mov    %esi,(%esp)
801030cb:	e8 30 d1 ff ff       	call   80100200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801030d0:	83 c4 10             	add    $0x10,%esp
801030d3:	3b 1d e8 16 11 80    	cmp    0x801116e8,%ebx
801030d9:	7c 95                	jl     80103070 <end_op+0xa0>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
801030db:	e8 60 fd ff ff       	call   80102e40 <write_head>
    install_trans(); // Now install writes to home locations
801030e0:	e8 bb fc ff ff       	call   80102da0 <install_trans>
    log.lh.n = 0;
801030e5:	c7 05 e8 16 11 80 00 	movl   $0x0,0x801116e8
801030ec:	00 00 00 
    write_head();    // Erase the transaction from the log
801030ef:	e8 4c fd ff ff       	call   80102e40 <write_head>
801030f4:	e9 35 ff ff ff       	jmp    8010302e <end_op+0x5e>
801030f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    wakeup(&log);
80103100:	83 ec 0c             	sub    $0xc,%esp
80103103:	68 a0 16 11 80       	push   $0x801116a0
80103108:	e8 73 12 00 00       	call   80104380 <wakeup>
  release(&log.lock);
8010310d:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
80103114:	e8 07 17 00 00       	call   80104820 <release>
80103119:	83 c4 10             	add    $0x10,%esp
}
8010311c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010311f:	5b                   	pop    %ebx
80103120:	5e                   	pop    %esi
80103121:	5f                   	pop    %edi
80103122:	5d                   	pop    %ebp
80103123:	c3                   	ret
    panic("log.committing");
80103124:	83 ec 0c             	sub    $0xc,%esp
80103127:	68 7b 77 10 80       	push   $0x8010777b
8010312c:	e8 6f d2 ff ff       	call   801003a0 <panic>
80103131:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010313f:	00 

80103140 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
80103140:	55                   	push   %ebp
80103141:	89 e5                	mov    %esp,%ebp
80103143:	53                   	push   %ebx
80103144:	83 ec 04             	sub    $0x4,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103147:	8b 15 e8 16 11 80    	mov    0x801116e8,%edx
{
8010314d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103150:	83 fa 1d             	cmp    $0x1d,%edx
80103153:	7f 7d                	jg     801031d2 <log_write+0x92>
80103155:	a1 d8 16 11 80       	mov    0x801116d8,%eax
8010315a:	83 e8 01             	sub    $0x1,%eax
8010315d:	39 c2                	cmp    %eax,%edx
8010315f:	7d 71                	jge    801031d2 <log_write+0x92>
    panic("too big a transaction");
  if (log.outstanding < 1)
80103161:	a1 dc 16 11 80       	mov    0x801116dc,%eax
80103166:	85 c0                	test   %eax,%eax
80103168:	7e 75                	jle    801031df <log_write+0x9f>
    panic("log_write outside of trans");

  acquire(&log.lock);
8010316a:	83 ec 0c             	sub    $0xc,%esp
8010316d:	68 a0 16 11 80       	push   $0x801116a0
80103172:	e8 09 17 00 00       	call   80104880 <acquire>
  for (i = 0; i < log.lh.n; i++) {
    if (log.lh.block[i] == b->blockno)   // log absorbtion
      break;
  }
  log.lh.block[i] = b->blockno;
80103177:	8b 4b 08             	mov    0x8(%ebx),%ecx
  for (i = 0; i < log.lh.n; i++) {
8010317a:	83 c4 10             	add    $0x10,%esp
8010317d:	31 c0                	xor    %eax,%eax
8010317f:	8b 15 e8 16 11 80    	mov    0x801116e8,%edx
80103185:	85 d2                	test   %edx,%edx
80103187:	7f 0e                	jg     80103197 <log_write+0x57>
80103189:	eb 15                	jmp    801031a0 <log_write+0x60>
8010318b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103190:	83 c0 01             	add    $0x1,%eax
80103193:	39 d0                	cmp    %edx,%eax
80103195:	74 29                	je     801031c0 <log_write+0x80>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103197:	39 0c 85 ec 16 11 80 	cmp    %ecx,-0x7feee914(,%eax,4)
8010319e:	75 f0                	jne    80103190 <log_write+0x50>
  log.lh.block[i] = b->blockno;
801031a0:	89 0c 85 ec 16 11 80 	mov    %ecx,-0x7feee914(,%eax,4)
  if (i == log.lh.n)
801031a7:	39 c2                	cmp    %eax,%edx
801031a9:	74 1c                	je     801031c7 <log_write+0x87>
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
801031ab:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
}
801031ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  release(&log.lock);
801031b1:	c7 45 08 a0 16 11 80 	movl   $0x801116a0,0x8(%ebp)
}
801031b8:	c9                   	leave
  release(&log.lock);
801031b9:	e9 62 16 00 00       	jmp    80104820 <release>
801031be:	66 90                	xchg   %ax,%ax
  log.lh.block[i] = b->blockno;
801031c0:	89 0c 95 ec 16 11 80 	mov    %ecx,-0x7feee914(,%edx,4)
    log.lh.n++;
801031c7:	83 c2 01             	add    $0x1,%edx
801031ca:	89 15 e8 16 11 80    	mov    %edx,0x801116e8
801031d0:	eb d9                	jmp    801031ab <log_write+0x6b>
    panic("too big a transaction");
801031d2:	83 ec 0c             	sub    $0xc,%esp
801031d5:	68 8a 77 10 80       	push   $0x8010778a
801031da:	e8 c1 d1 ff ff       	call   801003a0 <panic>
    panic("log_write outside of trans");
801031df:	83 ec 0c             	sub    $0xc,%esp
801031e2:	68 a0 77 10 80       	push   $0x801077a0
801031e7:	e8 b4 d1 ff ff       	call   801003a0 <panic>
801031ec:	66 90                	xchg   %ax,%ax
801031ee:	66 90                	xchg   %ax,%ax

801031f0 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
801031f0:	55                   	push   %ebp
801031f1:	89 e5                	mov    %esp,%ebp
801031f3:	53                   	push   %ebx
801031f4:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
801031f7:	e8 c4 09 00 00       	call   80103bc0 <cpuid>
801031fc:	89 c3                	mov    %eax,%ebx
801031fe:	e8 bd 09 00 00       	call   80103bc0 <cpuid>
80103203:	83 ec 04             	sub    $0x4,%esp
80103206:	53                   	push   %ebx
80103207:	50                   	push   %eax
80103208:	68 bb 77 10 80       	push   $0x801077bb
8010320d:	e8 be d4 ff ff       	call   801006d0 <cprintf>
  idtinit();       // load idt register
80103212:	e8 99 2a 00 00       	call   80105cb0 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
80103217:	e8 24 09 00 00       	call   80103b40 <mycpu>
8010321c:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
8010321e:	b8 01 00 00 00       	mov    $0x1,%eax
80103223:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
8010322a:	e8 61 0c 00 00       	call   80103e90 <scheduler>
8010322f:	90                   	nop

80103230 <mpenter>:
{
80103230:	55                   	push   %ebp
80103231:	89 e5                	mov    %esp,%ebp
80103233:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80103236:	e8 f5 3b 00 00       	call   80106e30 <switchkvm>
  seginit();
8010323b:	e8 f0 3a 00 00       	call   80106d30 <seginit>
  lapicinit();
80103240:	e8 3b f7 ff ff       	call   80102980 <lapicinit>
  mpmain();
80103245:	e8 a6 ff ff ff       	call   801031f0 <mpmain>
8010324a:	66 90                	xchg   %ax,%ax
8010324c:	66 90                	xchg   %ax,%ax
8010324e:	66 90                	xchg   %ax,%ax

80103250 <main>:
{
80103250:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80103254:	83 e4 f0             	and    $0xfffffff0,%esp
80103257:	ff 71 fc             	push   -0x4(%ecx)
8010325a:	55                   	push   %ebp
8010325b:	89 e5                	mov    %esp,%ebp
8010325d:	53                   	push   %ebx
8010325e:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
8010325f:	83 ec 08             	sub    $0x8,%esp
80103262:	68 00 00 40 80       	push   $0x80400000
80103267:	68 d0 54 11 80       	push   $0x801154d0
8010326c:	e8 bf f4 ff ff       	call   80102730 <kinit1>
  kvmalloc();      // kernel page table
80103271:	e8 7a 40 00 00       	call   801072f0 <kvmalloc>
  mpinit();        // detect other processors
80103276:	e8 85 01 00 00       	call   80103400 <mpinit>
  lapicinit();     // interrupt controller
8010327b:	e8 00 f7 ff ff       	call   80102980 <lapicinit>
  seginit();       // segment descriptors
80103280:	e8 ab 3a 00 00       	call   80106d30 <seginit>
  picinit();       // disable pic
80103285:	e8 76 03 00 00       	call   80103600 <picinit>
  ioapicinit();    // another interrupt controller
8010328a:	e8 31 f2 ff ff       	call   801024c0 <ioapicinit>
  consoleinit();   // console hardware
8010328f:	e8 2c d8 ff ff       	call   80100ac0 <consoleinit>
  uartinit();      // serial port
80103294:	e8 17 2d 00 00       	call   80105fb0 <uartinit>
  pinit();         // process table
80103299:	e8 82 08 00 00       	call   80103b20 <pinit>
  tvinit();        // trap vectors
8010329e:	e8 5d 29 00 00       	call   80105c00 <tvinit>
  binit();         // buffer cache
801032a3:	e8 98 cd ff ff       	call   80100040 <binit>
  fileinit();      // file table
801032a8:	e8 f3 db ff ff       	call   80100ea0 <fileinit>
  ideinit();       // disk 
801032ad:	e8 ee ef ff ff       	call   801022a0 <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
801032b2:	83 c4 0c             	add    $0xc,%esp
801032b5:	68 8a 00 00 00       	push   $0x8a
801032ba:	68 8c a4 10 80       	push   $0x8010a48c
801032bf:	68 00 70 00 80       	push   $0x80007000
801032c4:	e8 67 17 00 00       	call   80104a30 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
801032c9:	83 c4 10             	add    $0x10,%esp
801032cc:	69 05 84 17 11 80 b0 	imul   $0xb0,0x80111784,%eax
801032d3:	00 00 00 
801032d6:	05 a0 17 11 80       	add    $0x801117a0,%eax
801032db:	3d a0 17 11 80       	cmp    $0x801117a0,%eax
801032e0:	76 7e                	jbe    80103360 <main+0x110>
801032e2:	bb a0 17 11 80       	mov    $0x801117a0,%ebx
801032e7:	eb 20                	jmp    80103309 <main+0xb9>
801032e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801032f0:	69 05 84 17 11 80 b0 	imul   $0xb0,0x80111784,%eax
801032f7:	00 00 00 
801032fa:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80103300:	05 a0 17 11 80       	add    $0x801117a0,%eax
80103305:	39 c3                	cmp    %eax,%ebx
80103307:	73 57                	jae    80103360 <main+0x110>
    if(c == mycpu())  // We've started already.
80103309:	e8 32 08 00 00       	call   80103b40 <mycpu>
8010330e:	39 d8                	cmp    %ebx,%eax
80103310:	74 de                	je     801032f0 <main+0xa0>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80103312:	e8 99 f4 ff ff       	call   801027b0 <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
    *(void(**)(void))(code-8) = mpenter;
    *(int**)(code-12) = (void *) V2P(entrypgdir);

    lapicstartap(c->apicid, V2P(code));
80103317:	83 ec 08             	sub    $0x8,%esp
    *(void(**)(void))(code-8) = mpenter;
8010331a:	c7 05 f8 6f 00 80 30 	movl   $0x80103230,0x80006ff8
80103321:	32 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80103324:	c7 05 f4 6f 00 80 00 	movl   $0x109000,0x80006ff4
8010332b:	90 10 00 
    *(void**)(code-4) = stack + KSTACKSIZE;
8010332e:	05 00 10 00 00       	add    $0x1000,%eax
80103333:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    lapicstartap(c->apicid, V2P(code));
80103338:	0f b6 03             	movzbl (%ebx),%eax
8010333b:	68 00 70 00 00       	push   $0x7000
80103340:	50                   	push   %eax
80103341:	e8 8a f7 ff ff       	call   80102ad0 <lapicstartap>

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80103346:	83 c4 10             	add    $0x10,%esp
80103349:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103350:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80103356:	85 c0                	test   %eax,%eax
80103358:	74 f6                	je     80103350 <main+0x100>
8010335a:	eb 94                	jmp    801032f0 <main+0xa0>
8010335c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80103360:	83 ec 08             	sub    $0x8,%esp
80103363:	68 00 00 00 8e       	push   $0x8e000000
80103368:	68 00 00 40 80       	push   $0x80400000
8010336d:	e8 5e f3 ff ff       	call   801026d0 <kinit2>
  userinit();      // first user process
80103372:	e8 99 08 00 00       	call   80103c10 <userinit>
  mpmain();        // finish this processor's setup
80103377:	e8 74 fe ff ff       	call   801031f0 <mpmain>
8010337c:	66 90                	xchg   %ax,%ax
8010337e:	66 90                	xchg   %ax,%ax

80103380 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80103380:	55                   	push   %ebp
80103381:	89 e5                	mov    %esp,%ebp
80103383:	57                   	push   %edi
80103384:	56                   	push   %esi
  uchar *e, *p, *addr;

  addr = P2V(a);
80103385:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
{
8010338b:	53                   	push   %ebx
  e = addr+len;
8010338c:	8d 1c 16             	lea    (%esi,%edx,1),%ebx
{
8010338f:	83 ec 0c             	sub    $0xc,%esp
  for(p = addr; p < e; p += sizeof(struct mp))
80103392:	39 de                	cmp    %ebx,%esi
80103394:	72 10                	jb     801033a6 <mpsearch1+0x26>
80103396:	eb 58                	jmp    801033f0 <mpsearch1+0x70>
80103398:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010339f:	00 
801033a0:	89 fe                	mov    %edi,%esi
801033a2:	39 df                	cmp    %ebx,%edi
801033a4:	73 4a                	jae    801033f0 <mpsearch1+0x70>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801033a6:	83 ec 04             	sub    $0x4,%esp
801033a9:	8d 7e 10             	lea    0x10(%esi),%edi
801033ac:	6a 04                	push   $0x4
801033ae:	68 cf 77 10 80       	push   $0x801077cf
801033b3:	56                   	push   %esi
801033b4:	e8 27 16 00 00       	call   801049e0 <memcmp>
801033b9:	83 c4 10             	add    $0x10,%esp
801033bc:	85 c0                	test   %eax,%eax
801033be:	75 e0                	jne    801033a0 <mpsearch1+0x20>
801033c0:	89 f2                	mov    %esi,%edx
801033c2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801033c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801033cf:	00 
    sum += addr[i];
801033d0:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
801033d3:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
801033d6:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
801033d8:	39 fa                	cmp    %edi,%edx
801033da:	75 f4                	jne    801033d0 <mpsearch1+0x50>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801033dc:	84 c0                	test   %al,%al
801033de:	75 c0                	jne    801033a0 <mpsearch1+0x20>
      return (struct mp*)p;
  return 0;
}
801033e0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801033e3:	89 f0                	mov    %esi,%eax
801033e5:	5b                   	pop    %ebx
801033e6:	5e                   	pop    %esi
801033e7:	5f                   	pop    %edi
801033e8:	5d                   	pop    %ebp
801033e9:	c3                   	ret
801033ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801033f0:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801033f3:	31 f6                	xor    %esi,%esi
}
801033f5:	5b                   	pop    %ebx
801033f6:	89 f0                	mov    %esi,%eax
801033f8:	5e                   	pop    %esi
801033f9:	5f                   	pop    %edi
801033fa:	5d                   	pop    %ebp
801033fb:	c3                   	ret
801033fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80103400 <mpinit>:
  return conf;
}

void
mpinit(void)
{
80103400:	55                   	push   %ebp
80103401:	89 e5                	mov    %esp,%ebp
80103403:	57                   	push   %edi
80103404:	56                   	push   %esi
80103405:	53                   	push   %ebx
80103406:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80103409:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80103410:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80103417:	c1 e0 08             	shl    $0x8,%eax
8010341a:	09 d0                	or     %edx,%eax
8010341c:	c1 e0 04             	shl    $0x4,%eax
8010341f:	75 1b                	jne    8010343c <mpinit+0x3c>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80103421:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80103428:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
8010342f:	c1 e0 08             	shl    $0x8,%eax
80103432:	09 d0                	or     %edx,%eax
80103434:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80103437:	2d 00 04 00 00       	sub    $0x400,%eax
8010343c:	ba 00 04 00 00       	mov    $0x400,%edx
80103441:	e8 3a ff ff ff       	call   80103380 <mpsearch1>
80103446:	85 c0                	test   %eax,%eax
80103448:	0f 84 5a 01 00 00    	je     801035a8 <mpinit+0x1a8>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
8010344e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80103451:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80103454:	8b 40 04             	mov    0x4(%eax),%eax
80103457:	85 c0                	test   %eax,%eax
80103459:	0f 84 d1 00 00 00    	je     80103530 <mpinit+0x130>
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
8010345f:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  if(memcmp(conf, "PCMP", 4) != 0)
80103462:	83 ec 04             	sub    $0x4,%esp
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80103465:	8b 40 04             	mov    0x4(%eax),%eax
80103468:	05 00 00 00 80       	add    $0x80000000,%eax
8010346d:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
80103470:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103473:	6a 04                	push   $0x4
80103475:	68 ec 77 10 80       	push   $0x801077ec
8010347a:	50                   	push   %eax
8010347b:	e8 60 15 00 00       	call   801049e0 <memcmp>
80103480:	83 c4 10             	add    $0x10,%esp
80103483:	89 c2                	mov    %eax,%edx
80103485:	85 c0                	test   %eax,%eax
80103487:	0f 85 a3 00 00 00    	jne    80103530 <mpinit+0x130>
  if(conf->version != 1 && conf->version != 4)
8010348d:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103490:	80 78 06 01          	cmpb   $0x1,0x6(%eax)
80103494:	74 0d                	je     801034a3 <mpinit+0xa3>
80103496:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103499:	80 78 06 04          	cmpb   $0x4,0x6(%eax)
8010349d:	0f 85 8d 00 00 00    	jne    80103530 <mpinit+0x130>
  if(sum((uchar*)conf, conf->length) != 0)
801034a3:	8b 45 e0             	mov    -0x20(%ebp),%eax
801034a6:	0f b7 48 04          	movzwl 0x4(%eax),%ecx
801034aa:	8b 45 e0             	mov    -0x20(%ebp),%eax
  for(i=0; i<len; i++)
801034ad:	66 85 c9             	test   %cx,%cx
801034b0:	74 1e                	je     801034d0 <mpinit+0xd0>
801034b2:	8d 1c 08             	lea    (%eax,%ecx,1),%ebx
801034b5:	8d 76 00             	lea    0x0(%esi),%esi
801034b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801034bf:	00 
    sum += addr[i];
801034c0:	0f b6 08             	movzbl (%eax),%ecx
  for(i=0; i<len; i++)
801034c3:	83 c0 01             	add    $0x1,%eax
    sum += addr[i];
801034c6:	01 ca                	add    %ecx,%edx
  for(i=0; i<len; i++)
801034c8:	39 d8                	cmp    %ebx,%eax
801034ca:	75 f4                	jne    801034c0 <mpinit+0xc0>
  if(sum((uchar*)conf, conf->length) != 0)
801034cc:	84 d2                	test   %dl,%dl
801034ce:	75 60                	jne    80103530 <mpinit+0x130>
  *pmp = mp;
801034d0:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
  return conf;
801034d3:	8b 4d e0             	mov    -0x20(%ebp),%ecx
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
801034d6:	85 c9                	test   %ecx,%ecx
801034d8:	74 56                	je     80103530 <mpinit+0x130>
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
801034da:	8b 41 24             	mov    0x24(%ecx),%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034dd:	0f b7 51 04          	movzwl 0x4(%ecx),%edx
  lapic = (uint*)conf->lapicaddr;
801034e1:	a3 84 16 11 80       	mov    %eax,0x80111684
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034e6:	8d 41 2c             	lea    0x2c(%ecx),%eax
801034e9:	01 d1                	add    %edx,%ecx
801034eb:	39 c8                	cmp    %ecx,%eax
801034ed:	72 14                	jb     80103503 <mpinit+0x103>
801034ef:	eb 60                	jmp    80103551 <mpinit+0x151>
801034f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    switch(*p){
801034f8:	84 d2                	test   %dl,%dl
801034fa:	74 7c                	je     80103578 <mpinit+0x178>
      p += sizeof(struct mpioapic);
      continue;
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
801034fc:	83 c0 08             	add    $0x8,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
801034ff:	39 c8                	cmp    %ecx,%eax
80103501:	73 4e                	jae    80103551 <mpinit+0x151>
    switch(*p){
80103503:	0f b6 10             	movzbl (%eax),%edx
80103506:	80 fa 02             	cmp    $0x2,%dl
80103509:	74 35                	je     80103540 <mpinit+0x140>
8010350b:	76 eb                	jbe    801034f8 <mpinit+0xf8>
8010350d:	83 ea 03             	sub    $0x3,%edx
80103510:	80 fa 01             	cmp    $0x1,%dl
80103513:	76 e7                	jbe    801034fc <mpinit+0xfc>
80103515:	eb fe                	jmp    80103515 <mpinit+0x115>
80103517:	90                   	nop
80103518:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010351f:	00 
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103520:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80103527:	90                   	nop
80103528:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010352f:	00 
    panic("Expect to run on an SMP");
80103530:	83 ec 0c             	sub    $0xc,%esp
80103533:	68 d4 77 10 80       	push   $0x801077d4
80103538:	e8 63 ce ff ff       	call   801003a0 <panic>
8010353d:	8d 76 00             	lea    0x0(%esi),%esi
      ioapicid = ioapic->apicno;
80103540:	0f b6 50 01          	movzbl 0x1(%eax),%edx
      p += sizeof(struct mpioapic);
80103544:	83 c0 08             	add    $0x8,%eax
      ioapicid = ioapic->apicno;
80103547:	88 15 80 17 11 80    	mov    %dl,0x80111780
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
8010354d:	39 c8                	cmp    %ecx,%eax
8010354f:	72 b2                	jb     80103503 <mpinit+0x103>
    }
  }
  if(!ismp)
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
80103551:	80 7b 0c 00          	cmpb   $0x0,0xc(%ebx)
80103555:	74 15                	je     8010356c <mpinit+0x16c>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103557:	b8 70 00 00 00       	mov    $0x70,%eax
8010355c:	ba 22 00 00 00       	mov    $0x22,%edx
80103561:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103562:	ba 23 00 00 00       	mov    $0x23,%edx
80103567:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
80103568:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010356b:	ee                   	out    %al,(%dx)
  }
}
8010356c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010356f:	5b                   	pop    %ebx
80103570:	5e                   	pop    %esi
80103571:	5f                   	pop    %edi
80103572:	5d                   	pop    %ebp
80103573:	c3                   	ret
80103574:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(ncpu < NCPU) {
80103578:	8b 35 84 17 11 80    	mov    0x80111784,%esi
8010357e:	83 fe 07             	cmp    $0x7,%esi
80103581:	7f 19                	jg     8010359c <mpinit+0x19c>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103583:	69 fe b0 00 00 00    	imul   $0xb0,%esi,%edi
80103589:	0f b6 50 01          	movzbl 0x1(%eax),%edx
        ncpu++;
8010358d:	83 c6 01             	add    $0x1,%esi
80103590:	89 35 84 17 11 80    	mov    %esi,0x80111784
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103596:	88 97 a0 17 11 80    	mov    %dl,-0x7feee860(%edi)
      p += sizeof(struct mpproc);
8010359c:	83 c0 14             	add    $0x14,%eax
      continue;
8010359f:	e9 5b ff ff ff       	jmp    801034ff <mpinit+0xff>
801035a4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
{
801035a8:	bb 00 00 0f 80       	mov    $0x800f0000,%ebx
801035ad:	eb 0f                	jmp    801035be <mpinit+0x1be>
801035af:	90                   	nop
  for(p = addr; p < e; p += sizeof(struct mp))
801035b0:	89 f3                	mov    %esi,%ebx
801035b2:	81 fe 00 00 10 80    	cmp    $0x80100000,%esi
801035b8:	0f 84 62 ff ff ff    	je     80103520 <mpinit+0x120>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801035be:	83 ec 04             	sub    $0x4,%esp
801035c1:	8d 73 10             	lea    0x10(%ebx),%esi
801035c4:	6a 04                	push   $0x4
801035c6:	68 cf 77 10 80       	push   $0x801077cf
801035cb:	53                   	push   %ebx
801035cc:	e8 0f 14 00 00       	call   801049e0 <memcmp>
801035d1:	83 c4 10             	add    $0x10,%esp
801035d4:	85 c0                	test   %eax,%eax
801035d6:	75 d8                	jne    801035b0 <mpinit+0x1b0>
801035d8:	89 da                	mov    %ebx,%edx
801035da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    sum += addr[i];
801035e0:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
801035e3:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
801035e6:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
801035e8:	39 d6                	cmp    %edx,%esi
801035ea:	75 f4                	jne    801035e0 <mpinit+0x1e0>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801035ec:	84 c0                	test   %al,%al
801035ee:	75 c0                	jne    801035b0 <mpinit+0x1b0>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
801035f0:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
801035f3:	e9 59 fe ff ff       	jmp    80103451 <mpinit+0x51>
801035f8:	66 90                	xchg   %ax,%ax
801035fa:	66 90                	xchg   %ax,%ax
801035fc:	66 90                	xchg   %ax,%ax
801035fe:	66 90                	xchg   %ax,%ax

80103600 <picinit>:
80103600:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103605:	ba 21 00 00 00       	mov    $0x21,%edx
8010360a:	ee                   	out    %al,(%dx)
8010360b:	ba a1 00 00 00       	mov    $0xa1,%edx
80103610:	ee                   	out    %al,(%dx)
picinit(void)
{
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80103611:	c3                   	ret
80103612:	66 90                	xchg   %ax,%ax
80103614:	66 90                	xchg   %ax,%ax
80103616:	66 90                	xchg   %ax,%ax
80103618:	66 90                	xchg   %ax,%ax
8010361a:	66 90                	xchg   %ax,%ax
8010361c:	66 90                	xchg   %ax,%ax
8010361e:	66 90                	xchg   %ax,%ax
80103620:	66 90                	xchg   %ax,%ax
80103622:	66 90                	xchg   %ax,%ax
80103624:	66 90                	xchg   %ax,%ax
80103626:	66 90                	xchg   %ax,%ax
80103628:	66 90                	xchg   %ax,%ax
8010362a:	66 90                	xchg   %ax,%ax
8010362c:	66 90                	xchg   %ax,%ax
8010362e:	66 90                	xchg   %ax,%ax
80103630:	66 90                	xchg   %ax,%ax
80103632:	66 90                	xchg   %ax,%ax
80103634:	66 90                	xchg   %ax,%ax
80103636:	66 90                	xchg   %ax,%ax
80103638:	66 90                	xchg   %ax,%ax
8010363a:	66 90                	xchg   %ax,%ax
8010363c:	66 90                	xchg   %ax,%ax
8010363e:	66 90                	xchg   %ax,%ax

80103640 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80103640:	55                   	push   %ebp
80103641:	89 e5                	mov    %esp,%ebp
80103643:	57                   	push   %edi
80103644:	56                   	push   %esi
80103645:	53                   	push   %ebx
80103646:	83 ec 0c             	sub    $0xc,%esp
80103649:	8b 75 08             	mov    0x8(%ebp),%esi
8010364c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
8010364f:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
80103655:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
8010365b:	e8 60 d8 ff ff       	call   80100ec0 <filealloc>
80103660:	89 06                	mov    %eax,(%esi)
80103662:	85 c0                	test   %eax,%eax
80103664:	0f 84 a5 00 00 00    	je     8010370f <pipealloc+0xcf>
8010366a:	e8 51 d8 ff ff       	call   80100ec0 <filealloc>
8010366f:	89 07                	mov    %eax,(%edi)
80103671:	85 c0                	test   %eax,%eax
80103673:	0f 84 84 00 00 00    	je     801036fd <pipealloc+0xbd>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80103679:	e8 32 f1 ff ff       	call   801027b0 <kalloc>
8010367e:	89 c3                	mov    %eax,%ebx
80103680:	85 c0                	test   %eax,%eax
80103682:	0f 84 a0 00 00 00    	je     80103728 <pipealloc+0xe8>
    goto bad;
  p->readopen = 1;
80103688:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
8010368f:	00 00 00 
  p->writeopen = 1;
  p->nwrite = 0;
  p->nread = 0;
  initlock(&p->lock, "pipe");
80103692:	83 ec 08             	sub    $0x8,%esp
  p->writeopen = 1;
80103695:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
8010369c:	00 00 00 
  p->nwrite = 0;
8010369f:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
801036a6:	00 00 00 
  p->nread = 0;
801036a9:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
801036b0:	00 00 00 
  initlock(&p->lock, "pipe");
801036b3:	68 f1 77 10 80       	push   $0x801077f1
801036b8:	50                   	push   %eax
801036b9:	e8 a2 0f 00 00       	call   80104660 <initlock>
  (*f0)->type = FD_PIPE;
801036be:	8b 06                	mov    (%esi),%eax
  (*f0)->pipe = p;
  (*f1)->type = FD_PIPE;
  (*f1)->readable = 0;
  (*f1)->writable = 1;
  (*f1)->pipe = p;
  return 0;
801036c0:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
801036c3:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
801036c9:	8b 06                	mov    (%esi),%eax
801036cb:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
801036cf:	8b 06                	mov    (%esi),%eax
801036d1:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
801036d5:	8b 06                	mov    (%esi),%eax
801036d7:	89 58 0c             	mov    %ebx,0xc(%eax)
  (*f1)->type = FD_PIPE;
801036da:	8b 07                	mov    (%edi),%eax
801036dc:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
801036e2:	8b 07                	mov    (%edi),%eax
801036e4:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
801036e8:	8b 07                	mov    (%edi),%eax
801036ea:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
801036ee:	8b 07                	mov    (%edi),%eax
801036f0:	89 58 0c             	mov    %ebx,0xc(%eax)
  return 0;
801036f3:	31 c0                	xor    %eax,%eax
  if(*f0)
    fileclose(*f0);
  if(*f1)
    fileclose(*f1);
  return -1;
}
801036f5:	8d 65 f4             	lea    -0xc(%ebp),%esp
801036f8:	5b                   	pop    %ebx
801036f9:	5e                   	pop    %esi
801036fa:	5f                   	pop    %edi
801036fb:	5d                   	pop    %ebp
801036fc:	c3                   	ret
  if(*f0)
801036fd:	8b 06                	mov    (%esi),%eax
801036ff:	85 c0                	test   %eax,%eax
80103701:	74 1e                	je     80103721 <pipealloc+0xe1>
    fileclose(*f0);
80103703:	83 ec 0c             	sub    $0xc,%esp
80103706:	50                   	push   %eax
80103707:	e8 74 d8 ff ff       	call   80100f80 <fileclose>
8010370c:	83 c4 10             	add    $0x10,%esp
  if(*f1)
8010370f:	8b 07                	mov    (%edi),%eax
80103711:	85 c0                	test   %eax,%eax
80103713:	74 0c                	je     80103721 <pipealloc+0xe1>
    fileclose(*f1);
80103715:	83 ec 0c             	sub    $0xc,%esp
80103718:	50                   	push   %eax
80103719:	e8 62 d8 ff ff       	call   80100f80 <fileclose>
8010371e:	83 c4 10             	add    $0x10,%esp
  return -1;
80103721:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103726:	eb cd                	jmp    801036f5 <pipealloc+0xb5>
  if(*f0)
80103728:	8b 06                	mov    (%esi),%eax
8010372a:	85 c0                	test   %eax,%eax
8010372c:	75 d5                	jne    80103703 <pipealloc+0xc3>
8010372e:	eb df                	jmp    8010370f <pipealloc+0xcf>

80103730 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80103730:	55                   	push   %ebp
80103731:	89 e5                	mov    %esp,%ebp
80103733:	56                   	push   %esi
80103734:	53                   	push   %ebx
80103735:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103738:	8b 75 0c             	mov    0xc(%ebp),%esi
  acquire(&p->lock);
8010373b:	83 ec 0c             	sub    $0xc,%esp
8010373e:	53                   	push   %ebx
8010373f:	e8 3c 11 00 00       	call   80104880 <acquire>
  if(writable){
80103744:	83 c4 10             	add    $0x10,%esp
80103747:	85 f6                	test   %esi,%esi
80103749:	74 45                	je     80103790 <pipeclose+0x60>
    p->writeopen = 0;
    wakeup(&p->nread);
8010374b:	83 ec 0c             	sub    $0xc,%esp
8010374e:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
    p->writeopen = 0;
80103754:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
8010375b:	00 00 00 
    wakeup(&p->nread);
8010375e:	50                   	push   %eax
8010375f:	e8 1c 0c 00 00       	call   80104380 <wakeup>
80103764:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
80103767:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
8010376d:	85 d2                	test   %edx,%edx
8010376f:	75 0a                	jne    8010377b <pipeclose+0x4b>
80103771:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
80103777:	85 c0                	test   %eax,%eax
80103779:	74 35                	je     801037b0 <pipeclose+0x80>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
8010377b:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010377e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103781:	5b                   	pop    %ebx
80103782:	5e                   	pop    %esi
80103783:	5d                   	pop    %ebp
    release(&p->lock);
80103784:	e9 97 10 00 00       	jmp    80104820 <release>
80103789:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    wakeup(&p->nwrite);
80103790:	83 ec 0c             	sub    $0xc,%esp
80103793:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
    p->readopen = 0;
80103799:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
801037a0:	00 00 00 
    wakeup(&p->nwrite);
801037a3:	50                   	push   %eax
801037a4:	e8 d7 0b 00 00       	call   80104380 <wakeup>
801037a9:	83 c4 10             	add    $0x10,%esp
801037ac:	eb b9                	jmp    80103767 <pipeclose+0x37>
801037ae:	66 90                	xchg   %ax,%ax
    release(&p->lock);
801037b0:	83 ec 0c             	sub    $0xc,%esp
801037b3:	53                   	push   %ebx
801037b4:	e8 67 10 00 00       	call   80104820 <release>
    kfree((char*)p);
801037b9:	83 c4 10             	add    $0x10,%esp
801037bc:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801037bf:	8d 65 f8             	lea    -0x8(%ebp),%esp
801037c2:	5b                   	pop    %ebx
801037c3:	5e                   	pop    %esi
801037c4:	5d                   	pop    %ebp
    kfree((char*)p);
801037c5:	e9 f6 ed ff ff       	jmp    801025c0 <kfree>
801037ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801037d0 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
801037d0:	55                   	push   %ebp
801037d1:	89 e5                	mov    %esp,%ebp
801037d3:	57                   	push   %edi
801037d4:	56                   	push   %esi
801037d5:	53                   	push   %ebx
801037d6:	83 ec 28             	sub    $0x28,%esp
801037d9:	8b 5d 08             	mov    0x8(%ebp),%ebx
801037dc:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  acquire(&p->lock);
801037df:	53                   	push   %ebx
801037e0:	e8 9b 10 00 00       	call   80104880 <acquire>
  for(i = 0; i < n; i++){
801037e5:	83 c4 10             	add    $0x10,%esp
801037e8:	85 ff                	test   %edi,%edi
801037ea:	0f 8e cc 00 00 00    	jle    801038bc <pipewrite+0xec>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801037f0:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
801037f6:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801037f9:	89 7d 10             	mov    %edi,0x10(%ebp)
801037fc:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801037ff:	8d 34 39             	lea    (%ecx,%edi,1),%esi
80103802:	89 75 e0             	mov    %esi,-0x20(%ebp)
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80103805:	8d b3 34 02 00 00    	lea    0x234(%ebx),%esi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010380b:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103811:	8d bb 38 02 00 00    	lea    0x238(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103817:	8d 90 00 02 00 00    	lea    0x200(%eax),%edx
8010381d:	39 55 e4             	cmp    %edx,-0x1c(%ebp)
80103820:	0f 85 b4 00 00 00    	jne    801038da <pipewrite+0x10a>
80103826:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80103829:	eb 3b                	jmp    80103866 <pipewrite+0x96>
8010382b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(p->readopen == 0 || myproc()->killed){
80103830:	e8 ab 03 00 00       	call   80103be0 <myproc>
80103835:	8b 48 24             	mov    0x24(%eax),%ecx
80103838:	85 c9                	test   %ecx,%ecx
8010383a:	75 34                	jne    80103870 <pipewrite+0xa0>
      wakeup(&p->nread);
8010383c:	83 ec 0c             	sub    $0xc,%esp
8010383f:	56                   	push   %esi
80103840:	e8 3b 0b 00 00       	call   80104380 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103845:	58                   	pop    %eax
80103846:	5a                   	pop    %edx
80103847:	53                   	push   %ebx
80103848:	57                   	push   %edi
80103849:	e8 72 0a 00 00       	call   801042c0 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010384e:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80103854:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
8010385a:	83 c4 10             	add    $0x10,%esp
8010385d:	05 00 02 00 00       	add    $0x200,%eax
80103862:	39 c2                	cmp    %eax,%edx
80103864:	75 2a                	jne    80103890 <pipewrite+0xc0>
      if(p->readopen == 0 || myproc()->killed){
80103866:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
8010386c:	85 c0                	test   %eax,%eax
8010386e:	75 c0                	jne    80103830 <pipewrite+0x60>
        release(&p->lock);
80103870:	83 ec 0c             	sub    $0xc,%esp
80103873:	53                   	push   %ebx
80103874:	e8 a7 0f 00 00       	call   80104820 <release>
        return -1;
80103879:	83 c4 10             	add    $0x10,%esp
8010387c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
80103881:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103884:	5b                   	pop    %ebx
80103885:	5e                   	pop    %esi
80103886:	5f                   	pop    %edi
80103887:	5d                   	pop    %ebp
80103888:	c3                   	ret
80103889:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103890:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
80103893:	8d 42 01             	lea    0x1(%edx),%eax
80103896:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
  for(i = 0; i < n; i++){
8010389c:	83 c1 01             	add    $0x1,%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
8010389f:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
801038a5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801038a8:	0f b6 41 ff          	movzbl -0x1(%ecx),%eax
801038ac:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
  for(i = 0; i < n; i++){
801038b0:	3b 4d e0             	cmp    -0x20(%ebp),%ecx
801038b3:	0f 85 52 ff ff ff    	jne    8010380b <pipewrite+0x3b>
801038b9:	8b 7d 10             	mov    0x10(%ebp),%edi
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
801038bc:	83 ec 0c             	sub    $0xc,%esp
801038bf:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
801038c5:	50                   	push   %eax
801038c6:	e8 b5 0a 00 00       	call   80104380 <wakeup>
  release(&p->lock);
801038cb:	89 1c 24             	mov    %ebx,(%esp)
801038ce:	e8 4d 0f 00 00       	call   80104820 <release>
  return n;
801038d3:	83 c4 10             	add    $0x10,%esp
801038d6:	89 f8                	mov    %edi,%eax
801038d8:	eb a7                	jmp    80103881 <pipewrite+0xb1>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801038da:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801038dd:	eb b4                	jmp    80103893 <pipewrite+0xc3>
801038df:	90                   	nop

801038e0 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
801038e0:	55                   	push   %ebp
801038e1:	89 e5                	mov    %esp,%ebp
801038e3:	57                   	push   %edi
801038e4:	56                   	push   %esi
801038e5:	53                   	push   %ebx
801038e6:	83 ec 18             	sub    $0x18,%esp
801038e9:	8b 75 08             	mov    0x8(%ebp),%esi
801038ec:	8b 7d 0c             	mov    0xc(%ebp),%edi
  int i;

  acquire(&p->lock);
801038ef:	56                   	push   %esi
801038f0:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
801038f6:	e8 85 0f 00 00       	call   80104880 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
801038fb:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103901:	83 c4 10             	add    $0x10,%esp
80103904:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
8010390a:	74 2f                	je     8010393b <piperead+0x5b>
8010390c:	eb 37                	jmp    80103945 <piperead+0x65>
8010390e:	66 90                	xchg   %ax,%ax
    if(myproc()->killed){
80103910:	e8 cb 02 00 00       	call   80103be0 <myproc>
80103915:	8b 40 24             	mov    0x24(%eax),%eax
80103918:	85 c0                	test   %eax,%eax
8010391a:	0f 85 b0 00 00 00    	jne    801039d0 <piperead+0xf0>
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80103920:	83 ec 08             	sub    $0x8,%esp
80103923:	56                   	push   %esi
80103924:	53                   	push   %ebx
80103925:	e8 96 09 00 00       	call   801042c0 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010392a:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103930:	83 c4 10             	add    $0x10,%esp
80103933:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
80103939:	75 0a                	jne    80103945 <piperead+0x65>
8010393b:	8b 96 40 02 00 00    	mov    0x240(%esi),%edx
80103941:	85 d2                	test   %edx,%edx
80103943:	75 cb                	jne    80103910 <piperead+0x30>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103945:	8b 4d 10             	mov    0x10(%ebp),%ecx
80103948:	31 db                	xor    %ebx,%ebx
8010394a:	85 c9                	test   %ecx,%ecx
8010394c:	7f 56                	jg     801039a4 <piperead+0xc4>
8010394e:	eb 5c                	jmp    801039ac <piperead+0xcc>
80103950:	eb 2e                	jmp    80103980 <piperead+0xa0>
80103952:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80103958:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010395f:	00 
80103960:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103967:	00 
80103968:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010396f:	00 
80103970:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103977:	00 
80103978:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010397f:	00 
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
80103980:	8d 48 01             	lea    0x1(%eax),%ecx
80103983:	25 ff 01 00 00       	and    $0x1ff,%eax
80103988:	89 8e 34 02 00 00    	mov    %ecx,0x234(%esi)
8010398e:	0f b6 44 06 34       	movzbl 0x34(%esi,%eax,1),%eax
80103993:	88 04 1f             	mov    %al,(%edi,%ebx,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103996:	83 c3 01             	add    $0x1,%ebx
80103999:	39 5d 10             	cmp    %ebx,0x10(%ebp)
8010399c:	74 0e                	je     801039ac <piperead+0xcc>
8010399e:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
    if(p->nread == p->nwrite)
801039a4:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
801039aa:	75 d4                	jne    80103980 <piperead+0xa0>
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
801039ac:	83 ec 0c             	sub    $0xc,%esp
801039af:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
801039b5:	50                   	push   %eax
801039b6:	e8 c5 09 00 00       	call   80104380 <wakeup>
  release(&p->lock);
801039bb:	89 34 24             	mov    %esi,(%esp)
801039be:	e8 5d 0e 00 00       	call   80104820 <release>
  return i;
801039c3:	83 c4 10             	add    $0x10,%esp
}
801039c6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801039c9:	89 d8                	mov    %ebx,%eax
801039cb:	5b                   	pop    %ebx
801039cc:	5e                   	pop    %esi
801039cd:	5f                   	pop    %edi
801039ce:	5d                   	pop    %ebp
801039cf:	c3                   	ret
      release(&p->lock);
801039d0:	83 ec 0c             	sub    $0xc,%esp
      return -1;
801039d3:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
      release(&p->lock);
801039d8:	56                   	push   %esi
801039d9:	e8 42 0e 00 00       	call   80104820 <release>
      return -1;
801039de:	83 c4 10             	add    $0x10,%esp
}
801039e1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801039e4:	89 d8                	mov    %ebx,%eax
801039e6:	5b                   	pop    %ebx
801039e7:	5e                   	pop    %esi
801039e8:	5f                   	pop    %edi
801039e9:	5d                   	pop    %ebp
801039ea:	c3                   	ret
801039eb:	66 90                	xchg   %ax,%ax
801039ed:	66 90                	xchg   %ax,%ax
801039ef:	66 90                	xchg   %ax,%ax
801039f1:	66 90                	xchg   %ax,%ax
801039f3:	66 90                	xchg   %ax,%ax
801039f5:	66 90                	xchg   %ax,%ax
801039f7:	66 90                	xchg   %ax,%ax
801039f9:	66 90                	xchg   %ax,%ax
801039fb:	66 90                	xchg   %ax,%ax
801039fd:	66 90                	xchg   %ax,%ax
801039ff:	90                   	nop

80103a00 <allocproc>:
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
80103a00:	55                   	push   %ebp
80103a01:	89 e5                	mov    %esp,%ebp
80103a03:	53                   	push   %ebx
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103a04:	bb 54 1d 11 80       	mov    $0x80111d54,%ebx
{
80103a09:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
80103a0c:	68 20 1d 11 80       	push   $0x80111d20
80103a11:	e8 6a 0e 00 00       	call   80104880 <acquire>
80103a16:	83 c4 10             	add    $0x10,%esp
80103a19:	eb 10                	jmp    80103a2b <allocproc+0x2b>
80103a1b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103a20:	83 c3 7c             	add    $0x7c,%ebx
80103a23:	81 fb 54 3c 11 80    	cmp    $0x80113c54,%ebx
80103a29:	74 75                	je     80103aa0 <allocproc+0xa0>
    if(p->state == UNUSED)
80103a2b:	8b 43 0c             	mov    0xc(%ebx),%eax
80103a2e:	85 c0                	test   %eax,%eax
80103a30:	75 ee                	jne    80103a20 <allocproc+0x20>
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
80103a32:	a1 04 a0 10 80       	mov    0x8010a004,%eax

  release(&ptable.lock);
80103a37:	83 ec 0c             	sub    $0xc,%esp
  p->state = EMBRYO;
80103a3a:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
80103a41:	89 43 10             	mov    %eax,0x10(%ebx)
80103a44:	8d 50 01             	lea    0x1(%eax),%edx
  release(&ptable.lock);
80103a47:	68 20 1d 11 80       	push   $0x80111d20
  p->pid = nextpid++;
80103a4c:	89 15 04 a0 10 80    	mov    %edx,0x8010a004
  release(&ptable.lock);
80103a52:	e8 c9 0d 00 00       	call   80104820 <release>

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
80103a57:	e8 54 ed ff ff       	call   801027b0 <kalloc>
80103a5c:	83 c4 10             	add    $0x10,%esp
80103a5f:	89 43 08             	mov    %eax,0x8(%ebx)
80103a62:	85 c0                	test   %eax,%eax
80103a64:	74 53                	je     80103ab9 <allocproc+0xb9>
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80103a66:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
80103a6c:	83 ec 04             	sub    $0x4,%esp
  sp -= sizeof *p->context;
80103a6f:	05 9c 0f 00 00       	add    $0xf9c,%eax
  sp -= sizeof *p->tf;
80103a74:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
80103a77:	c7 40 14 b7 5b 10 80 	movl   $0x80105bb7,0x14(%eax)
  p->context = (struct context*)sp;
80103a7e:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
80103a81:	6a 14                	push   $0x14
80103a83:	6a 00                	push   $0x0
80103a85:	50                   	push   %eax
80103a86:	e8 15 0f 00 00       	call   801049a0 <memset>
  p->context->eip = (uint)forkret;
80103a8b:	8b 43 1c             	mov    0x1c(%ebx),%eax

  return p;
80103a8e:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
80103a91:	c7 40 10 d0 3a 10 80 	movl   $0x80103ad0,0x10(%eax)
}
80103a98:	89 d8                	mov    %ebx,%eax
80103a9a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a9d:	c9                   	leave
80103a9e:	c3                   	ret
80103a9f:	90                   	nop
  release(&ptable.lock);
80103aa0:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80103aa3:	31 db                	xor    %ebx,%ebx
  release(&ptable.lock);
80103aa5:	68 20 1d 11 80       	push   $0x80111d20
80103aaa:	e8 71 0d 00 00       	call   80104820 <release>
  return 0;
80103aaf:	83 c4 10             	add    $0x10,%esp
}
80103ab2:	89 d8                	mov    %ebx,%eax
80103ab4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103ab7:	c9                   	leave
80103ab8:	c3                   	ret
    p->state = UNUSED;
80103ab9:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  return 0;
80103ac0:	31 db                	xor    %ebx,%ebx
80103ac2:	eb ee                	jmp    80103ab2 <allocproc+0xb2>
80103ac4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103ac8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103acf:	00 

80103ad0 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
80103ad0:	55                   	push   %ebp
80103ad1:	89 e5                	mov    %esp,%ebp
80103ad3:	83 ec 14             	sub    $0x14,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80103ad6:	68 20 1d 11 80       	push   $0x80111d20
80103adb:	e8 40 0d 00 00       	call   80104820 <release>

  if (first) {
80103ae0:	a1 00 a0 10 80       	mov    0x8010a000,%eax
80103ae5:	83 c4 10             	add    $0x10,%esp
80103ae8:	85 c0                	test   %eax,%eax
80103aea:	75 04                	jne    80103af0 <forkret+0x20>
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}
80103aec:	c9                   	leave
80103aed:	c3                   	ret
80103aee:	66 90                	xchg   %ax,%ax
    first = 0;
80103af0:	c7 05 00 a0 10 80 00 	movl   $0x0,0x8010a000
80103af7:	00 00 00 
    iinit(ROOTDEV);
80103afa:	83 ec 0c             	sub    $0xc,%esp
80103afd:	6a 01                	push   $0x1
80103aff:	e8 3c db ff ff       	call   80101640 <iinit>
    initlog(ROOTDEV);
80103b04:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
80103b0b:	e8 a0 f3 ff ff       	call   80102eb0 <initlog>
}
80103b10:	83 c4 10             	add    $0x10,%esp
80103b13:	c9                   	leave
80103b14:	c3                   	ret
80103b15:	8d 76 00             	lea    0x0(%esi),%esi
80103b18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b1f:	00 

80103b20 <pinit>:
{
80103b20:	55                   	push   %ebp
80103b21:	89 e5                	mov    %esp,%ebp
80103b23:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
80103b26:	68 f6 77 10 80       	push   $0x801077f6
80103b2b:	68 20 1d 11 80       	push   $0x80111d20
80103b30:	e8 2b 0b 00 00       	call   80104660 <initlock>
}
80103b35:	83 c4 10             	add    $0x10,%esp
80103b38:	c9                   	leave
80103b39:	c3                   	ret
80103b3a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103b40 <mycpu>:
{
80103b40:	55                   	push   %ebp
80103b41:	89 e5                	mov    %esp,%ebp
80103b43:	56                   	push   %esi
80103b44:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103b45:	9c                   	pushf
80103b46:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103b47:	f6 c4 02             	test   $0x2,%ah
80103b4a:	75 65                	jne    80103bb1 <mycpu+0x71>
  apicid = lapicid();
80103b4c:	e8 2f ef ff ff       	call   80102a80 <lapicid>
  for (i = 0; i < ncpu; ++i) {
80103b51:	8b 1d 84 17 11 80    	mov    0x80111784,%ebx
  apicid = lapicid();
80103b57:	89 c6                	mov    %eax,%esi
  for (i = 0; i < ncpu; ++i) {
80103b59:	85 db                	test   %ebx,%ebx
80103b5b:	7e 47                	jle    80103ba4 <mycpu+0x64>
80103b5d:	31 d2                	xor    %edx,%edx
80103b5f:	eb 26                	jmp    80103b87 <mycpu+0x47>
80103b61:	eb 1d                	jmp    80103b80 <mycpu+0x40>
80103b63:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b6f:	00 
80103b70:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b77:	00 
80103b78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b7f:	00 
80103b80:	83 c2 01             	add    $0x1,%edx
80103b83:	39 da                	cmp    %ebx,%edx
80103b85:	74 1d                	je     80103ba4 <mycpu+0x64>
    if (cpus[i].apicid == apicid)
80103b87:	69 c2 b0 00 00 00    	imul   $0xb0,%edx,%eax
80103b8d:	0f b6 88 a0 17 11 80 	movzbl -0x7feee860(%eax),%ecx
80103b94:	39 f1                	cmp    %esi,%ecx
80103b96:	75 e8                	jne    80103b80 <mycpu+0x40>
}
80103b98:	8d 65 f8             	lea    -0x8(%ebp),%esp
      return &cpus[i];
80103b9b:	05 a0 17 11 80       	add    $0x801117a0,%eax
}
80103ba0:	5b                   	pop    %ebx
80103ba1:	5e                   	pop    %esi
80103ba2:	5d                   	pop    %ebp
80103ba3:	c3                   	ret
  panic("unknown apicid\n");
80103ba4:	83 ec 0c             	sub    $0xc,%esp
80103ba7:	68 fd 77 10 80       	push   $0x801077fd
80103bac:	e8 ef c7 ff ff       	call   801003a0 <panic>
    panic("mycpu called with interrupts enabled\n");
80103bb1:	83 ec 0c             	sub    $0xc,%esp
80103bb4:	68 3c 7b 10 80       	push   $0x80107b3c
80103bb9:	e8 e2 c7 ff ff       	call   801003a0 <panic>
80103bbe:	66 90                	xchg   %ax,%ax

80103bc0 <cpuid>:
cpuid() {
80103bc0:	55                   	push   %ebp
80103bc1:	89 e5                	mov    %esp,%ebp
80103bc3:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
80103bc6:	e8 75 ff ff ff       	call   80103b40 <mycpu>
}
80103bcb:	c9                   	leave
  return mycpu()-cpus;
80103bcc:	2d a0 17 11 80       	sub    $0x801117a0,%eax
80103bd1:	c1 f8 04             	sar    $0x4,%eax
80103bd4:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
80103bda:	c3                   	ret
80103bdb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103be0 <myproc>:
myproc(void) {
80103be0:	55                   	push   %ebp
80103be1:	89 e5                	mov    %esp,%ebp
80103be3:	53                   	push   %ebx
80103be4:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80103be7:	e8 34 0b 00 00       	call   80104720 <pushcli>
  c = mycpu();
80103bec:	e8 4f ff ff ff       	call   80103b40 <mycpu>
  p = c->proc;
80103bf1:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103bf7:	e8 74 0b 00 00       	call   80104770 <popcli>
}
80103bfc:	89 d8                	mov    %ebx,%eax
80103bfe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103c01:	c9                   	leave
80103c02:	c3                   	ret
80103c03:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103c08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103c0f:	00 

80103c10 <userinit>:
{
80103c10:	55                   	push   %ebp
80103c11:	89 e5                	mov    %esp,%ebp
80103c13:	53                   	push   %ebx
80103c14:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80103c17:	e8 e4 fd ff ff       	call   80103a00 <allocproc>
80103c1c:	89 c3                	mov    %eax,%ebx
  initproc = p;
80103c1e:	a3 54 3c 11 80       	mov    %eax,0x80113c54
  if((p->pgdir = setupkvm()) == 0)
80103c23:	e8 48 36 00 00       	call   80107270 <setupkvm>
80103c28:	89 43 04             	mov    %eax,0x4(%ebx)
80103c2b:	85 c0                	test   %eax,%eax
80103c2d:	0f 84 bd 00 00 00    	je     80103cf0 <userinit+0xe0>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
80103c33:	83 ec 04             	sub    $0x4,%esp
80103c36:	68 2c 00 00 00       	push   $0x2c
80103c3b:	68 60 a4 10 80       	push   $0x8010a460
80103c40:	50                   	push   %eax
80103c41:	e8 0a 33 00 00       	call   80106f50 <inituvm>
  memset(p->tf, 0, sizeof(*p->tf));
80103c46:	83 c4 0c             	add    $0xc,%esp
  p->sz = PGSIZE;
80103c49:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
80103c4f:	6a 4c                	push   $0x4c
80103c51:	6a 00                	push   $0x0
80103c53:	ff 73 18             	push   0x18(%ebx)
80103c56:	e8 45 0d 00 00       	call   801049a0 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103c5b:	8b 43 18             	mov    0x18(%ebx),%eax
80103c5e:	ba 1b 00 00 00       	mov    $0x1b,%edx
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103c63:	83 c4 0c             	add    $0xc,%esp
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103c66:	b9 23 00 00 00       	mov    $0x23,%ecx
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103c6b:	66 89 50 3c          	mov    %dx,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103c6f:	8b 43 18             	mov    0x18(%ebx),%eax
80103c72:	66 89 48 2c          	mov    %cx,0x2c(%eax)
  p->tf->es = p->tf->ds;
80103c76:	8b 43 18             	mov    0x18(%ebx),%eax
80103c79:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103c7d:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80103c81:	8b 43 18             	mov    0x18(%ebx),%eax
80103c84:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103c88:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
80103c8c:	8b 43 18             	mov    0x18(%ebx),%eax
80103c8f:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
80103c96:	8b 43 18             	mov    0x18(%ebx),%eax
80103c99:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
80103ca0:	8b 43 18             	mov    0x18(%ebx),%eax
80103ca3:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103caa:	8d 43 6c             	lea    0x6c(%ebx),%eax
80103cad:	6a 10                	push   $0x10
80103caf:	68 26 78 10 80       	push   $0x80107826
80103cb4:	50                   	push   %eax
80103cb5:	e8 96 0e 00 00       	call   80104b50 <safestrcpy>
  p->cwd = namei("/");
80103cba:	c7 04 24 2f 78 10 80 	movl   $0x8010782f,(%esp)
80103cc1:	e8 ca e4 ff ff       	call   80102190 <namei>
80103cc6:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
80103cc9:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103cd0:	e8 ab 0b 00 00       	call   80104880 <acquire>
  p->state = RUNNABLE;
80103cd5:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
80103cdc:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103ce3:	e8 38 0b 00 00       	call   80104820 <release>
}
80103ce8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103ceb:	83 c4 10             	add    $0x10,%esp
80103cee:	c9                   	leave
80103cef:	c3                   	ret
    panic("userinit: out of memory?");
80103cf0:	83 ec 0c             	sub    $0xc,%esp
80103cf3:	68 0d 78 10 80       	push   $0x8010780d
80103cf8:	e8 a3 c6 ff ff       	call   801003a0 <panic>
80103cfd:	8d 76 00             	lea    0x0(%esi),%esi

80103d00 <growproc>:
{
80103d00:	55                   	push   %ebp
80103d01:	89 e5                	mov    %esp,%ebp
80103d03:	53                   	push   %ebx
80103d04:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80103d07:	e8 14 0a 00 00       	call   80104720 <pushcli>
  c = mycpu();
80103d0c:	e8 2f fe ff ff       	call   80103b40 <mycpu>
  p = c->proc;
80103d11:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103d17:	e8 54 0a 00 00       	call   80104770 <popcli>
  if(n > 0){
80103d1c:	8b 55 08             	mov    0x8(%ebp),%edx
  sz = curproc->sz;
80103d1f:	8b 03                	mov    (%ebx),%eax
  if(n > 0){
80103d21:	85 d2                	test   %edx,%edx
80103d23:	7f 1b                	jg     80103d40 <growproc+0x40>
  } else if(n < 0){
80103d25:	75 39                	jne    80103d60 <growproc+0x60>
  switchuvm(curproc);
80103d27:	83 ec 0c             	sub    $0xc,%esp
  curproc->sz = sz;
80103d2a:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
80103d2c:	53                   	push   %ebx
80103d2d:	e8 0e 31 00 00       	call   80106e40 <switchuvm>
  return 0;
80103d32:	83 c4 10             	add    $0x10,%esp
80103d35:	31 c0                	xor    %eax,%eax
}
80103d37:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103d3a:	c9                   	leave
80103d3b:	c3                   	ret
80103d3c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103d40:	8b 55 08             	mov    0x8(%ebp),%edx
80103d43:	83 ec 04             	sub    $0x4,%esp
80103d46:	01 c2                	add    %eax,%edx
80103d48:	52                   	push   %edx
80103d49:	50                   	push   %eax
80103d4a:	ff 73 04             	push   0x4(%ebx)
80103d4d:	e8 4e 33 00 00       	call   801070a0 <allocuvm>
80103d52:	83 c4 10             	add    $0x10,%esp
80103d55:	85 c0                	test   %eax,%eax
80103d57:	75 ce                	jne    80103d27 <growproc+0x27>
      return -1;
80103d59:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103d5e:	eb d7                	jmp    80103d37 <growproc+0x37>
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103d60:	8b 55 08             	mov    0x8(%ebp),%edx
80103d63:	83 ec 04             	sub    $0x4,%esp
80103d66:	01 c2                	add    %eax,%edx
80103d68:	52                   	push   %edx
80103d69:	50                   	push   %eax
80103d6a:	ff 73 04             	push   0x4(%ebx)
80103d6d:	e8 4e 34 00 00       	call   801071c0 <deallocuvm>
80103d72:	83 c4 10             	add    $0x10,%esp
80103d75:	85 c0                	test   %eax,%eax
80103d77:	75 ae                	jne    80103d27 <growproc+0x27>
80103d79:	eb de                	jmp    80103d59 <growproc+0x59>
80103d7b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103d80 <fork>:
{
80103d80:	55                   	push   %ebp
80103d81:	89 e5                	mov    %esp,%ebp
80103d83:	57                   	push   %edi
80103d84:	56                   	push   %esi
80103d85:	53                   	push   %ebx
80103d86:	83 ec 1c             	sub    $0x1c,%esp
  pushcli();
80103d89:	e8 92 09 00 00       	call   80104720 <pushcli>
  c = mycpu();
80103d8e:	e8 ad fd ff ff       	call   80103b40 <mycpu>
  p = c->proc;
80103d93:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103d99:	e8 d2 09 00 00       	call   80104770 <popcli>
  if((np = allocproc()) == 0){
80103d9e:	e8 5d fc ff ff       	call   80103a00 <allocproc>
80103da3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80103da6:	85 c0                	test   %eax,%eax
80103da8:	0f 84 d6 00 00 00    	je     80103e84 <fork+0x104>
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
80103dae:	83 ec 08             	sub    $0x8,%esp
80103db1:	ff 33                	push   (%ebx)
80103db3:	89 c7                	mov    %eax,%edi
80103db5:	ff 73 04             	push   0x4(%ebx)
80103db8:	e8 a3 35 00 00       	call   80107360 <copyuvm>
80103dbd:	83 c4 10             	add    $0x10,%esp
80103dc0:	89 47 04             	mov    %eax,0x4(%edi)
80103dc3:	85 c0                	test   %eax,%eax
80103dc5:	0f 84 9a 00 00 00    	je     80103e65 <fork+0xe5>
  np->sz = curproc->sz;
80103dcb:	8b 03                	mov    (%ebx),%eax
80103dcd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80103dd0:	89 01                	mov    %eax,(%ecx)
  *np->tf = *curproc->tf;
80103dd2:	8b 79 18             	mov    0x18(%ecx),%edi
  np->parent = curproc;
80103dd5:	89 c8                	mov    %ecx,%eax
80103dd7:	89 59 14             	mov    %ebx,0x14(%ecx)
  *np->tf = *curproc->tf;
80103dda:	b9 13 00 00 00       	mov    $0x13,%ecx
80103ddf:	8b 73 18             	mov    0x18(%ebx),%esi
80103de2:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  for(i = 0; i < NOFILE; i++)
80103de4:	31 f6                	xor    %esi,%esi
  np->tf->eax = 0;
80103de6:	8b 40 18             	mov    0x18(%eax),%eax
80103de9:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
    if(curproc->ofile[i])
80103df0:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
80103df4:	85 c0                	test   %eax,%eax
80103df6:	74 13                	je     80103e0b <fork+0x8b>
      np->ofile[i] = filedup(curproc->ofile[i]);
80103df8:	83 ec 0c             	sub    $0xc,%esp
80103dfb:	50                   	push   %eax
80103dfc:	e8 2f d1 ff ff       	call   80100f30 <filedup>
80103e01:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80103e04:	83 c4 10             	add    $0x10,%esp
80103e07:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
  for(i = 0; i < NOFILE; i++)
80103e0b:	83 c6 01             	add    $0x1,%esi
80103e0e:	83 fe 10             	cmp    $0x10,%esi
80103e11:	75 dd                	jne    80103df0 <fork+0x70>
  np->cwd = idup(curproc->cwd);
80103e13:	83 ec 0c             	sub    $0xc,%esp
80103e16:	ff 73 68             	push   0x68(%ebx)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103e19:	83 c3 6c             	add    $0x6c,%ebx
  np->cwd = idup(curproc->cwd);
80103e1c:	e8 1f da ff ff       	call   80101840 <idup>
80103e21:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103e24:	83 c4 0c             	add    $0xc,%esp
  np->cwd = idup(curproc->cwd);
80103e27:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103e2a:	8d 47 6c             	lea    0x6c(%edi),%eax
80103e2d:	6a 10                	push   $0x10
80103e2f:	53                   	push   %ebx
80103e30:	50                   	push   %eax
80103e31:	e8 1a 0d 00 00       	call   80104b50 <safestrcpy>
  pid = np->pid;
80103e36:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
80103e39:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103e40:	e8 3b 0a 00 00       	call   80104880 <acquire>
  np->state = RUNNABLE;
80103e45:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
80103e4c:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103e53:	e8 c8 09 00 00       	call   80104820 <release>
  return pid;
80103e58:	83 c4 10             	add    $0x10,%esp
}
80103e5b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103e5e:	89 d8                	mov    %ebx,%eax
80103e60:	5b                   	pop    %ebx
80103e61:	5e                   	pop    %esi
80103e62:	5f                   	pop    %edi
80103e63:	5d                   	pop    %ebp
80103e64:	c3                   	ret
    kfree(np->kstack);
80103e65:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103e68:	83 ec 0c             	sub    $0xc,%esp
80103e6b:	ff 73 08             	push   0x8(%ebx)
80103e6e:	e8 4d e7 ff ff       	call   801025c0 <kfree>
    np->kstack = 0;
80103e73:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    return -1;
80103e7a:	83 c4 10             	add    $0x10,%esp
    np->state = UNUSED;
80103e7d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80103e84:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103e89:	eb d0                	jmp    80103e5b <fork+0xdb>
80103e8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103e90 <scheduler>:
{
80103e90:	55                   	push   %ebp
80103e91:	89 e5                	mov    %esp,%ebp
80103e93:	57                   	push   %edi
80103e94:	56                   	push   %esi
80103e95:	53                   	push   %ebx
80103e96:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
80103e99:	e8 a2 fc ff ff       	call   80103b40 <mycpu>
  c->proc = 0;
80103e9e:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
80103ea5:	00 00 00 
  struct cpu *c = mycpu();
80103ea8:	89 c6                	mov    %eax,%esi
  c->proc = 0;
80103eaa:	8d 78 04             	lea    0x4(%eax),%edi
80103ead:	8d 76 00             	lea    0x0(%esi),%esi
  asm volatile("sti");
80103eb0:	fb                   	sti
    acquire(&ptable.lock);
80103eb1:	83 ec 0c             	sub    $0xc,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103eb4:	bb 54 1d 11 80       	mov    $0x80111d54,%ebx
    acquire(&ptable.lock);
80103eb9:	68 20 1d 11 80       	push   $0x80111d20
80103ebe:	e8 bd 09 00 00       	call   80104880 <acquire>
80103ec3:	83 c4 10             	add    $0x10,%esp
80103ec6:	66 90                	xchg   %ax,%ax
80103ec8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103ecf:	00 
      if(p->state != RUNNABLE)
80103ed0:	83 7b 0c 03          	cmpl   $0x3,0xc(%ebx)
80103ed4:	75 33                	jne    80103f09 <scheduler+0x79>
      switchuvm(p);
80103ed6:	83 ec 0c             	sub    $0xc,%esp
      c->proc = p;
80103ed9:	89 9e ac 00 00 00    	mov    %ebx,0xac(%esi)
      switchuvm(p);
80103edf:	53                   	push   %ebx
80103ee0:	e8 5b 2f 00 00       	call   80106e40 <switchuvm>
      swtch(&(c->scheduler), p->context);
80103ee5:	58                   	pop    %eax
80103ee6:	5a                   	pop    %edx
80103ee7:	ff 73 1c             	push   0x1c(%ebx)
80103eea:	57                   	push   %edi
      p->state = RUNNING;
80103eeb:	c7 43 0c 04 00 00 00 	movl   $0x4,0xc(%ebx)
      swtch(&(c->scheduler), p->context);
80103ef2:	e8 c4 0c 00 00       	call   80104bbb <swtch>
      switchkvm();
80103ef7:	e8 34 2f 00 00       	call   80106e30 <switchkvm>
      c->proc = 0;
80103efc:	83 c4 10             	add    $0x10,%esp
80103eff:	c7 86 ac 00 00 00 00 	movl   $0x0,0xac(%esi)
80103f06:	00 00 00 
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103f09:	83 c3 7c             	add    $0x7c,%ebx
80103f0c:	81 fb 54 3c 11 80    	cmp    $0x80113c54,%ebx
80103f12:	75 bc                	jne    80103ed0 <scheduler+0x40>
    release(&ptable.lock);
80103f14:	83 ec 0c             	sub    $0xc,%esp
80103f17:	68 20 1d 11 80       	push   $0x80111d20
80103f1c:	e8 ff 08 00 00       	call   80104820 <release>
    sti();
80103f21:	83 c4 10             	add    $0x10,%esp
80103f24:	eb 8a                	jmp    80103eb0 <scheduler+0x20>
80103f26:	66 90                	xchg   %ax,%ax
80103f28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103f2f:	00 

80103f30 <sched>:
{
80103f30:	55                   	push   %ebp
80103f31:	89 e5                	mov    %esp,%ebp
80103f33:	56                   	push   %esi
80103f34:	53                   	push   %ebx
  pushcli();
80103f35:	e8 e6 07 00 00       	call   80104720 <pushcli>
  c = mycpu();
80103f3a:	e8 01 fc ff ff       	call   80103b40 <mycpu>
  p = c->proc;
80103f3f:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103f45:	e8 26 08 00 00       	call   80104770 <popcli>
  if(!holding(&ptable.lock))
80103f4a:	83 ec 0c             	sub    $0xc,%esp
80103f4d:	68 20 1d 11 80       	push   $0x80111d20
80103f52:	e8 79 08 00 00       	call   801047d0 <holding>
80103f57:	83 c4 10             	add    $0x10,%esp
80103f5a:	85 c0                	test   %eax,%eax
80103f5c:	74 4f                	je     80103fad <sched+0x7d>
  if(mycpu()->ncli != 1)
80103f5e:	e8 dd fb ff ff       	call   80103b40 <mycpu>
80103f63:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103f6a:	75 68                	jne    80103fd4 <sched+0xa4>
  if(p->state == RUNNING)
80103f6c:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80103f70:	74 55                	je     80103fc7 <sched+0x97>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103f72:	9c                   	pushf
80103f73:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103f74:	f6 c4 02             	test   $0x2,%ah
80103f77:	75 41                	jne    80103fba <sched+0x8a>
  intena = mycpu()->intena;
80103f79:	e8 c2 fb ff ff       	call   80103b40 <mycpu>
  swtch(&p->context, mycpu()->scheduler);
80103f7e:	83 c3 1c             	add    $0x1c,%ebx
  intena = mycpu()->intena;
80103f81:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
80103f87:	e8 b4 fb ff ff       	call   80103b40 <mycpu>
80103f8c:	83 ec 08             	sub    $0x8,%esp
80103f8f:	ff 70 04             	push   0x4(%eax)
80103f92:	53                   	push   %ebx
80103f93:	e8 23 0c 00 00       	call   80104bbb <swtch>
  mycpu()->intena = intena;
80103f98:	e8 a3 fb ff ff       	call   80103b40 <mycpu>
}
80103f9d:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
80103fa0:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
80103fa6:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103fa9:	5b                   	pop    %ebx
80103faa:	5e                   	pop    %esi
80103fab:	5d                   	pop    %ebp
80103fac:	c3                   	ret
    panic("sched ptable.lock");
80103fad:	83 ec 0c             	sub    $0xc,%esp
80103fb0:	68 31 78 10 80       	push   $0x80107831
80103fb5:	e8 e6 c3 ff ff       	call   801003a0 <panic>
    panic("sched interruptible");
80103fba:	83 ec 0c             	sub    $0xc,%esp
80103fbd:	68 5d 78 10 80       	push   $0x8010785d
80103fc2:	e8 d9 c3 ff ff       	call   801003a0 <panic>
    panic("sched running");
80103fc7:	83 ec 0c             	sub    $0xc,%esp
80103fca:	68 4f 78 10 80       	push   $0x8010784f
80103fcf:	e8 cc c3 ff ff       	call   801003a0 <panic>
    panic("sched locks");
80103fd4:	83 ec 0c             	sub    $0xc,%esp
80103fd7:	68 43 78 10 80       	push   $0x80107843
80103fdc:	e8 bf c3 ff ff       	call   801003a0 <panic>
80103fe1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103fe8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103fef:	00 

80103ff0 <exit>:
{
80103ff0:	55                   	push   %ebp
80103ff1:	89 e5                	mov    %esp,%ebp
80103ff3:	57                   	push   %edi
80103ff4:	56                   	push   %esi
80103ff5:	53                   	push   %ebx
80103ff6:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
80103ff9:	e8 e2 fb ff ff       	call   80103be0 <myproc>
  if(curproc == initproc)
80103ffe:	39 05 54 3c 11 80    	cmp    %eax,0x80113c54
80104004:	0f 84 0d 01 00 00    	je     80104117 <exit+0x127>
8010400a:	89 c3                	mov    %eax,%ebx
8010400c:	8d 70 28             	lea    0x28(%eax),%esi
8010400f:	8d 78 68             	lea    0x68(%eax),%edi
80104012:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104018:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010401f:	00 
    if(curproc->ofile[fd]){
80104020:	8b 06                	mov    (%esi),%eax
80104022:	85 c0                	test   %eax,%eax
80104024:	74 12                	je     80104038 <exit+0x48>
      fileclose(curproc->ofile[fd]);
80104026:	83 ec 0c             	sub    $0xc,%esp
80104029:	50                   	push   %eax
8010402a:	e8 51 cf ff ff       	call   80100f80 <fileclose>
      curproc->ofile[fd] = 0;
8010402f:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80104035:	83 c4 10             	add    $0x10,%esp
  for(fd = 0; fd < NOFILE; fd++){
80104038:	83 c6 04             	add    $0x4,%esi
8010403b:	39 f7                	cmp    %esi,%edi
8010403d:	75 e1                	jne    80104020 <exit+0x30>
  begin_op();
8010403f:	e8 1c ef ff ff       	call   80102f60 <begin_op>
  iput(curproc->cwd);
80104044:	83 ec 0c             	sub    $0xc,%esp
80104047:	ff 73 68             	push   0x68(%ebx)
8010404a:	e8 51 d9 ff ff       	call   801019a0 <iput>
  end_op();
8010404f:	e8 7c ef ff ff       	call   80102fd0 <end_op>
  curproc->cwd = 0;
80104054:	c7 43 68 00 00 00 00 	movl   $0x0,0x68(%ebx)
  acquire(&ptable.lock);
8010405b:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80104062:	e8 19 08 00 00       	call   80104880 <acquire>
  wakeup1(curproc->parent);
80104067:	8b 53 14             	mov    0x14(%ebx),%edx
8010406a:	83 c4 10             	add    $0x10,%esp
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010406d:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80104072:	eb 16                	jmp    8010408a <exit+0x9a>
80104074:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104078:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010407f:	00 
80104080:	83 c0 7c             	add    $0x7c,%eax
80104083:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
80104088:	74 1c                	je     801040a6 <exit+0xb6>
    if(p->state == SLEEPING && p->chan == chan)
8010408a:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
8010408e:	75 f0                	jne    80104080 <exit+0x90>
80104090:	3b 50 20             	cmp    0x20(%eax),%edx
80104093:	75 eb                	jne    80104080 <exit+0x90>
      p->state = RUNNABLE;
80104095:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010409c:	83 c0 7c             	add    $0x7c,%eax
8010409f:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
801040a4:	75 e4                	jne    8010408a <exit+0x9a>
      p->parent = initproc;
801040a6:	8b 0d 54 3c 11 80    	mov    0x80113c54,%ecx
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801040ac:	ba 54 1d 11 80       	mov    $0x80111d54,%edx
801040b1:	eb 18                	jmp    801040cb <exit+0xdb>
801040b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801040b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801040bf:	00 
801040c0:	83 c2 7c             	add    $0x7c,%edx
801040c3:	81 fa 54 3c 11 80    	cmp    $0x80113c54,%edx
801040c9:	74 33                	je     801040fe <exit+0x10e>
    if(p->parent == curproc){
801040cb:	39 5a 14             	cmp    %ebx,0x14(%edx)
801040ce:	75 f0                	jne    801040c0 <exit+0xd0>
      p->parent = initproc;
801040d0:	89 4a 14             	mov    %ecx,0x14(%edx)
      if(p->state == ZOMBIE)
801040d3:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
801040d7:	75 e7                	jne    801040c0 <exit+0xd0>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801040d9:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
801040de:	eb 0a                	jmp    801040ea <exit+0xfa>
801040e0:	83 c0 7c             	add    $0x7c,%eax
801040e3:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
801040e8:	74 d6                	je     801040c0 <exit+0xd0>
    if(p->state == SLEEPING && p->chan == chan)
801040ea:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801040ee:	75 f0                	jne    801040e0 <exit+0xf0>
801040f0:	3b 48 20             	cmp    0x20(%eax),%ecx
801040f3:	75 eb                	jne    801040e0 <exit+0xf0>
      p->state = RUNNABLE;
801040f5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
801040fc:	eb e2                	jmp    801040e0 <exit+0xf0>
  curproc->state = ZOMBIE;
801040fe:	c7 43 0c 05 00 00 00 	movl   $0x5,0xc(%ebx)
  sched();
80104105:	e8 26 fe ff ff       	call   80103f30 <sched>
  panic("zombie exit");
8010410a:	83 ec 0c             	sub    $0xc,%esp
8010410d:	68 7e 78 10 80       	push   $0x8010787e
80104112:	e8 89 c2 ff ff       	call   801003a0 <panic>
    panic("init exiting");
80104117:	83 ec 0c             	sub    $0xc,%esp
8010411a:	68 71 78 10 80       	push   $0x80107871
8010411f:	e8 7c c2 ff ff       	call   801003a0 <panic>
80104124:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104128:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010412f:	00 

80104130 <wait>:
{
80104130:	55                   	push   %ebp
80104131:	89 e5                	mov    %esp,%ebp
80104133:	56                   	push   %esi
80104134:	53                   	push   %ebx
  pushcli();
80104135:	e8 e6 05 00 00       	call   80104720 <pushcli>
  c = mycpu();
8010413a:	e8 01 fa ff ff       	call   80103b40 <mycpu>
  p = c->proc;
8010413f:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80104145:	e8 26 06 00 00       	call   80104770 <popcli>
  acquire(&ptable.lock);
8010414a:	83 ec 0c             	sub    $0xc,%esp
8010414d:	68 20 1d 11 80       	push   $0x80111d20
80104152:	e8 29 07 00 00       	call   80104880 <acquire>
80104157:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
8010415a:	31 c0                	xor    %eax,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
8010415c:	bb 54 1d 11 80       	mov    $0x80111d54,%ebx
80104161:	eb 18                	jmp    8010417b <wait+0x4b>
80104163:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104168:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010416f:	00 
80104170:	83 c3 7c             	add    $0x7c,%ebx
80104173:	81 fb 54 3c 11 80    	cmp    $0x80113c54,%ebx
80104179:	74 1b                	je     80104196 <wait+0x66>
      if(p->parent != curproc)
8010417b:	39 73 14             	cmp    %esi,0x14(%ebx)
8010417e:	75 f0                	jne    80104170 <wait+0x40>
      if(p->state == ZOMBIE){
80104180:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80104184:	74 62                	je     801041e8 <wait+0xb8>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104186:	83 c3 7c             	add    $0x7c,%ebx
      havekids = 1;
80104189:	b8 01 00 00 00       	mov    $0x1,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
8010418e:	81 fb 54 3c 11 80    	cmp    $0x80113c54,%ebx
80104194:	75 e5                	jne    8010417b <wait+0x4b>
    if(!havekids || curproc->killed){
80104196:	85 c0                	test   %eax,%eax
80104198:	0f 84 a0 00 00 00    	je     8010423e <wait+0x10e>
8010419e:	8b 46 24             	mov    0x24(%esi),%eax
801041a1:	85 c0                	test   %eax,%eax
801041a3:	0f 85 95 00 00 00    	jne    8010423e <wait+0x10e>
  pushcli();
801041a9:	e8 72 05 00 00       	call   80104720 <pushcli>
  c = mycpu();
801041ae:	e8 8d f9 ff ff       	call   80103b40 <mycpu>
  p = c->proc;
801041b3:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801041b9:	e8 b2 05 00 00       	call   80104770 <popcli>
  if(p == 0)
801041be:	85 db                	test   %ebx,%ebx
801041c0:	0f 84 8f 00 00 00    	je     80104255 <wait+0x125>
  p->chan = chan;
801041c6:	89 73 20             	mov    %esi,0x20(%ebx)
  p->state = SLEEPING;
801041c9:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
801041d0:	e8 5b fd ff ff       	call   80103f30 <sched>
  p->chan = 0;
801041d5:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
801041dc:	e9 79 ff ff ff       	jmp    8010415a <wait+0x2a>
801041e1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        kfree(p->kstack);
801041e8:	83 ec 0c             	sub    $0xc,%esp
        pid = p->pid;
801041eb:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
801041ee:	ff 73 08             	push   0x8(%ebx)
801041f1:	e8 ca e3 ff ff       	call   801025c0 <kfree>
        p->kstack = 0;
801041f6:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
801041fd:	5a                   	pop    %edx
801041fe:	ff 73 04             	push   0x4(%ebx)
80104201:	e8 ea 2f 00 00       	call   801071f0 <freevm>
        p->pid = 0;
80104206:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
8010420d:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
80104214:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80104218:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
8010421f:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
80104226:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
8010422d:	e8 ee 05 00 00       	call   80104820 <release>
        return pid;
80104232:	83 c4 10             	add    $0x10,%esp
}
80104235:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104238:	89 f0                	mov    %esi,%eax
8010423a:	5b                   	pop    %ebx
8010423b:	5e                   	pop    %esi
8010423c:	5d                   	pop    %ebp
8010423d:	c3                   	ret
      release(&ptable.lock);
8010423e:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104241:	be ff ff ff ff       	mov    $0xffffffff,%esi
      release(&ptable.lock);
80104246:	68 20 1d 11 80       	push   $0x80111d20
8010424b:	e8 d0 05 00 00       	call   80104820 <release>
      return -1;
80104250:	83 c4 10             	add    $0x10,%esp
80104253:	eb e0                	jmp    80104235 <wait+0x105>
    panic("sleep");
80104255:	83 ec 0c             	sub    $0xc,%esp
80104258:	68 8a 78 10 80       	push   $0x8010788a
8010425d:	e8 3e c1 ff ff       	call   801003a0 <panic>
80104262:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104268:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010426f:	00 

80104270 <yield>:
{
80104270:	55                   	push   %ebp
80104271:	89 e5                	mov    %esp,%ebp
80104273:	53                   	push   %ebx
80104274:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
80104277:	68 20 1d 11 80       	push   $0x80111d20
8010427c:	e8 ff 05 00 00       	call   80104880 <acquire>
  pushcli();
80104281:	e8 9a 04 00 00       	call   80104720 <pushcli>
  c = mycpu();
80104286:	e8 b5 f8 ff ff       	call   80103b40 <mycpu>
  p = c->proc;
8010428b:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104291:	e8 da 04 00 00       	call   80104770 <popcli>
  myproc()->state = RUNNABLE;
80104296:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  sched();
8010429d:	e8 8e fc ff ff       	call   80103f30 <sched>
  release(&ptable.lock);
801042a2:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
801042a9:	e8 72 05 00 00       	call   80104820 <release>
}
801042ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801042b1:	83 c4 10             	add    $0x10,%esp
801042b4:	c9                   	leave
801042b5:	c3                   	ret
801042b6:	66 90                	xchg   %ax,%ax
801042b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801042bf:	00 

801042c0 <sleep>:
{
801042c0:	55                   	push   %ebp
801042c1:	89 e5                	mov    %esp,%ebp
801042c3:	57                   	push   %edi
801042c4:	56                   	push   %esi
801042c5:	53                   	push   %ebx
801042c6:	83 ec 0c             	sub    $0xc,%esp
801042c9:	8b 7d 08             	mov    0x8(%ebp),%edi
801042cc:	8b 75 0c             	mov    0xc(%ebp),%esi
  pushcli();
801042cf:	e8 4c 04 00 00       	call   80104720 <pushcli>
  c = mycpu();
801042d4:	e8 67 f8 ff ff       	call   80103b40 <mycpu>
  p = c->proc;
801042d9:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801042df:	e8 8c 04 00 00       	call   80104770 <popcli>
  if(p == 0)
801042e4:	85 db                	test   %ebx,%ebx
801042e6:	0f 84 87 00 00 00    	je     80104373 <sleep+0xb3>
  if(lk == 0)
801042ec:	85 f6                	test   %esi,%esi
801042ee:	74 76                	je     80104366 <sleep+0xa6>
  if(lk != &ptable.lock){  //DOC: sleeplock0
801042f0:	81 fe 20 1d 11 80    	cmp    $0x80111d20,%esi
801042f6:	74 50                	je     80104348 <sleep+0x88>
    acquire(&ptable.lock);  //DOC: sleeplock1
801042f8:	83 ec 0c             	sub    $0xc,%esp
801042fb:	68 20 1d 11 80       	push   $0x80111d20
80104300:	e8 7b 05 00 00       	call   80104880 <acquire>
    release(lk);
80104305:	89 34 24             	mov    %esi,(%esp)
80104308:	e8 13 05 00 00       	call   80104820 <release>
  p->chan = chan;
8010430d:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104310:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104317:	e8 14 fc ff ff       	call   80103f30 <sched>
  p->chan = 0;
8010431c:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80104323:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
8010432a:	e8 f1 04 00 00       	call   80104820 <release>
    acquire(lk);
8010432f:	83 c4 10             	add    $0x10,%esp
80104332:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104335:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104338:	5b                   	pop    %ebx
80104339:	5e                   	pop    %esi
8010433a:	5f                   	pop    %edi
8010433b:	5d                   	pop    %ebp
    acquire(lk);
8010433c:	e9 3f 05 00 00       	jmp    80104880 <acquire>
80104341:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  p->chan = chan;
80104348:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
8010434b:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104352:	e8 d9 fb ff ff       	call   80103f30 <sched>
  p->chan = 0;
80104357:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
8010435e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104361:	5b                   	pop    %ebx
80104362:	5e                   	pop    %esi
80104363:	5f                   	pop    %edi
80104364:	5d                   	pop    %ebp
80104365:	c3                   	ret
    panic("sleep without lk");
80104366:	83 ec 0c             	sub    $0xc,%esp
80104369:	68 90 78 10 80       	push   $0x80107890
8010436e:	e8 2d c0 ff ff       	call   801003a0 <panic>
    panic("sleep");
80104373:	83 ec 0c             	sub    $0xc,%esp
80104376:	68 8a 78 10 80       	push   $0x8010788a
8010437b:	e8 20 c0 ff ff       	call   801003a0 <panic>

80104380 <wakeup>:
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
80104380:	55                   	push   %ebp
80104381:	89 e5                	mov    %esp,%ebp
80104383:	53                   	push   %ebx
80104384:	83 ec 10             	sub    $0x10,%esp
80104387:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ptable.lock);
8010438a:	68 20 1d 11 80       	push   $0x80111d20
8010438f:	e8 ec 04 00 00       	call   80104880 <acquire>
80104394:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104397:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
8010439c:	eb 0c                	jmp    801043aa <wakeup+0x2a>
8010439e:	66 90                	xchg   %ax,%ax
801043a0:	83 c0 7c             	add    $0x7c,%eax
801043a3:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
801043a8:	74 1c                	je     801043c6 <wakeup+0x46>
    if(p->state == SLEEPING && p->chan == chan)
801043aa:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801043ae:	75 f0                	jne    801043a0 <wakeup+0x20>
801043b0:	3b 58 20             	cmp    0x20(%eax),%ebx
801043b3:	75 eb                	jne    801043a0 <wakeup+0x20>
      p->state = RUNNABLE;
801043b5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801043bc:	83 c0 7c             	add    $0x7c,%eax
801043bf:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
801043c4:	75 e4                	jne    801043aa <wakeup+0x2a>
  wakeup1(chan);
  release(&ptable.lock);
801043c6:	c7 45 08 20 1d 11 80 	movl   $0x80111d20,0x8(%ebp)
}
801043cd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801043d0:	c9                   	leave
  release(&ptable.lock);
801043d1:	e9 4a 04 00 00       	jmp    80104820 <release>
801043d6:	66 90                	xchg   %ax,%ax
801043d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801043df:	00 

801043e0 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
801043e0:	55                   	push   %ebp
801043e1:	89 e5                	mov    %esp,%ebp
801043e3:	53                   	push   %ebx
801043e4:	83 ec 10             	sub    $0x10,%esp
801043e7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
801043ea:	68 20 1d 11 80       	push   $0x80111d20
801043ef:	e8 8c 04 00 00       	call   80104880 <acquire>
801043f4:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801043f7:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
801043fc:	eb 0c                	jmp    8010440a <kill+0x2a>
801043fe:	66 90                	xchg   %ax,%ax
80104400:	83 c0 7c             	add    $0x7c,%eax
80104403:	3d 54 3c 11 80       	cmp    $0x80113c54,%eax
80104408:	74 36                	je     80104440 <kill+0x60>
    if(p->pid == pid){
8010440a:	39 58 10             	cmp    %ebx,0x10(%eax)
8010440d:	75 f1                	jne    80104400 <kill+0x20>
      p->killed = 1;
8010440f:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
80104416:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
8010441a:	75 07                	jne    80104423 <kill+0x43>
        p->state = RUNNABLE;
8010441c:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104423:	83 ec 0c             	sub    $0xc,%esp
80104426:	68 20 1d 11 80       	push   $0x80111d20
8010442b:	e8 f0 03 00 00       	call   80104820 <release>
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}
80104430:	8b 5d fc             	mov    -0x4(%ebp),%ebx
      return 0;
80104433:	83 c4 10             	add    $0x10,%esp
80104436:	31 c0                	xor    %eax,%eax
}
80104438:	c9                   	leave
80104439:	c3                   	ret
8010443a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
80104440:	83 ec 0c             	sub    $0xc,%esp
80104443:	68 20 1d 11 80       	push   $0x80111d20
80104448:	e8 d3 03 00 00       	call   80104820 <release>
}
8010444d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
80104450:	83 c4 10             	add    $0x10,%esp
80104453:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104458:	c9                   	leave
80104459:	c3                   	ret
8010445a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104460 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80104460:	55                   	push   %ebp
80104461:	89 e5                	mov    %esp,%ebp
80104463:	57                   	push   %edi
80104464:	56                   	push   %esi
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
80104465:	8d 75 c0             	lea    -0x40(%ebp),%esi
{
80104468:	53                   	push   %ebx
80104469:	bb c0 1d 11 80       	mov    $0x80111dc0,%ebx
8010446e:	83 ec 3c             	sub    $0x3c,%esp
80104471:	eb 24                	jmp    80104497 <procdump+0x37>
80104473:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
80104478:	83 ec 0c             	sub    $0xc,%esp
8010447b:	68 4f 7a 10 80       	push   $0x80107a4f
80104480:	e8 4b c2 ff ff       	call   801006d0 <cprintf>
80104485:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104488:	83 c3 7c             	add    $0x7c,%ebx
8010448b:	81 fb c0 3c 11 80    	cmp    $0x80113cc0,%ebx
80104491:	0f 84 89 00 00 00    	je     80104520 <procdump+0xc0>
    if(p->state == UNUSED)
80104497:	8b 43 a0             	mov    -0x60(%ebx),%eax
8010449a:	85 c0                	test   %eax,%eax
8010449c:	74 ea                	je     80104488 <procdump+0x28>
      state = "???";
8010449e:	ba a1 78 10 80       	mov    $0x801078a1,%edx
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
801044a3:	83 f8 05             	cmp    $0x5,%eax
801044a6:	77 11                	ja     801044b9 <procdump+0x59>
801044a8:	8b 14 85 60 7e 10 80 	mov    -0x7fef81a0(,%eax,4),%edx
      state = "???";
801044af:	b8 a1 78 10 80       	mov    $0x801078a1,%eax
801044b4:	85 d2                	test   %edx,%edx
801044b6:	0f 44 d0             	cmove  %eax,%edx
    cprintf("%d %s %s", p->pid, state, p->name);
801044b9:	53                   	push   %ebx
801044ba:	52                   	push   %edx
801044bb:	ff 73 a4             	push   -0x5c(%ebx)
801044be:	68 a5 78 10 80       	push   $0x801078a5
801044c3:	e8 08 c2 ff ff       	call   801006d0 <cprintf>
    if(p->state == SLEEPING){
801044c8:	83 c4 10             	add    $0x10,%esp
801044cb:	83 7b a0 02          	cmpl   $0x2,-0x60(%ebx)
801044cf:	75 a7                	jne    80104478 <procdump+0x18>
      getcallerpcs((uint*)p->context->ebp+2, pc);
801044d1:	83 ec 08             	sub    $0x8,%esp
801044d4:	89 f7                	mov    %esi,%edi
801044d6:	56                   	push   %esi
801044d7:	8b 43 b0             	mov    -0x50(%ebx),%eax
801044da:	8b 40 0c             	mov    0xc(%eax),%eax
801044dd:	83 c0 08             	add    $0x8,%eax
801044e0:	50                   	push   %eax
801044e1:	e8 9a 01 00 00       	call   80104680 <getcallerpcs>
      for(i=0; i<10 && pc[i] != 0; i++)
801044e6:	83 c4 10             	add    $0x10,%esp
801044e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801044f0:	8b 07                	mov    (%edi),%eax
801044f2:	85 c0                	test   %eax,%eax
801044f4:	74 82                	je     80104478 <procdump+0x18>
        cprintf(" %p", pc[i]);
801044f6:	83 ec 08             	sub    $0x8,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
801044f9:	83 c7 04             	add    $0x4,%edi
        cprintf(" %p", pc[i]);
801044fc:	50                   	push   %eax
801044fd:	68 e1 75 10 80       	push   $0x801075e1
80104502:	e8 c9 c1 ff ff       	call   801006d0 <cprintf>
      for(i=0; i<10 && pc[i] != 0; i++)
80104507:	8d 45 e8             	lea    -0x18(%ebp),%eax
8010450a:	83 c4 10             	add    $0x10,%esp
8010450d:	39 c7                	cmp    %eax,%edi
8010450f:	75 df                	jne    801044f0 <procdump+0x90>
80104511:	e9 62 ff ff ff       	jmp    80104478 <procdump+0x18>
80104516:	66 90                	xchg   %ax,%ax
80104518:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010451f:	00 
  }
}
80104520:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104523:	5b                   	pop    %ebx
80104524:	5e                   	pop    %esi
80104525:	5f                   	pop    %edi
80104526:	5d                   	pop    %ebp
80104527:	c3                   	ret
80104528:	66 90                	xchg   %ax,%ax
8010452a:	66 90                	xchg   %ax,%ax
8010452c:	66 90                	xchg   %ax,%ax
8010452e:	66 90                	xchg   %ax,%ax

80104530 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80104530:	55                   	push   %ebp
80104531:	89 e5                	mov    %esp,%ebp
80104533:	53                   	push   %ebx
80104534:	83 ec 0c             	sub    $0xc,%esp
80104537:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
8010453a:	68 d8 78 10 80       	push   $0x801078d8
8010453f:	8d 43 04             	lea    0x4(%ebx),%eax
80104542:	50                   	push   %eax
80104543:	e8 18 01 00 00       	call   80104660 <initlock>
  lk->name = name;
80104548:	8b 45 0c             	mov    0xc(%ebp),%eax
  lk->locked = 0;
8010454b:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
}
80104551:	83 c4 10             	add    $0x10,%esp
  lk->pid = 0;
80104554:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  lk->name = name;
8010455b:	89 43 38             	mov    %eax,0x38(%ebx)
}
8010455e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104561:	c9                   	leave
80104562:	c3                   	ret
80104563:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010456f:	00 

80104570 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104570:	55                   	push   %ebp
80104571:	89 e5                	mov    %esp,%ebp
80104573:	56                   	push   %esi
80104574:	53                   	push   %ebx
80104575:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104578:	8d 73 04             	lea    0x4(%ebx),%esi
8010457b:	83 ec 0c             	sub    $0xc,%esp
8010457e:	56                   	push   %esi
8010457f:	e8 fc 02 00 00       	call   80104880 <acquire>
  while (lk->locked) {
80104584:	8b 13                	mov    (%ebx),%edx
80104586:	83 c4 10             	add    $0x10,%esp
80104589:	85 d2                	test   %edx,%edx
8010458b:	74 16                	je     801045a3 <acquiresleep+0x33>
8010458d:	8d 76 00             	lea    0x0(%esi),%esi
    sleep(lk, &lk->lk);
80104590:	83 ec 08             	sub    $0x8,%esp
80104593:	56                   	push   %esi
80104594:	53                   	push   %ebx
80104595:	e8 26 fd ff ff       	call   801042c0 <sleep>
  while (lk->locked) {
8010459a:	8b 03                	mov    (%ebx),%eax
8010459c:	83 c4 10             	add    $0x10,%esp
8010459f:	85 c0                	test   %eax,%eax
801045a1:	75 ed                	jne    80104590 <acquiresleep+0x20>
  }
  lk->locked = 1;
801045a3:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
801045a9:	e8 32 f6 ff ff       	call   80103be0 <myproc>
801045ae:	8b 40 10             	mov    0x10(%eax),%eax
801045b1:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
801045b4:	89 75 08             	mov    %esi,0x8(%ebp)
}
801045b7:	8d 65 f8             	lea    -0x8(%ebp),%esp
801045ba:	5b                   	pop    %ebx
801045bb:	5e                   	pop    %esi
801045bc:	5d                   	pop    %ebp
  release(&lk->lk);
801045bd:	e9 5e 02 00 00       	jmp    80104820 <release>
801045c2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801045c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801045cf:	00 

801045d0 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
801045d0:	55                   	push   %ebp
801045d1:	89 e5                	mov    %esp,%ebp
801045d3:	56                   	push   %esi
801045d4:	53                   	push   %ebx
801045d5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
801045d8:	8d 73 04             	lea    0x4(%ebx),%esi
801045db:	83 ec 0c             	sub    $0xc,%esp
801045de:	56                   	push   %esi
801045df:	e8 9c 02 00 00       	call   80104880 <acquire>
  lk->locked = 0;
801045e4:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
801045ea:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
801045f1:	89 1c 24             	mov    %ebx,(%esp)
801045f4:	e8 87 fd ff ff       	call   80104380 <wakeup>
  release(&lk->lk);
801045f9:	83 c4 10             	add    $0x10,%esp
801045fc:	89 75 08             	mov    %esi,0x8(%ebp)
}
801045ff:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104602:	5b                   	pop    %ebx
80104603:	5e                   	pop    %esi
80104604:	5d                   	pop    %ebp
  release(&lk->lk);
80104605:	e9 16 02 00 00       	jmp    80104820 <release>
8010460a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104610 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80104610:	55                   	push   %ebp
80104611:	89 e5                	mov    %esp,%ebp
80104613:	57                   	push   %edi
80104614:	31 ff                	xor    %edi,%edi
80104616:	56                   	push   %esi
80104617:	53                   	push   %ebx
80104618:	83 ec 18             	sub    $0x18,%esp
8010461b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
8010461e:	8d 73 04             	lea    0x4(%ebx),%esi
80104621:	56                   	push   %esi
80104622:	e8 59 02 00 00       	call   80104880 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
80104627:	8b 03                	mov    (%ebx),%eax
80104629:	83 c4 10             	add    $0x10,%esp
8010462c:	85 c0                	test   %eax,%eax
8010462e:	75 18                	jne    80104648 <holdingsleep+0x38>
  release(&lk->lk);
80104630:	83 ec 0c             	sub    $0xc,%esp
80104633:	56                   	push   %esi
80104634:	e8 e7 01 00 00       	call   80104820 <release>
  return r;
}
80104639:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010463c:	89 f8                	mov    %edi,%eax
8010463e:	5b                   	pop    %ebx
8010463f:	5e                   	pop    %esi
80104640:	5f                   	pop    %edi
80104641:	5d                   	pop    %ebp
80104642:	c3                   	ret
80104643:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lk->locked && (lk->pid == myproc()->pid);
80104648:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
8010464b:	e8 90 f5 ff ff       	call   80103be0 <myproc>
80104650:	39 58 10             	cmp    %ebx,0x10(%eax)
80104653:	0f 94 c0             	sete   %al
80104656:	0f b6 c0             	movzbl %al,%eax
80104659:	89 c7                	mov    %eax,%edi
8010465b:	eb d3                	jmp    80104630 <holdingsleep+0x20>
8010465d:	66 90                	xchg   %ax,%ax
8010465f:	90                   	nop

80104660 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80104660:	55                   	push   %ebp
80104661:	89 e5                	mov    %esp,%ebp
80104663:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80104666:	8b 55 0c             	mov    0xc(%ebp),%edx
  lk->locked = 0;
80104669:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->name = name;
8010466f:	89 50 04             	mov    %edx,0x4(%eax)
  lk->cpu = 0;
80104672:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80104679:	5d                   	pop    %ebp
8010467a:	c3                   	ret
8010467b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104680 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80104680:	55                   	push   %ebp
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
80104681:	31 d2                	xor    %edx,%edx
{
80104683:	89 e5                	mov    %esp,%ebp
80104685:	53                   	push   %ebx
  ebp = (uint*)v - 2;
80104686:	8b 45 08             	mov    0x8(%ebp),%eax
{
80104689:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  ebp = (uint*)v - 2;
8010468c:	83 e8 08             	sub    $0x8,%eax
  for(i = 0; i < 10; i++){
8010468f:	90                   	nop
80104690:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104697:	00 
80104698:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010469f:	00 
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
801046a0:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
801046a6:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
801046ac:	77 1a                	ja     801046c8 <getcallerpcs+0x48>
      break;
    pcs[i] = ebp[1];     // saved %eip
801046ae:	8b 58 04             	mov    0x4(%eax),%ebx
801046b1:	89 1c 91             	mov    %ebx,(%ecx,%edx,4)
  for(i = 0; i < 10; i++){
801046b4:	83 c2 01             	add    $0x1,%edx
    ebp = (uint*)ebp[0]; // saved %ebp
801046b7:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
801046b9:	83 fa 0a             	cmp    $0xa,%edx
801046bc:	75 e2                	jne    801046a0 <getcallerpcs+0x20>
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}
801046be:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801046c1:	c9                   	leave
801046c2:	c3                   	ret
801046c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(; i < 10; i++)
801046c8:	8d 04 91             	lea    (%ecx,%edx,4),%eax
801046cb:	83 c1 28             	add    $0x28,%ecx
801046ce:	89 ca                	mov    %ecx,%edx
801046d0:	29 c2                	sub    %eax,%edx
801046d2:	83 e2 04             	and    $0x4,%edx
801046d5:	74 29                	je     80104700 <getcallerpcs+0x80>
    pcs[i] = 0;
801046d7:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801046dd:	83 c0 04             	add    $0x4,%eax
801046e0:	39 c8                	cmp    %ecx,%eax
801046e2:	74 da                	je     801046be <getcallerpcs+0x3e>
801046e4:	eb 1a                	jmp    80104700 <getcallerpcs+0x80>
801046e6:	66 90                	xchg   %ax,%ax
801046e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801046ef:	00 
801046f0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801046f7:	00 
801046f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801046ff:	00 
    pcs[i] = 0;
80104700:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80104706:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
80104709:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
80104710:	39 c8                	cmp    %ecx,%eax
80104712:	75 ec                	jne    80104700 <getcallerpcs+0x80>
80104714:	eb a8                	jmp    801046be <getcallerpcs+0x3e>
80104716:	66 90                	xchg   %ax,%ax
80104718:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010471f:	00 

80104720 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
80104720:	55                   	push   %ebp
80104721:	89 e5                	mov    %esp,%ebp
80104723:	53                   	push   %ebx
80104724:	83 ec 04             	sub    $0x4,%esp
80104727:	9c                   	pushf
80104728:	5b                   	pop    %ebx
  asm volatile("cli");
80104729:	fa                   	cli
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
8010472a:	e8 11 f4 ff ff       	call   80103b40 <mycpu>
8010472f:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
80104735:	85 c0                	test   %eax,%eax
80104737:	74 17                	je     80104750 <pushcli+0x30>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
80104739:	e8 02 f4 ff ff       	call   80103b40 <mycpu>
8010473e:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80104745:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104748:	c9                   	leave
80104749:	c3                   	ret
8010474a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    mycpu()->intena = eflags & FL_IF;
80104750:	e8 eb f3 ff ff       	call   80103b40 <mycpu>
80104755:	81 e3 00 02 00 00    	and    $0x200,%ebx
8010475b:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80104761:	eb d6                	jmp    80104739 <pushcli+0x19>
80104763:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104768:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010476f:	00 

80104770 <popcli>:

void
popcli(void)
{
80104770:	55                   	push   %ebp
80104771:	89 e5                	mov    %esp,%ebp
80104773:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104776:	9c                   	pushf
80104777:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104778:	f6 c4 02             	test   $0x2,%ah
8010477b:	75 35                	jne    801047b2 <popcli+0x42>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
8010477d:	e8 be f3 ff ff       	call   80103b40 <mycpu>
80104782:	83 a8 a4 00 00 00 01 	subl   $0x1,0xa4(%eax)
80104789:	78 34                	js     801047bf <popcli+0x4f>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
8010478b:	e8 b0 f3 ff ff       	call   80103b40 <mycpu>
80104790:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80104796:	85 d2                	test   %edx,%edx
80104798:	74 06                	je     801047a0 <popcli+0x30>
    sti();
}
8010479a:	c9                   	leave
8010479b:	c3                   	ret
8010479c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(mycpu()->ncli == 0 && mycpu()->intena)
801047a0:	e8 9b f3 ff ff       	call   80103b40 <mycpu>
801047a5:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
801047ab:	85 c0                	test   %eax,%eax
801047ad:	74 eb                	je     8010479a <popcli+0x2a>
  asm volatile("sti");
801047af:	fb                   	sti
}
801047b0:	c9                   	leave
801047b1:	c3                   	ret
    panic("popcli - interruptible");
801047b2:	83 ec 0c             	sub    $0xc,%esp
801047b5:	68 e3 78 10 80       	push   $0x801078e3
801047ba:	e8 e1 bb ff ff       	call   801003a0 <panic>
    panic("popcli");
801047bf:	83 ec 0c             	sub    $0xc,%esp
801047c2:	68 fa 78 10 80       	push   $0x801078fa
801047c7:	e8 d4 bb ff ff       	call   801003a0 <panic>
801047cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801047d0 <holding>:
{
801047d0:	55                   	push   %ebp
801047d1:	89 e5                	mov    %esp,%ebp
801047d3:	53                   	push   %ebx
801047d4:	31 db                	xor    %ebx,%ebx
801047d6:	83 ec 04             	sub    $0x4,%esp
  pushcli();
801047d9:	e8 42 ff ff ff       	call   80104720 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
801047de:	8b 45 08             	mov    0x8(%ebp),%eax
801047e1:	8b 10                	mov    (%eax),%edx
801047e3:	85 d2                	test   %edx,%edx
801047e5:	75 11                	jne    801047f8 <holding+0x28>
  popcli();
801047e7:	e8 84 ff ff ff       	call   80104770 <popcli>
}
801047ec:	89 d8                	mov    %ebx,%eax
801047ee:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801047f1:	c9                   	leave
801047f2:	c3                   	ret
801047f3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lock->locked && lock->cpu == mycpu();
801047f8:	8b 58 08             	mov    0x8(%eax),%ebx
801047fb:	e8 40 f3 ff ff       	call   80103b40 <mycpu>
80104800:	39 c3                	cmp    %eax,%ebx
80104802:	0f 94 c3             	sete   %bl
  popcli();
80104805:	e8 66 ff ff ff       	call   80104770 <popcli>
  r = lock->locked && lock->cpu == mycpu();
8010480a:	0f b6 db             	movzbl %bl,%ebx
}
8010480d:	89 d8                	mov    %ebx,%eax
8010480f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104812:	c9                   	leave
80104813:	c3                   	ret
80104814:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104818:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010481f:	00 

80104820 <release>:
{
80104820:	55                   	push   %ebp
80104821:	89 e5                	mov    %esp,%ebp
80104823:	56                   	push   %esi
80104824:	53                   	push   %ebx
80104825:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
80104828:	e8 f3 fe ff ff       	call   80104720 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
8010482d:	8b 03                	mov    (%ebx),%eax
8010482f:	85 c0                	test   %eax,%eax
80104831:	75 15                	jne    80104848 <release+0x28>
  popcli();
80104833:	e8 38 ff ff ff       	call   80104770 <popcli>
    panic("release");
80104838:	83 ec 0c             	sub    $0xc,%esp
8010483b:	68 01 79 10 80       	push   $0x80107901
80104840:	e8 5b bb ff ff       	call   801003a0 <panic>
80104845:	8d 76 00             	lea    0x0(%esi),%esi
  r = lock->locked && lock->cpu == mycpu();
80104848:	8b 73 08             	mov    0x8(%ebx),%esi
8010484b:	e8 f0 f2 ff ff       	call   80103b40 <mycpu>
80104850:	39 c6                	cmp    %eax,%esi
80104852:	75 df                	jne    80104833 <release+0x13>
  popcli();
80104854:	e8 17 ff ff ff       	call   80104770 <popcli>
  lk->pcs[0] = 0;
80104859:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80104860:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80104867:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
8010486c:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
}
80104872:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104875:	5b                   	pop    %ebx
80104876:	5e                   	pop    %esi
80104877:	5d                   	pop    %ebp
  popcli();
80104878:	e9 f3 fe ff ff       	jmp    80104770 <popcli>
8010487d:	8d 76 00             	lea    0x0(%esi),%esi

80104880 <acquire>:
{
80104880:	55                   	push   %ebp
80104881:	89 e5                	mov    %esp,%ebp
80104883:	56                   	push   %esi
80104884:	53                   	push   %ebx
  pushcli(); // disable interrupts to avoid deadlock.
80104885:	e8 96 fe ff ff       	call   80104720 <pushcli>
  if(holding(lk))
8010488a:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
8010488d:	e8 8e fe ff ff       	call   80104720 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80104892:	8b 03                	mov    (%ebx),%eax
80104894:	85 c0                	test   %eax,%eax
80104896:	0f 85 c4 00 00 00    	jne    80104960 <acquire+0xe0>
  popcli();
8010489c:	e8 cf fe ff ff       	call   80104770 <popcli>
  asm volatile("lock; xchgl %0, %1" :
801048a1:	b8 01 00 00 00       	mov    $0x1,%eax
801048a6:	f0 87 03             	lock xchg %eax,(%ebx)
               "+m" (*addr), "=a" (result) :
               "1" (newval) :
               "cc");
  return result;
801048a9:	8b 55 08             	mov    0x8(%ebp),%edx
  while(xchg(&lk->locked, 1) != 0)
801048ac:	85 c0                	test   %eax,%eax
801048ae:	74 0c                	je     801048bc <acquire+0x3c>
  asm volatile("lock; xchgl %0, %1" :
801048b0:	b8 01 00 00 00       	mov    $0x1,%eax
801048b5:	f0 87 02             	lock xchg %eax,(%edx)
801048b8:	85 c0                	test   %eax,%eax
801048ba:	75 f4                	jne    801048b0 <acquire+0x30>
  __sync_synchronize();
801048bc:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
801048c1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801048c4:	e8 77 f2 ff ff       	call   80103b40 <mycpu>
  ebp = (uint*)v - 2;
801048c9:	89 ea                	mov    %ebp,%edx
  lk->cpu = mycpu();
801048cb:	89 43 08             	mov    %eax,0x8(%ebx)
  for(i = 0; i < 10; i++){
801048ce:	31 c0                	xor    %eax,%eax
801048d0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048d7:	00 
801048d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048df:	00 
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
801048e0:	8d 8a 00 00 00 80    	lea    -0x80000000(%edx),%ecx
801048e6:	81 f9 fe ff ff 7f    	cmp    $0x7ffffffe,%ecx
801048ec:	77 22                	ja     80104910 <acquire+0x90>
    pcs[i] = ebp[1];     // saved %eip
801048ee:	8b 4a 04             	mov    0x4(%edx),%ecx
801048f1:	89 4c 83 0c          	mov    %ecx,0xc(%ebx,%eax,4)
  for(i = 0; i < 10; i++){
801048f5:	83 c0 01             	add    $0x1,%eax
    ebp = (uint*)ebp[0]; // saved %ebp
801048f8:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
801048fa:	83 f8 0a             	cmp    $0xa,%eax
801048fd:	75 e1                	jne    801048e0 <acquire+0x60>
}
801048ff:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104902:	5b                   	pop    %ebx
80104903:	5e                   	pop    %esi
80104904:	5d                   	pop    %ebp
80104905:	c3                   	ret
80104906:	66 90                	xchg   %ax,%ax
80104908:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010490f:	00 
  for(; i < 10; i++)
80104910:	8d 44 83 0c          	lea    0xc(%ebx,%eax,4),%eax
80104914:	83 c3 34             	add    $0x34,%ebx
80104917:	89 da                	mov    %ebx,%edx
80104919:	29 c2                	sub    %eax,%edx
8010491b:	83 e2 04             	and    $0x4,%edx
8010491e:	74 20                	je     80104940 <acquire+0xc0>
    pcs[i] = 0;
80104920:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80104926:	83 c0 04             	add    $0x4,%eax
80104929:	39 d8                	cmp    %ebx,%eax
8010492b:	74 d2                	je     801048ff <acquire+0x7f>
8010492d:	8d 76 00             	lea    0x0(%esi),%esi
80104930:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104937:	00 
80104938:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010493f:	00 
    pcs[i] = 0;
80104940:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80104946:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
80104949:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
80104950:	39 d8                	cmp    %ebx,%eax
80104952:	75 ec                	jne    80104940 <acquire+0xc0>
80104954:	eb a9                	jmp    801048ff <acquire+0x7f>
80104956:	66 90                	xchg   %ax,%ax
80104958:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010495f:	00 
  r = lock->locked && lock->cpu == mycpu();
80104960:	8b 73 08             	mov    0x8(%ebx),%esi
80104963:	e8 d8 f1 ff ff       	call   80103b40 <mycpu>
80104968:	39 c6                	cmp    %eax,%esi
8010496a:	0f 85 2c ff ff ff    	jne    8010489c <acquire+0x1c>
  popcli();
80104970:	e8 fb fd ff ff       	call   80104770 <popcli>
    panic("acquire");
80104975:	83 ec 0c             	sub    $0xc,%esp
80104978:	68 09 79 10 80       	push   $0x80107909
8010497d:	e8 1e ba ff ff       	call   801003a0 <panic>
80104982:	66 90                	xchg   %ax,%ax
80104984:	66 90                	xchg   %ax,%ax
80104986:	66 90                	xchg   %ax,%ax
80104988:	66 90                	xchg   %ax,%ax
8010498a:	66 90                	xchg   %ax,%ax
8010498c:	66 90                	xchg   %ax,%ax
8010498e:	66 90                	xchg   %ax,%ax
80104990:	66 90                	xchg   %ax,%ax
80104992:	66 90                	xchg   %ax,%ax
80104994:	66 90                	xchg   %ax,%ax
80104996:	66 90                	xchg   %ax,%ax
80104998:	66 90                	xchg   %ax,%ax
8010499a:	66 90                	xchg   %ax,%ax
8010499c:	66 90                	xchg   %ax,%ax
8010499e:	66 90                	xchg   %ax,%ax

801049a0 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
801049a0:	55                   	push   %ebp
801049a1:	89 e5                	mov    %esp,%ebp
801049a3:	57                   	push   %edi
801049a4:	8b 55 08             	mov    0x8(%ebp),%edx
801049a7:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
801049aa:	89 d0                	mov    %edx,%eax
801049ac:	09 c8                	or     %ecx,%eax
801049ae:	a8 03                	test   $0x3,%al
801049b0:	75 1e                	jne    801049d0 <memset+0x30>
    c &= 0xFF;
801049b2:	0f b6 45 0c          	movzbl 0xc(%ebp),%eax
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
801049b6:	c1 e9 02             	shr    $0x2,%ecx
  asm volatile("cld; rep stosl" :
801049b9:	89 d7                	mov    %edx,%edi
801049bb:	69 c0 01 01 01 01    	imul   $0x1010101,%eax,%eax
801049c1:	fc                   	cld
801049c2:	f3 ab                	rep stos %eax,%es:(%edi)
  } else
    stosb(dst, c, n);
  return dst;
}
801049c4:	8b 7d fc             	mov    -0x4(%ebp),%edi
801049c7:	89 d0                	mov    %edx,%eax
801049c9:	c9                   	leave
801049ca:	c3                   	ret
801049cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  asm volatile("cld; rep stosb" :
801049d0:	8b 45 0c             	mov    0xc(%ebp),%eax
801049d3:	89 d7                	mov    %edx,%edi
801049d5:	fc                   	cld
801049d6:	f3 aa                	rep stos %al,%es:(%edi)
801049d8:	8b 7d fc             	mov    -0x4(%ebp),%edi
801049db:	89 d0                	mov    %edx,%eax
801049dd:	c9                   	leave
801049de:	c3                   	ret
801049df:	90                   	nop

801049e0 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
801049e0:	55                   	push   %ebp
801049e1:	89 e5                	mov    %esp,%ebp
801049e3:	56                   	push   %esi
801049e4:	8b 75 10             	mov    0x10(%ebp),%esi
801049e7:	8b 45 08             	mov    0x8(%ebp),%eax
801049ea:	53                   	push   %ebx
801049eb:	8b 55 0c             	mov    0xc(%ebp),%edx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
801049ee:	85 f6                	test   %esi,%esi
801049f0:	74 2e                	je     80104a20 <memcmp+0x40>
801049f2:	01 c6                	add    %eax,%esi
801049f4:	eb 14                	jmp    80104a0a <memcmp+0x2a>
801049f6:	66 90                	xchg   %ax,%ax
801049f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801049ff:	00 
    if(*s1 != *s2)
      return *s1 - *s2;
    s1++, s2++;
80104a00:	83 c0 01             	add    $0x1,%eax
80104a03:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0){
80104a06:	39 f0                	cmp    %esi,%eax
80104a08:	74 16                	je     80104a20 <memcmp+0x40>
    if(*s1 != *s2)
80104a0a:	0f b6 08             	movzbl (%eax),%ecx
80104a0d:	0f b6 1a             	movzbl (%edx),%ebx
80104a10:	38 d9                	cmp    %bl,%cl
80104a12:	74 ec                	je     80104a00 <memcmp+0x20>
      return *s1 - *s2;
80104a14:	0f b6 c1             	movzbl %cl,%eax
80104a17:	29 d8                	sub    %ebx,%eax
  }

  return 0;
}
80104a19:	5b                   	pop    %ebx
80104a1a:	5e                   	pop    %esi
80104a1b:	5d                   	pop    %ebp
80104a1c:	c3                   	ret
80104a1d:	8d 76 00             	lea    0x0(%esi),%esi
80104a20:	5b                   	pop    %ebx
  return 0;
80104a21:	31 c0                	xor    %eax,%eax
}
80104a23:	5e                   	pop    %esi
80104a24:	5d                   	pop    %ebp
80104a25:	c3                   	ret
80104a26:	66 90                	xchg   %ax,%ax
80104a28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a2f:	00 

80104a30 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80104a30:	55                   	push   %ebp
80104a31:	89 e5                	mov    %esp,%ebp
80104a33:	57                   	push   %edi
80104a34:	8b 55 08             	mov    0x8(%ebp),%edx
80104a37:	8b 45 10             	mov    0x10(%ebp),%eax
80104a3a:	56                   	push   %esi
80104a3b:	8b 75 0c             	mov    0xc(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
80104a3e:	39 d6                	cmp    %edx,%esi
80104a40:	73 26                	jae    80104a68 <memmove+0x38>
80104a42:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
80104a45:	39 ca                	cmp    %ecx,%edx
80104a47:	73 1f                	jae    80104a68 <memmove+0x38>
    s += n;
    d += n;
    while(n-- > 0)
80104a49:	85 c0                	test   %eax,%eax
80104a4b:	74 0f                	je     80104a5c <memmove+0x2c>
80104a4d:	83 e8 01             	sub    $0x1,%eax
      *--d = *--s;
80104a50:	0f b6 0c 06          	movzbl (%esi,%eax,1),%ecx
80104a54:	88 0c 02             	mov    %cl,(%edx,%eax,1)
    while(n-- > 0)
80104a57:	83 e8 01             	sub    $0x1,%eax
80104a5a:	73 f4                	jae    80104a50 <memmove+0x20>
  } else
    while(n-- > 0)
      *d++ = *s++;

  return dst;
}
80104a5c:	5e                   	pop    %esi
80104a5d:	89 d0                	mov    %edx,%eax
80104a5f:	5f                   	pop    %edi
80104a60:	5d                   	pop    %ebp
80104a61:	c3                   	ret
80104a62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    while(n-- > 0)
80104a68:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
80104a6b:	89 d7                	mov    %edx,%edi
80104a6d:	85 c0                	test   %eax,%eax
80104a6f:	74 eb                	je     80104a5c <memmove+0x2c>
80104a71:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104a78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a7f:	00 
      *d++ = *s++;
80104a80:	a4                   	movsb  %ds:(%esi),%es:(%edi)
    while(n-- > 0)
80104a81:	39 f1                	cmp    %esi,%ecx
80104a83:	75 fb                	jne    80104a80 <memmove+0x50>
}
80104a85:	5e                   	pop    %esi
80104a86:	89 d0                	mov    %edx,%eax
80104a88:	5f                   	pop    %edi
80104a89:	5d                   	pop    %ebp
80104a8a:	c3                   	ret
80104a8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104a90 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
80104a90:	eb 9e                	jmp    80104a30 <memmove>
80104a92:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104a98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a9f:	00 

80104aa0 <strncmp>:
}

int
strncmp(const char *p, const char *q, uint n)
{
80104aa0:	55                   	push   %ebp
80104aa1:	89 e5                	mov    %esp,%ebp
80104aa3:	53                   	push   %ebx
80104aa4:	8b 55 10             	mov    0x10(%ebp),%edx
80104aa7:	8b 45 08             	mov    0x8(%ebp),%eax
80104aaa:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(n > 0 && *p && *p == *q)
80104aad:	85 d2                	test   %edx,%edx
80104aaf:	75 16                	jne    80104ac7 <strncmp+0x27>
80104ab1:	eb 2d                	jmp    80104ae0 <strncmp+0x40>
80104ab3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104ab8:	3a 19                	cmp    (%ecx),%bl
80104aba:	75 12                	jne    80104ace <strncmp+0x2e>
    n--, p++, q++;
80104abc:	83 c0 01             	add    $0x1,%eax
80104abf:	83 c1 01             	add    $0x1,%ecx
  while(n > 0 && *p && *p == *q)
80104ac2:	83 ea 01             	sub    $0x1,%edx
80104ac5:	74 19                	je     80104ae0 <strncmp+0x40>
80104ac7:	0f b6 18             	movzbl (%eax),%ebx
80104aca:	84 db                	test   %bl,%bl
80104acc:	75 ea                	jne    80104ab8 <strncmp+0x18>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
80104ace:	0f b6 00             	movzbl (%eax),%eax
80104ad1:	0f b6 11             	movzbl (%ecx),%edx
}
80104ad4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ad7:	c9                   	leave
  return (uchar)*p - (uchar)*q;
80104ad8:	29 d0                	sub    %edx,%eax
}
80104ada:	c3                   	ret
80104adb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104ae0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80104ae3:	31 c0                	xor    %eax,%eax
}
80104ae5:	c9                   	leave
80104ae6:	c3                   	ret
80104ae7:	90                   	nop
80104ae8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104aef:	00 

80104af0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80104af0:	55                   	push   %ebp
80104af1:	89 e5                	mov    %esp,%ebp
80104af3:	53                   	push   %ebx
80104af4:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80104af7:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
80104afa:	8b 45 08             	mov    0x8(%ebp),%eax
80104afd:	eb 14                	jmp    80104b13 <strncpy+0x23>
80104aff:	90                   	nop
80104b00:	0f b6 19             	movzbl (%ecx),%ebx
80104b03:	83 c1 01             	add    $0x1,%ecx
80104b06:	83 c0 01             	add    $0x1,%eax
80104b09:	88 58 ff             	mov    %bl,-0x1(%eax)
80104b0c:	84 db                	test   %bl,%bl
80104b0e:	74 10                	je     80104b20 <strncpy+0x30>
80104b10:	83 ea 01             	sub    $0x1,%edx
80104b13:	85 d2                	test   %edx,%edx
80104b15:	7f e9                	jg     80104b00 <strncpy+0x10>
    ;
  while(n-- > 0)
    *s++ = 0;
  return os;
}
80104b17:	8b 45 08             	mov    0x8(%ebp),%eax
80104b1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104b1d:	c9                   	leave
80104b1e:	c3                   	ret
80104b1f:	90                   	nop
  while(n-- > 0)
80104b20:	8d 4c 10 ff          	lea    -0x1(%eax,%edx,1),%ecx
80104b24:	83 ea 01             	sub    $0x1,%edx
80104b27:	74 ee                	je     80104b17 <strncpy+0x27>
80104b29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    *s++ = 0;
80104b30:	83 c0 01             	add    $0x1,%eax
80104b33:	89 ca                	mov    %ecx,%edx
80104b35:	c6 40 ff 00          	movb   $0x0,-0x1(%eax)
  while(n-- > 0)
80104b39:	29 c2                	sub    %eax,%edx
80104b3b:	85 d2                	test   %edx,%edx
80104b3d:	7f f1                	jg     80104b30 <strncpy+0x40>
}
80104b3f:	8b 45 08             	mov    0x8(%ebp),%eax
80104b42:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104b45:	c9                   	leave
80104b46:	c3                   	ret
80104b47:	90                   	nop
80104b48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b4f:	00 

80104b50 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
80104b50:	55                   	push   %ebp
80104b51:	89 e5                	mov    %esp,%ebp
80104b53:	53                   	push   %ebx
80104b54:	8b 55 10             	mov    0x10(%ebp),%edx
80104b57:	8b 45 0c             	mov    0xc(%ebp),%eax
  char *os;

  os = s;
  if(n <= 0)
80104b5a:	85 d2                	test   %edx,%edx
80104b5c:	7e 39                	jle    80104b97 <safestrcpy+0x47>
80104b5e:	8d 5c 10 ff          	lea    -0x1(%eax,%edx,1),%ebx
80104b62:	8b 55 08             	mov    0x8(%ebp),%edx
80104b65:	eb 29                	jmp    80104b90 <safestrcpy+0x40>
80104b67:	eb 17                	jmp    80104b80 <safestrcpy+0x30>
80104b69:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104b70:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b77:	00 
80104b78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b7f:	00 
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
80104b80:	0f b6 08             	movzbl (%eax),%ecx
80104b83:	83 c0 01             	add    $0x1,%eax
80104b86:	83 c2 01             	add    $0x1,%edx
80104b89:	88 4a ff             	mov    %cl,-0x1(%edx)
80104b8c:	84 c9                	test   %cl,%cl
80104b8e:	74 04                	je     80104b94 <safestrcpy+0x44>
80104b90:	39 d8                	cmp    %ebx,%eax
80104b92:	75 ec                	jne    80104b80 <safestrcpy+0x30>
    ;
  *s = 0;
80104b94:	c6 02 00             	movb   $0x0,(%edx)
  return os;
}
80104b97:	8b 45 08             	mov    0x8(%ebp),%eax
80104b9a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104b9d:	c9                   	leave
80104b9e:	c3                   	ret
80104b9f:	90                   	nop

80104ba0 <strlen>:

int
strlen(const char *s)
{
80104ba0:	55                   	push   %ebp
  int n;

  for(n = 0; s[n]; n++)
80104ba1:	31 c0                	xor    %eax,%eax
{
80104ba3:	89 e5                	mov    %esp,%ebp
80104ba5:	8b 55 08             	mov    0x8(%ebp),%edx
  for(n = 0; s[n]; n++)
80104ba8:	80 3a 00             	cmpb   $0x0,(%edx)
80104bab:	74 0c                	je     80104bb9 <strlen+0x19>
80104bad:	8d 76 00             	lea    0x0(%esi),%esi
80104bb0:	83 c0 01             	add    $0x1,%eax
80104bb3:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
80104bb7:	75 f7                	jne    80104bb0 <strlen+0x10>
    ;
  return n;
}
80104bb9:	5d                   	pop    %ebp
80104bba:	c3                   	ret

80104bbb <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
80104bbb:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
80104bbf:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80104bc3:	55                   	push   %ebp
  pushl %ebx
80104bc4:	53                   	push   %ebx
  pushl %esi
80104bc5:	56                   	push   %esi
  pushl %edi
80104bc6:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
80104bc7:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
80104bc9:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
80104bcb:	5f                   	pop    %edi
  popl %esi
80104bcc:	5e                   	pop    %esi
  popl %ebx
80104bcd:	5b                   	pop    %ebx
  popl %ebp
80104bce:	5d                   	pop    %ebp
  ret
80104bcf:	c3                   	ret

80104bd0 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80104bd0:	55                   	push   %ebp
80104bd1:	89 e5                	mov    %esp,%ebp
80104bd3:	53                   	push   %ebx
80104bd4:	83 ec 04             	sub    $0x4,%esp
80104bd7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
80104bda:	e8 01 f0 ff ff       	call   80103be0 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104bdf:	8b 00                	mov    (%eax),%eax
80104be1:	39 c3                	cmp    %eax,%ebx
80104be3:	73 1b                	jae    80104c00 <fetchint+0x30>
80104be5:	8d 53 04             	lea    0x4(%ebx),%edx
80104be8:	39 d0                	cmp    %edx,%eax
80104bea:	72 14                	jb     80104c00 <fetchint+0x30>
    return -1;
  *ip = *(int*)(addr);
80104bec:	8b 45 0c             	mov    0xc(%ebp),%eax
80104bef:	8b 13                	mov    (%ebx),%edx
80104bf1:	89 10                	mov    %edx,(%eax)
  return 0;
80104bf3:	31 c0                	xor    %eax,%eax
}
80104bf5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104bf8:	c9                   	leave
80104bf9:	c3                   	ret
80104bfa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80104c00:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104c05:	eb ee                	jmp    80104bf5 <fetchint+0x25>
80104c07:	90                   	nop
80104c08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c0f:	00 

80104c10 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80104c10:	55                   	push   %ebp
80104c11:	89 e5                	mov    %esp,%ebp
80104c13:	53                   	push   %ebx
80104c14:	83 ec 04             	sub    $0x4,%esp
80104c17:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
80104c1a:	e8 c1 ef ff ff       	call   80103be0 <myproc>

  if(addr >= curproc->sz)
80104c1f:	3b 18                	cmp    (%eax),%ebx
80104c21:	73 35                	jae    80104c58 <fetchstr+0x48>
    return -1;
  *pp = (char*)addr;
80104c23:	8b 55 0c             	mov    0xc(%ebp),%edx
80104c26:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104c28:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104c2a:	39 d3                	cmp    %edx,%ebx
80104c2c:	73 2a                	jae    80104c58 <fetchstr+0x48>
80104c2e:	89 d8                	mov    %ebx,%eax
80104c30:	eb 15                	jmp    80104c47 <fetchstr+0x37>
80104c32:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104c38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c3f:	00 
80104c40:	83 c0 01             	add    $0x1,%eax
80104c43:	39 d0                	cmp    %edx,%eax
80104c45:	73 11                	jae    80104c58 <fetchstr+0x48>
    if(*s == 0)
80104c47:	80 38 00             	cmpb   $0x0,(%eax)
80104c4a:	75 f4                	jne    80104c40 <fetchstr+0x30>
      return s - *pp;
80104c4c:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
80104c4e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104c51:	c9                   	leave
80104c52:	c3                   	ret
80104c53:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c58:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
80104c5b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104c60:	c9                   	leave
80104c61:	c3                   	ret
80104c62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104c68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c6f:	00 

80104c70 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104c70:	55                   	push   %ebp
80104c71:	89 e5                	mov    %esp,%ebp
80104c73:	56                   	push   %esi
80104c74:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104c75:	e8 66 ef ff ff       	call   80103be0 <myproc>
80104c7a:	8b 55 08             	mov    0x8(%ebp),%edx
80104c7d:	8b 40 18             	mov    0x18(%eax),%eax
80104c80:	8b 40 44             	mov    0x44(%eax),%eax
80104c83:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104c86:	e8 55 ef ff ff       	call   80103be0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104c8b:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104c8e:	8b 00                	mov    (%eax),%eax
80104c90:	39 c6                	cmp    %eax,%esi
80104c92:	73 1c                	jae    80104cb0 <argint+0x40>
80104c94:	8d 53 08             	lea    0x8(%ebx),%edx
80104c97:	39 d0                	cmp    %edx,%eax
80104c99:	72 15                	jb     80104cb0 <argint+0x40>
  *ip = *(int*)(addr);
80104c9b:	8b 45 0c             	mov    0xc(%ebp),%eax
80104c9e:	8b 53 04             	mov    0x4(%ebx),%edx
80104ca1:	89 10                	mov    %edx,(%eax)
  return 0;
80104ca3:	31 c0                	xor    %eax,%eax
}
80104ca5:	5b                   	pop    %ebx
80104ca6:	5e                   	pop    %esi
80104ca7:	5d                   	pop    %ebp
80104ca8:	c3                   	ret
80104ca9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80104cb0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104cb5:	eb ee                	jmp    80104ca5 <argint+0x35>
80104cb7:	90                   	nop
80104cb8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104cbf:	00 

80104cc0 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes. Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80104cc0:	55                   	push   %ebp
80104cc1:	89 e5                	mov    %esp,%ebp
80104cc3:	57                   	push   %edi
80104cc4:	56                   	push   %esi
80104cc5:	53                   	push   %ebx
80104cc6:	83 ec 0c             	sub    $0xc,%esp
  int i;
  struct proc *curproc = myproc();
80104cc9:	e8 12 ef ff ff       	call   80103be0 <myproc>
80104cce:	89 c6                	mov    %eax,%esi
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104cd0:	e8 0b ef ff ff       	call   80103be0 <myproc>
80104cd5:	8b 55 08             	mov    0x8(%ebp),%edx
80104cd8:	8b 40 18             	mov    0x18(%eax),%eax
80104cdb:	8b 40 44             	mov    0x44(%eax),%eax
80104cde:	8d 3c 90             	lea    (%eax,%edx,4),%edi
  struct proc *curproc = myproc();
80104ce1:	e8 fa ee ff ff       	call   80103be0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104ce6:	8d 5f 04             	lea    0x4(%edi),%ebx
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104ce9:	8b 00                	mov    (%eax),%eax
80104ceb:	39 c3                	cmp    %eax,%ebx
80104ced:	73 31                	jae    80104d20 <argptr+0x60>
80104cef:	8d 57 08             	lea    0x8(%edi),%edx
80104cf2:	39 d0                	cmp    %edx,%eax
80104cf4:	72 2a                	jb     80104d20 <argptr+0x60>

  if(argint(n, &i) < 0)
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104cf6:	8b 45 10             	mov    0x10(%ebp),%eax
80104cf9:	85 c0                	test   %eax,%eax
80104cfb:	78 23                	js     80104d20 <argptr+0x60>
  *ip = *(int*)(addr);
80104cfd:	8b 57 04             	mov    0x4(%edi),%edx
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104d00:	8b 0e                	mov    (%esi),%ecx
80104d02:	39 ca                	cmp    %ecx,%edx
80104d04:	73 1a                	jae    80104d20 <argptr+0x60>
80104d06:	8b 45 10             	mov    0x10(%ebp),%eax
80104d09:	01 d0                	add    %edx,%eax
80104d0b:	39 c1                	cmp    %eax,%ecx
80104d0d:	72 11                	jb     80104d20 <argptr+0x60>
    return -1;
  *pp = (char*)i;
80104d0f:	8b 45 0c             	mov    0xc(%ebp),%eax
80104d12:	89 10                	mov    %edx,(%eax)
  return 0;
80104d14:	31 c0                	xor    %eax,%eax
}
80104d16:	83 c4 0c             	add    $0xc,%esp
80104d19:	5b                   	pop    %ebx
80104d1a:	5e                   	pop    %esi
80104d1b:	5f                   	pop    %edi
80104d1c:	5d                   	pop    %ebp
80104d1d:	c3                   	ret
80104d1e:	66 90                	xchg   %ax,%ax
    return -1;
80104d20:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d25:	eb ef                	jmp    80104d16 <argptr+0x56>
80104d27:	90                   	nop
80104d28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d2f:	00 

80104d30 <argstr>:

// Fetch the nth word-sized system call argument as a string pointer.
// Check that the pointer is valid and the string is nul-terminated.
int
argstr(int n, char **pp)
{
80104d30:	55                   	push   %ebp
80104d31:	89 e5                	mov    %esp,%ebp
80104d33:	56                   	push   %esi
80104d34:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104d35:	e8 a6 ee ff ff       	call   80103be0 <myproc>
80104d3a:	8b 55 08             	mov    0x8(%ebp),%edx
80104d3d:	8b 40 18             	mov    0x18(%eax),%eax
80104d40:	8b 40 44             	mov    0x44(%eax),%eax
80104d43:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104d46:	e8 95 ee ff ff       	call   80103be0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104d4b:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104d4e:	8b 00                	mov    (%eax),%eax
80104d50:	39 c6                	cmp    %eax,%esi
80104d52:	73 44                	jae    80104d98 <argstr+0x68>
80104d54:	8d 53 08             	lea    0x8(%ebx),%edx
80104d57:	39 d0                	cmp    %edx,%eax
80104d59:	72 3d                	jb     80104d98 <argstr+0x68>
  *ip = *(int*)(addr);
80104d5b:	8b 5b 04             	mov    0x4(%ebx),%ebx
  struct proc *curproc = myproc();
80104d5e:	e8 7d ee ff ff       	call   80103be0 <myproc>
  if(addr >= curproc->sz)
80104d63:	3b 18                	cmp    (%eax),%ebx
80104d65:	73 31                	jae    80104d98 <argstr+0x68>
  *pp = (char*)addr;
80104d67:	8b 55 0c             	mov    0xc(%ebp),%edx
80104d6a:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104d6c:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104d6e:	39 d3                	cmp    %edx,%ebx
80104d70:	73 26                	jae    80104d98 <argstr+0x68>
80104d72:	89 d8                	mov    %ebx,%eax
80104d74:	eb 11                	jmp    80104d87 <argstr+0x57>
80104d76:	66 90                	xchg   %ax,%ax
80104d78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104d7f:	00 
80104d80:	83 c0 01             	add    $0x1,%eax
80104d83:	39 d0                	cmp    %edx,%eax
80104d85:	73 11                	jae    80104d98 <argstr+0x68>
    if(*s == 0)
80104d87:	80 38 00             	cmpb   $0x0,(%eax)
80104d8a:	75 f4                	jne    80104d80 <argstr+0x50>
      return s - *pp;
80104d8c:	29 d8                	sub    %ebx,%eax
  int addr;
  if(argint(n, &addr) < 0)
    return -1;
  return fetchstr(addr, pp);
}
80104d8e:	5b                   	pop    %ebx
80104d8f:	5e                   	pop    %esi
80104d90:	5d                   	pop    %ebp
80104d91:	c3                   	ret
80104d92:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104d98:	5b                   	pop    %ebx
    return -1;
80104d99:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104d9e:	5e                   	pop    %esi
80104d9f:	5d                   	pop    %ebp
80104da0:	c3                   	ret
80104da1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80104da8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104daf:	00 

80104db0 <syscall>:
[SYS_va2pa]     sys_va2pa,
};

void
syscall(void)
{
80104db0:	55                   	push   %ebp
80104db1:	89 e5                	mov    %esp,%ebp
80104db3:	53                   	push   %ebx
80104db4:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
80104db7:	e8 24 ee ff ff       	call   80103be0 <myproc>
80104dbc:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
80104dbe:	8b 40 18             	mov    0x18(%eax),%eax
80104dc1:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80104dc4:	8d 50 ff             	lea    -0x1(%eax),%edx
80104dc7:	83 fa 16             	cmp    $0x16,%edx
80104dca:	77 24                	ja     80104df0 <syscall+0x40>
80104dcc:	8b 14 85 80 7e 10 80 	mov    -0x7fef8180(,%eax,4),%edx
80104dd3:	85 d2                	test   %edx,%edx
80104dd5:	74 19                	je     80104df0 <syscall+0x40>
    curproc->tf->eax = syscalls[num]();
80104dd7:	ff d2                	call   *%edx
80104dd9:	89 c2                	mov    %eax,%edx
80104ddb:	8b 43 18             	mov    0x18(%ebx),%eax
80104dde:	89 50 1c             	mov    %edx,0x1c(%eax)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
80104de1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104de4:	c9                   	leave
80104de5:	c3                   	ret
80104de6:	66 90                	xchg   %ax,%ax
80104de8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104def:	00 
    cprintf("%d %s: unknown sys call %d\n",
80104df0:	50                   	push   %eax
            curproc->pid, curproc->name, num);
80104df1:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
80104df4:	50                   	push   %eax
80104df5:	ff 73 10             	push   0x10(%ebx)
80104df8:	68 11 79 10 80       	push   $0x80107911
80104dfd:	e8 ce b8 ff ff       	call   801006d0 <cprintf>
    curproc->tf->eax = -1;
80104e02:	8b 43 18             	mov    0x18(%ebx),%eax
80104e05:	83 c4 10             	add    $0x10,%esp
80104e08:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
}
80104e0f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104e12:	c9                   	leave
80104e13:	c3                   	ret
80104e14:	66 90                	xchg   %ax,%ax
80104e16:	66 90                	xchg   %ax,%ax
80104e18:	66 90                	xchg   %ax,%ax
80104e1a:	66 90                	xchg   %ax,%ax
80104e1c:	66 90                	xchg   %ax,%ax
80104e1e:	66 90                	xchg   %ax,%ax

80104e20 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80104e20:	55                   	push   %ebp
80104e21:	89 e5                	mov    %esp,%ebp
80104e23:	57                   	push   %edi
80104e24:	56                   	push   %esi
80104e25:	53                   	push   %ebx
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80104e26:	8d 5d da             	lea    -0x26(%ebp),%ebx
{
80104e29:	83 ec 34             	sub    $0x34,%esp
80104e2c:	89 4d cc             	mov    %ecx,-0x34(%ebp)
80104e2f:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104e32:	89 55 d4             	mov    %edx,-0x2c(%ebp)
80104e35:	89 4d d0             	mov    %ecx,-0x30(%ebp)
  if((dp = nameiparent(path, name)) == 0)
80104e38:	53                   	push   %ebx
80104e39:	50                   	push   %eax
80104e3a:	e8 71 d3 ff ff       	call   801021b0 <nameiparent>
80104e3f:	83 c4 10             	add    $0x10,%esp
80104e42:	85 c0                	test   %eax,%eax
80104e44:	74 5e                	je     80104ea4 <create+0x84>
    return 0;
  ilock(dp);
80104e46:	83 ec 0c             	sub    $0xc,%esp
80104e49:	89 c6                	mov    %eax,%esi
80104e4b:	50                   	push   %eax
80104e4c:	e8 1f ca ff ff       	call   80101870 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
80104e51:	83 c4 0c             	add    $0xc,%esp
80104e54:	6a 00                	push   $0x0
80104e56:	53                   	push   %ebx
80104e57:	56                   	push   %esi
80104e58:	e8 73 cf ff ff       	call   80101dd0 <dirlookup>
80104e5d:	83 c4 10             	add    $0x10,%esp
80104e60:	89 c7                	mov    %eax,%edi
80104e62:	85 c0                	test   %eax,%eax
80104e64:	74 4a                	je     80104eb0 <create+0x90>
    iunlockput(dp);
80104e66:	83 ec 0c             	sub    $0xc,%esp
80104e69:	56                   	push   %esi
80104e6a:	e8 a1 cc ff ff       	call   80101b10 <iunlockput>
    ilock(ip);
80104e6f:	89 3c 24             	mov    %edi,(%esp)
80104e72:	e8 f9 c9 ff ff       	call   80101870 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
80104e77:	83 c4 10             	add    $0x10,%esp
80104e7a:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
80104e7f:	75 17                	jne    80104e98 <create+0x78>
80104e81:	66 83 7f 50 02       	cmpw   $0x2,0x50(%edi)
80104e86:	75 10                	jne    80104e98 <create+0x78>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
80104e88:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104e8b:	89 f8                	mov    %edi,%eax
80104e8d:	5b                   	pop    %ebx
80104e8e:	5e                   	pop    %esi
80104e8f:	5f                   	pop    %edi
80104e90:	5d                   	pop    %ebp
80104e91:	c3                   	ret
80104e92:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(ip);
80104e98:	83 ec 0c             	sub    $0xc,%esp
80104e9b:	57                   	push   %edi
80104e9c:	e8 6f cc ff ff       	call   80101b10 <iunlockput>
    return 0;
80104ea1:	83 c4 10             	add    $0x10,%esp
}
80104ea4:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return 0;
80104ea7:	31 ff                	xor    %edi,%edi
}
80104ea9:	5b                   	pop    %ebx
80104eaa:	89 f8                	mov    %edi,%eax
80104eac:	5e                   	pop    %esi
80104ead:	5f                   	pop    %edi
80104eae:	5d                   	pop    %ebp
80104eaf:	c3                   	ret
  if((ip = ialloc(dp->dev, type)) == 0)
80104eb0:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
80104eb4:	83 ec 08             	sub    $0x8,%esp
80104eb7:	50                   	push   %eax
80104eb8:	ff 36                	push   (%esi)
80104eba:	e8 31 c8 ff ff       	call   801016f0 <ialloc>
80104ebf:	83 c4 10             	add    $0x10,%esp
80104ec2:	89 c7                	mov    %eax,%edi
80104ec4:	85 c0                	test   %eax,%eax
80104ec6:	0f 84 af 00 00 00    	je     80104f7b <create+0x15b>
  ilock(ip);
80104ecc:	83 ec 0c             	sub    $0xc,%esp
80104ecf:	50                   	push   %eax
80104ed0:	e8 9b c9 ff ff       	call   80101870 <ilock>
  ip->major = major;
80104ed5:	0f b7 45 cc          	movzwl -0x34(%ebp),%eax
80104ed9:	66 89 47 52          	mov    %ax,0x52(%edi)
  ip->minor = minor;
80104edd:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
80104ee1:	66 89 47 54          	mov    %ax,0x54(%edi)
  ip->nlink = 1;
80104ee5:	b8 01 00 00 00       	mov    $0x1,%eax
80104eea:	66 89 47 56          	mov    %ax,0x56(%edi)
  iupdate(ip);
80104eee:	89 3c 24             	mov    %edi,(%esp)
80104ef1:	e8 ba c8 ff ff       	call   801017b0 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80104ef6:	83 c4 10             	add    $0x10,%esp
80104ef9:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
80104efe:	74 30                	je     80104f30 <create+0x110>
  if(dirlink(dp, name, ip->inum) < 0)
80104f00:	83 ec 04             	sub    $0x4,%esp
80104f03:	ff 77 04             	push   0x4(%edi)
80104f06:	53                   	push   %ebx
80104f07:	56                   	push   %esi
80104f08:	e8 c3 d1 ff ff       	call   801020d0 <dirlink>
80104f0d:	83 c4 10             	add    $0x10,%esp
80104f10:	85 c0                	test   %eax,%eax
80104f12:	78 74                	js     80104f88 <create+0x168>
  iunlockput(dp);
80104f14:	83 ec 0c             	sub    $0xc,%esp
80104f17:	56                   	push   %esi
80104f18:	e8 f3 cb ff ff       	call   80101b10 <iunlockput>
  return ip;
80104f1d:	83 c4 10             	add    $0x10,%esp
}
80104f20:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104f23:	89 f8                	mov    %edi,%eax
80104f25:	5b                   	pop    %ebx
80104f26:	5e                   	pop    %esi
80104f27:	5f                   	pop    %edi
80104f28:	5d                   	pop    %ebp
80104f29:	c3                   	ret
80104f2a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iupdate(dp);
80104f30:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink++;  // for ".."
80104f33:	66 83 46 56 01       	addw   $0x1,0x56(%esi)
    iupdate(dp);
80104f38:	56                   	push   %esi
80104f39:	e8 72 c8 ff ff       	call   801017b0 <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
80104f3e:	83 c4 0c             	add    $0xc,%esp
80104f41:	ff 77 04             	push   0x4(%edi)
80104f44:	68 49 79 10 80       	push   $0x80107949
80104f49:	57                   	push   %edi
80104f4a:	e8 81 d1 ff ff       	call   801020d0 <dirlink>
80104f4f:	83 c4 10             	add    $0x10,%esp
80104f52:	85 c0                	test   %eax,%eax
80104f54:	78 18                	js     80104f6e <create+0x14e>
80104f56:	83 ec 04             	sub    $0x4,%esp
80104f59:	ff 76 04             	push   0x4(%esi)
80104f5c:	68 48 79 10 80       	push   $0x80107948
80104f61:	57                   	push   %edi
80104f62:	e8 69 d1 ff ff       	call   801020d0 <dirlink>
80104f67:	83 c4 10             	add    $0x10,%esp
80104f6a:	85 c0                	test   %eax,%eax
80104f6c:	79 92                	jns    80104f00 <create+0xe0>
      panic("create dots");
80104f6e:	83 ec 0c             	sub    $0xc,%esp
80104f71:	68 3c 79 10 80       	push   $0x8010793c
80104f76:	e8 25 b4 ff ff       	call   801003a0 <panic>
    panic("create: ialloc");
80104f7b:	83 ec 0c             	sub    $0xc,%esp
80104f7e:	68 2d 79 10 80       	push   $0x8010792d
80104f83:	e8 18 b4 ff ff       	call   801003a0 <panic>
    panic("create: dirlink");
80104f88:	83 ec 0c             	sub    $0xc,%esp
80104f8b:	68 4b 79 10 80       	push   $0x8010794b
80104f90:	e8 0b b4 ff ff       	call   801003a0 <panic>
80104f95:	8d 76 00             	lea    0x0(%esi),%esi
80104f98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104f9f:	00 

80104fa0 <sys_dup>:
{
80104fa0:	55                   	push   %ebp
80104fa1:	89 e5                	mov    %esp,%ebp
80104fa3:	56                   	push   %esi
80104fa4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104fa5:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80104fa8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104fab:	50                   	push   %eax
80104fac:	6a 00                	push   $0x0
80104fae:	e8 bd fc ff ff       	call   80104c70 <argint>
80104fb3:	83 c4 10             	add    $0x10,%esp
80104fb6:	85 c0                	test   %eax,%eax
80104fb8:	78 36                	js     80104ff0 <sys_dup+0x50>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104fba:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104fbe:	77 30                	ja     80104ff0 <sys_dup+0x50>
80104fc0:	e8 1b ec ff ff       	call   80103be0 <myproc>
80104fc5:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104fc8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80104fcc:	85 f6                	test   %esi,%esi
80104fce:	74 20                	je     80104ff0 <sys_dup+0x50>
  struct proc *curproc = myproc();
80104fd0:	e8 0b ec ff ff       	call   80103be0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
80104fd5:	31 db                	xor    %ebx,%ebx
80104fd7:	90                   	nop
80104fd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104fdf:	00 
    if(curproc->ofile[fd] == 0){
80104fe0:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80104fe4:	85 d2                	test   %edx,%edx
80104fe6:	74 18                	je     80105000 <sys_dup+0x60>
  for(fd = 0; fd < NOFILE; fd++){
80104fe8:	83 c3 01             	add    $0x1,%ebx
80104feb:	83 fb 10             	cmp    $0x10,%ebx
80104fee:	75 f0                	jne    80104fe0 <sys_dup+0x40>
    return -1;
80104ff0:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104ff5:	eb 19                	jmp    80105010 <sys_dup+0x70>
80104ff7:	90                   	nop
80104ff8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104fff:	00 
  filedup(f);
80105000:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80105003:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  filedup(f);
80105007:	56                   	push   %esi
80105008:	e8 23 bf ff ff       	call   80100f30 <filedup>
  return fd;
8010500d:	83 c4 10             	add    $0x10,%esp
}
80105010:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105013:	89 d8                	mov    %ebx,%eax
80105015:	5b                   	pop    %ebx
80105016:	5e                   	pop    %esi
80105017:	5d                   	pop    %ebp
80105018:	c3                   	ret
80105019:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80105020 <sys_read>:
{
80105020:	55                   	push   %ebp
80105021:	89 e5                	mov    %esp,%ebp
80105023:	56                   	push   %esi
80105024:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105025:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80105028:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010502b:	53                   	push   %ebx
8010502c:	6a 00                	push   $0x0
8010502e:	e8 3d fc ff ff       	call   80104c70 <argint>
80105033:	83 c4 10             	add    $0x10,%esp
80105036:	85 c0                	test   %eax,%eax
80105038:	78 5e                	js     80105098 <sys_read+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010503a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010503e:	77 58                	ja     80105098 <sys_read+0x78>
80105040:	e8 9b eb ff ff       	call   80103be0 <myproc>
80105045:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105048:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
8010504c:	85 f6                	test   %esi,%esi
8010504e:	74 48                	je     80105098 <sys_read+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80105050:	83 ec 08             	sub    $0x8,%esp
80105053:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105056:	50                   	push   %eax
80105057:	6a 02                	push   $0x2
80105059:	e8 12 fc ff ff       	call   80104c70 <argint>
8010505e:	83 c4 10             	add    $0x10,%esp
80105061:	85 c0                	test   %eax,%eax
80105063:	78 33                	js     80105098 <sys_read+0x78>
80105065:	83 ec 04             	sub    $0x4,%esp
80105068:	ff 75 f0             	push   -0x10(%ebp)
8010506b:	53                   	push   %ebx
8010506c:	6a 01                	push   $0x1
8010506e:	e8 4d fc ff ff       	call   80104cc0 <argptr>
80105073:	83 c4 10             	add    $0x10,%esp
80105076:	85 c0                	test   %eax,%eax
80105078:	78 1e                	js     80105098 <sys_read+0x78>
  return fileread(f, p, n);
8010507a:	83 ec 04             	sub    $0x4,%esp
8010507d:	ff 75 f0             	push   -0x10(%ebp)
80105080:	ff 75 f4             	push   -0xc(%ebp)
80105083:	56                   	push   %esi
80105084:	e8 27 c0 ff ff       	call   801010b0 <fileread>
80105089:	83 c4 10             	add    $0x10,%esp
}
8010508c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010508f:	5b                   	pop    %ebx
80105090:	5e                   	pop    %esi
80105091:	5d                   	pop    %ebp
80105092:	c3                   	ret
80105093:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105098:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010509d:	eb ed                	jmp    8010508c <sys_read+0x6c>
8010509f:	90                   	nop

801050a0 <sys_write>:
{
801050a0:	55                   	push   %ebp
801050a1:	89 e5                	mov    %esp,%ebp
801050a3:	56                   	push   %esi
801050a4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
801050a5:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
801050a8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
801050ab:	53                   	push   %ebx
801050ac:	6a 00                	push   $0x0
801050ae:	e8 bd fb ff ff       	call   80104c70 <argint>
801050b3:	83 c4 10             	add    $0x10,%esp
801050b6:	85 c0                	test   %eax,%eax
801050b8:	78 5e                	js     80105118 <sys_write+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801050ba:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801050be:	77 58                	ja     80105118 <sys_write+0x78>
801050c0:	e8 1b eb ff ff       	call   80103be0 <myproc>
801050c5:	8b 55 f4             	mov    -0xc(%ebp),%edx
801050c8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801050cc:	85 f6                	test   %esi,%esi
801050ce:	74 48                	je     80105118 <sys_write+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801050d0:	83 ec 08             	sub    $0x8,%esp
801050d3:	8d 45 f0             	lea    -0x10(%ebp),%eax
801050d6:	50                   	push   %eax
801050d7:	6a 02                	push   $0x2
801050d9:	e8 92 fb ff ff       	call   80104c70 <argint>
801050de:	83 c4 10             	add    $0x10,%esp
801050e1:	85 c0                	test   %eax,%eax
801050e3:	78 33                	js     80105118 <sys_write+0x78>
801050e5:	83 ec 04             	sub    $0x4,%esp
801050e8:	ff 75 f0             	push   -0x10(%ebp)
801050eb:	53                   	push   %ebx
801050ec:	6a 01                	push   $0x1
801050ee:	e8 cd fb ff ff       	call   80104cc0 <argptr>
801050f3:	83 c4 10             	add    $0x10,%esp
801050f6:	85 c0                	test   %eax,%eax
801050f8:	78 1e                	js     80105118 <sys_write+0x78>
  return filewrite(f, p, n);
801050fa:	83 ec 04             	sub    $0x4,%esp
801050fd:	ff 75 f0             	push   -0x10(%ebp)
80105100:	ff 75 f4             	push   -0xc(%ebp)
80105103:	56                   	push   %esi
80105104:	e8 37 c0 ff ff       	call   80101140 <filewrite>
80105109:	83 c4 10             	add    $0x10,%esp
}
8010510c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010510f:	5b                   	pop    %ebx
80105110:	5e                   	pop    %esi
80105111:	5d                   	pop    %ebp
80105112:	c3                   	ret
80105113:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105118:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010511d:	eb ed                	jmp    8010510c <sys_write+0x6c>
8010511f:	90                   	nop

80105120 <sys_close>:
{
80105120:	55                   	push   %ebp
80105121:	89 e5                	mov    %esp,%ebp
80105123:	56                   	push   %esi
80105124:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105125:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105128:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010512b:	50                   	push   %eax
8010512c:	6a 00                	push   $0x0
8010512e:	e8 3d fb ff ff       	call   80104c70 <argint>
80105133:	83 c4 10             	add    $0x10,%esp
80105136:	85 c0                	test   %eax,%eax
80105138:	78 3e                	js     80105178 <sys_close+0x58>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010513a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010513e:	77 38                	ja     80105178 <sys_close+0x58>
80105140:	e8 9b ea ff ff       	call   80103be0 <myproc>
80105145:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105148:	8d 5a 08             	lea    0x8(%edx),%ebx
8010514b:	8b 74 98 08          	mov    0x8(%eax,%ebx,4),%esi
8010514f:	85 f6                	test   %esi,%esi
80105151:	74 25                	je     80105178 <sys_close+0x58>
  myproc()->ofile[fd] = 0;
80105153:	e8 88 ea ff ff       	call   80103be0 <myproc>
  fileclose(f);
80105158:	83 ec 0c             	sub    $0xc,%esp
  myproc()->ofile[fd] = 0;
8010515b:	c7 44 98 08 00 00 00 	movl   $0x0,0x8(%eax,%ebx,4)
80105162:	00 
  fileclose(f);
80105163:	56                   	push   %esi
80105164:	e8 17 be ff ff       	call   80100f80 <fileclose>
  return 0;
80105169:	83 c4 10             	add    $0x10,%esp
8010516c:	31 c0                	xor    %eax,%eax
}
8010516e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105171:	5b                   	pop    %ebx
80105172:	5e                   	pop    %esi
80105173:	5d                   	pop    %ebp
80105174:	c3                   	ret
80105175:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105178:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010517d:	eb ef                	jmp    8010516e <sys_close+0x4e>
8010517f:	90                   	nop

80105180 <sys_fstat>:
{
80105180:	55                   	push   %ebp
80105181:	89 e5                	mov    %esp,%ebp
80105183:	56                   	push   %esi
80105184:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105185:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80105188:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010518b:	53                   	push   %ebx
8010518c:	6a 00                	push   $0x0
8010518e:	e8 dd fa ff ff       	call   80104c70 <argint>
80105193:	83 c4 10             	add    $0x10,%esp
80105196:	85 c0                	test   %eax,%eax
80105198:	78 46                	js     801051e0 <sys_fstat+0x60>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010519a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010519e:	77 40                	ja     801051e0 <sys_fstat+0x60>
801051a0:	e8 3b ea ff ff       	call   80103be0 <myproc>
801051a5:	8b 55 f4             	mov    -0xc(%ebp),%edx
801051a8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801051ac:	85 f6                	test   %esi,%esi
801051ae:	74 30                	je     801051e0 <sys_fstat+0x60>
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
801051b0:	83 ec 04             	sub    $0x4,%esp
801051b3:	6a 14                	push   $0x14
801051b5:	53                   	push   %ebx
801051b6:	6a 01                	push   $0x1
801051b8:	e8 03 fb ff ff       	call   80104cc0 <argptr>
801051bd:	83 c4 10             	add    $0x10,%esp
801051c0:	85 c0                	test   %eax,%eax
801051c2:	78 1c                	js     801051e0 <sys_fstat+0x60>
  return filestat(f, st);
801051c4:	83 ec 08             	sub    $0x8,%esp
801051c7:	ff 75 f4             	push   -0xc(%ebp)
801051ca:	56                   	push   %esi
801051cb:	e8 90 be ff ff       	call   80101060 <filestat>
801051d0:	83 c4 10             	add    $0x10,%esp
}
801051d3:	8d 65 f8             	lea    -0x8(%ebp),%esp
801051d6:	5b                   	pop    %ebx
801051d7:	5e                   	pop    %esi
801051d8:	5d                   	pop    %ebp
801051d9:	c3                   	ret
801051da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
801051e0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801051e5:	eb ec                	jmp    801051d3 <sys_fstat+0x53>
801051e7:	90                   	nop
801051e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801051ef:	00 

801051f0 <sys_link>:
{
801051f0:	55                   	push   %ebp
801051f1:	89 e5                	mov    %esp,%ebp
801051f3:	57                   	push   %edi
801051f4:	56                   	push   %esi
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
801051f5:	8d 45 d4             	lea    -0x2c(%ebp),%eax
{
801051f8:	53                   	push   %ebx
801051f9:	83 ec 34             	sub    $0x34,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
801051fc:	50                   	push   %eax
801051fd:	6a 00                	push   $0x0
801051ff:	e8 2c fb ff ff       	call   80104d30 <argstr>
80105204:	83 c4 10             	add    $0x10,%esp
80105207:	85 c0                	test   %eax,%eax
80105209:	0f 88 fb 00 00 00    	js     8010530a <sys_link+0x11a>
8010520f:	83 ec 08             	sub    $0x8,%esp
80105212:	8d 45 d0             	lea    -0x30(%ebp),%eax
80105215:	50                   	push   %eax
80105216:	6a 01                	push   $0x1
80105218:	e8 13 fb ff ff       	call   80104d30 <argstr>
8010521d:	83 c4 10             	add    $0x10,%esp
80105220:	85 c0                	test   %eax,%eax
80105222:	0f 88 e2 00 00 00    	js     8010530a <sys_link+0x11a>
  begin_op();
80105228:	e8 33 dd ff ff       	call   80102f60 <begin_op>
  if((ip = namei(old)) == 0){
8010522d:	83 ec 0c             	sub    $0xc,%esp
80105230:	ff 75 d4             	push   -0x2c(%ebp)
80105233:	e8 58 cf ff ff       	call   80102190 <namei>
80105238:	83 c4 10             	add    $0x10,%esp
8010523b:	89 c3                	mov    %eax,%ebx
8010523d:	85 c0                	test   %eax,%eax
8010523f:	0f 84 df 00 00 00    	je     80105324 <sys_link+0x134>
  ilock(ip);
80105245:	83 ec 0c             	sub    $0xc,%esp
80105248:	50                   	push   %eax
80105249:	e8 22 c6 ff ff       	call   80101870 <ilock>
  if(ip->type == T_DIR){
8010524e:	83 c4 10             	add    $0x10,%esp
80105251:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105256:	0f 84 b5 00 00 00    	je     80105311 <sys_link+0x121>
  iupdate(ip);
8010525c:	83 ec 0c             	sub    $0xc,%esp
  ip->nlink++;
8010525f:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  if((dp = nameiparent(new, name)) == 0)
80105264:	8d 7d da             	lea    -0x26(%ebp),%edi
  iupdate(ip);
80105267:	53                   	push   %ebx
80105268:	e8 43 c5 ff ff       	call   801017b0 <iupdate>
  iunlock(ip);
8010526d:	89 1c 24             	mov    %ebx,(%esp)
80105270:	e8 db c6 ff ff       	call   80101950 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
80105275:	58                   	pop    %eax
80105276:	5a                   	pop    %edx
80105277:	57                   	push   %edi
80105278:	ff 75 d0             	push   -0x30(%ebp)
8010527b:	e8 30 cf ff ff       	call   801021b0 <nameiparent>
80105280:	83 c4 10             	add    $0x10,%esp
80105283:	89 c6                	mov    %eax,%esi
80105285:	85 c0                	test   %eax,%eax
80105287:	74 5b                	je     801052e4 <sys_link+0xf4>
  ilock(dp);
80105289:	83 ec 0c             	sub    $0xc,%esp
8010528c:	50                   	push   %eax
8010528d:	e8 de c5 ff ff       	call   80101870 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
80105292:	8b 03                	mov    (%ebx),%eax
80105294:	83 c4 10             	add    $0x10,%esp
80105297:	39 06                	cmp    %eax,(%esi)
80105299:	75 3d                	jne    801052d8 <sys_link+0xe8>
8010529b:	83 ec 04             	sub    $0x4,%esp
8010529e:	ff 73 04             	push   0x4(%ebx)
801052a1:	57                   	push   %edi
801052a2:	56                   	push   %esi
801052a3:	e8 28 ce ff ff       	call   801020d0 <dirlink>
801052a8:	83 c4 10             	add    $0x10,%esp
801052ab:	85 c0                	test   %eax,%eax
801052ad:	78 29                	js     801052d8 <sys_link+0xe8>
  iunlockput(dp);
801052af:	83 ec 0c             	sub    $0xc,%esp
801052b2:	56                   	push   %esi
801052b3:	e8 58 c8 ff ff       	call   80101b10 <iunlockput>
  iput(ip);
801052b8:	89 1c 24             	mov    %ebx,(%esp)
801052bb:	e8 e0 c6 ff ff       	call   801019a0 <iput>
  end_op();
801052c0:	e8 0b dd ff ff       	call   80102fd0 <end_op>
  return 0;
801052c5:	83 c4 10             	add    $0x10,%esp
801052c8:	31 c0                	xor    %eax,%eax
}
801052ca:	8d 65 f4             	lea    -0xc(%ebp),%esp
801052cd:	5b                   	pop    %ebx
801052ce:	5e                   	pop    %esi
801052cf:	5f                   	pop    %edi
801052d0:	5d                   	pop    %ebp
801052d1:	c3                   	ret
801052d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(dp);
801052d8:	83 ec 0c             	sub    $0xc,%esp
801052db:	56                   	push   %esi
801052dc:	e8 2f c8 ff ff       	call   80101b10 <iunlockput>
    goto bad;
801052e1:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
801052e4:	83 ec 0c             	sub    $0xc,%esp
801052e7:	53                   	push   %ebx
801052e8:	e8 83 c5 ff ff       	call   80101870 <ilock>
  ip->nlink--;
801052ed:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
801052f2:	89 1c 24             	mov    %ebx,(%esp)
801052f5:	e8 b6 c4 ff ff       	call   801017b0 <iupdate>
  iunlockput(ip);
801052fa:	89 1c 24             	mov    %ebx,(%esp)
801052fd:	e8 0e c8 ff ff       	call   80101b10 <iunlockput>
  end_op();
80105302:	e8 c9 dc ff ff       	call   80102fd0 <end_op>
  return -1;
80105307:	83 c4 10             	add    $0x10,%esp
    return -1;
8010530a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010530f:	eb b9                	jmp    801052ca <sys_link+0xda>
    iunlockput(ip);
80105311:	83 ec 0c             	sub    $0xc,%esp
80105314:	53                   	push   %ebx
80105315:	e8 f6 c7 ff ff       	call   80101b10 <iunlockput>
    end_op();
8010531a:	e8 b1 dc ff ff       	call   80102fd0 <end_op>
    return -1;
8010531f:	83 c4 10             	add    $0x10,%esp
80105322:	eb e6                	jmp    8010530a <sys_link+0x11a>
    end_op();
80105324:	e8 a7 dc ff ff       	call   80102fd0 <end_op>
    return -1;
80105329:	eb df                	jmp    8010530a <sys_link+0x11a>
8010532b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105330 <sys_unlink>:
{
80105330:	55                   	push   %ebp
80105331:	89 e5                	mov    %esp,%ebp
80105333:	57                   	push   %edi
80105334:	56                   	push   %esi
  if(argstr(0, &path) < 0)
80105335:	8d 45 c0             	lea    -0x40(%ebp),%eax
{
80105338:	53                   	push   %ebx
80105339:	83 ec 54             	sub    $0x54,%esp
  if(argstr(0, &path) < 0)
8010533c:	50                   	push   %eax
8010533d:	6a 00                	push   $0x0
8010533f:	e8 ec f9 ff ff       	call   80104d30 <argstr>
80105344:	83 c4 10             	add    $0x10,%esp
80105347:	85 c0                	test   %eax,%eax
80105349:	0f 88 54 01 00 00    	js     801054a3 <sys_unlink+0x173>
  begin_op();
8010534f:	e8 0c dc ff ff       	call   80102f60 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80105354:	8d 5d ca             	lea    -0x36(%ebp),%ebx
80105357:	83 ec 08             	sub    $0x8,%esp
8010535a:	53                   	push   %ebx
8010535b:	ff 75 c0             	push   -0x40(%ebp)
8010535e:	e8 4d ce ff ff       	call   801021b0 <nameiparent>
80105363:	83 c4 10             	add    $0x10,%esp
80105366:	89 45 b4             	mov    %eax,-0x4c(%ebp)
80105369:	85 c0                	test   %eax,%eax
8010536b:	0f 84 58 01 00 00    	je     801054c9 <sys_unlink+0x199>
  ilock(dp);
80105371:	8b 7d b4             	mov    -0x4c(%ebp),%edi
80105374:	83 ec 0c             	sub    $0xc,%esp
80105377:	57                   	push   %edi
80105378:	e8 f3 c4 ff ff       	call   80101870 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
8010537d:	58                   	pop    %eax
8010537e:	5a                   	pop    %edx
8010537f:	68 49 79 10 80       	push   $0x80107949
80105384:	53                   	push   %ebx
80105385:	e8 26 ca ff ff       	call   80101db0 <namecmp>
8010538a:	83 c4 10             	add    $0x10,%esp
8010538d:	85 c0                	test   %eax,%eax
8010538f:	0f 84 fb 00 00 00    	je     80105490 <sys_unlink+0x160>
80105395:	83 ec 08             	sub    $0x8,%esp
80105398:	68 48 79 10 80       	push   $0x80107948
8010539d:	53                   	push   %ebx
8010539e:	e8 0d ca ff ff       	call   80101db0 <namecmp>
801053a3:	83 c4 10             	add    $0x10,%esp
801053a6:	85 c0                	test   %eax,%eax
801053a8:	0f 84 e2 00 00 00    	je     80105490 <sys_unlink+0x160>
  if((ip = dirlookup(dp, name, &off)) == 0)
801053ae:	83 ec 04             	sub    $0x4,%esp
801053b1:	8d 45 c4             	lea    -0x3c(%ebp),%eax
801053b4:	50                   	push   %eax
801053b5:	53                   	push   %ebx
801053b6:	57                   	push   %edi
801053b7:	e8 14 ca ff ff       	call   80101dd0 <dirlookup>
801053bc:	83 c4 10             	add    $0x10,%esp
801053bf:	89 c3                	mov    %eax,%ebx
801053c1:	85 c0                	test   %eax,%eax
801053c3:	0f 84 c7 00 00 00    	je     80105490 <sys_unlink+0x160>
  ilock(ip);
801053c9:	83 ec 0c             	sub    $0xc,%esp
801053cc:	50                   	push   %eax
801053cd:	e8 9e c4 ff ff       	call   80101870 <ilock>
  if(ip->nlink < 1)
801053d2:	83 c4 10             	add    $0x10,%esp
801053d5:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
801053da:	0f 8e fd 00 00 00    	jle    801054dd <sys_unlink+0x1ad>
  if(ip->type == T_DIR && !isdirempty(ip)){
801053e0:	8d 7d d8             	lea    -0x28(%ebp),%edi
801053e3:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
801053e8:	74 66                	je     80105450 <sys_unlink+0x120>
  memset(&de, 0, sizeof(de));
801053ea:	83 ec 04             	sub    $0x4,%esp
801053ed:	6a 10                	push   $0x10
801053ef:	6a 00                	push   $0x0
801053f1:	57                   	push   %edi
801053f2:	e8 a9 f5 ff ff       	call   801049a0 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801053f7:	6a 10                	push   $0x10
801053f9:	ff 75 c4             	push   -0x3c(%ebp)
801053fc:	57                   	push   %edi
801053fd:	ff 75 b4             	push   -0x4c(%ebp)
80105400:	e8 8b c8 ff ff       	call   80101c90 <writei>
80105405:	83 c4 20             	add    $0x20,%esp
80105408:	83 f8 10             	cmp    $0x10,%eax
8010540b:	0f 85 d9 00 00 00    	jne    801054ea <sys_unlink+0x1ba>
  if(ip->type == T_DIR){
80105411:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105416:	0f 84 94 00 00 00    	je     801054b0 <sys_unlink+0x180>
  iunlockput(dp);
8010541c:	83 ec 0c             	sub    $0xc,%esp
8010541f:	ff 75 b4             	push   -0x4c(%ebp)
80105422:	e8 e9 c6 ff ff       	call   80101b10 <iunlockput>
  ip->nlink--;
80105427:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010542c:	89 1c 24             	mov    %ebx,(%esp)
8010542f:	e8 7c c3 ff ff       	call   801017b0 <iupdate>
  iunlockput(ip);
80105434:	89 1c 24             	mov    %ebx,(%esp)
80105437:	e8 d4 c6 ff ff       	call   80101b10 <iunlockput>
  end_op();
8010543c:	e8 8f db ff ff       	call   80102fd0 <end_op>
  return 0;
80105441:	83 c4 10             	add    $0x10,%esp
80105444:	31 c0                	xor    %eax,%eax
}
80105446:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105449:	5b                   	pop    %ebx
8010544a:	5e                   	pop    %esi
8010544b:	5f                   	pop    %edi
8010544c:	5d                   	pop    %ebp
8010544d:	c3                   	ret
8010544e:	66 90                	xchg   %ax,%ax
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105450:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
80105454:	76 94                	jbe    801053ea <sys_unlink+0xba>
80105456:	be 20 00 00 00       	mov    $0x20,%esi
8010545b:	eb 0b                	jmp    80105468 <sys_unlink+0x138>
8010545d:	8d 76 00             	lea    0x0(%esi),%esi
80105460:	83 c6 10             	add    $0x10,%esi
80105463:	3b 73 58             	cmp    0x58(%ebx),%esi
80105466:	73 82                	jae    801053ea <sys_unlink+0xba>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105468:	6a 10                	push   $0x10
8010546a:	56                   	push   %esi
8010546b:	57                   	push   %edi
8010546c:	53                   	push   %ebx
8010546d:	e8 1e c7 ff ff       	call   80101b90 <readi>
80105472:	83 c4 10             	add    $0x10,%esp
80105475:	83 f8 10             	cmp    $0x10,%eax
80105478:	75 56                	jne    801054d0 <sys_unlink+0x1a0>
    if(de.inum != 0)
8010547a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
8010547f:	74 df                	je     80105460 <sys_unlink+0x130>
    iunlockput(ip);
80105481:	83 ec 0c             	sub    $0xc,%esp
80105484:	53                   	push   %ebx
80105485:	e8 86 c6 ff ff       	call   80101b10 <iunlockput>
    goto bad;
8010548a:	83 c4 10             	add    $0x10,%esp
8010548d:	8d 76 00             	lea    0x0(%esi),%esi
  iunlockput(dp);
80105490:	83 ec 0c             	sub    $0xc,%esp
80105493:	ff 75 b4             	push   -0x4c(%ebp)
80105496:	e8 75 c6 ff ff       	call   80101b10 <iunlockput>
  end_op();
8010549b:	e8 30 db ff ff       	call   80102fd0 <end_op>
  return -1;
801054a0:	83 c4 10             	add    $0x10,%esp
    return -1;
801054a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801054a8:	eb 9c                	jmp    80105446 <sys_unlink+0x116>
801054aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    dp->nlink--;
801054b0:	8b 45 b4             	mov    -0x4c(%ebp),%eax
    iupdate(dp);
801054b3:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink--;
801054b6:	66 83 68 56 01       	subw   $0x1,0x56(%eax)
    iupdate(dp);
801054bb:	50                   	push   %eax
801054bc:	e8 ef c2 ff ff       	call   801017b0 <iupdate>
801054c1:	83 c4 10             	add    $0x10,%esp
801054c4:	e9 53 ff ff ff       	jmp    8010541c <sys_unlink+0xec>
    end_op();
801054c9:	e8 02 db ff ff       	call   80102fd0 <end_op>
    return -1;
801054ce:	eb d3                	jmp    801054a3 <sys_unlink+0x173>
      panic("isdirempty: readi");
801054d0:	83 ec 0c             	sub    $0xc,%esp
801054d3:	68 6d 79 10 80       	push   $0x8010796d
801054d8:	e8 c3 ae ff ff       	call   801003a0 <panic>
    panic("unlink: nlink < 1");
801054dd:	83 ec 0c             	sub    $0xc,%esp
801054e0:	68 5b 79 10 80       	push   $0x8010795b
801054e5:	e8 b6 ae ff ff       	call   801003a0 <panic>
    panic("unlink: writei");
801054ea:	83 ec 0c             	sub    $0xc,%esp
801054ed:	68 7f 79 10 80       	push   $0x8010797f
801054f2:	e8 a9 ae ff ff       	call   801003a0 <panic>
801054f7:	90                   	nop
801054f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801054ff:	00 

80105500 <sys_open>:

int
sys_open(void)
{
80105500:	55                   	push   %ebp
80105501:	89 e5                	mov    %esp,%ebp
80105503:	57                   	push   %edi
80105504:	56                   	push   %esi
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105505:	8d 45 e0             	lea    -0x20(%ebp),%eax
{
80105508:	53                   	push   %ebx
80105509:	83 ec 24             	sub    $0x24,%esp
  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
8010550c:	50                   	push   %eax
8010550d:	6a 00                	push   $0x0
8010550f:	e8 1c f8 ff ff       	call   80104d30 <argstr>
80105514:	83 c4 10             	add    $0x10,%esp
80105517:	85 c0                	test   %eax,%eax
80105519:	0f 88 8e 00 00 00    	js     801055ad <sys_open+0xad>
8010551f:	83 ec 08             	sub    $0x8,%esp
80105522:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105525:	50                   	push   %eax
80105526:	6a 01                	push   $0x1
80105528:	e8 43 f7 ff ff       	call   80104c70 <argint>
8010552d:	83 c4 10             	add    $0x10,%esp
80105530:	85 c0                	test   %eax,%eax
80105532:	78 79                	js     801055ad <sys_open+0xad>
    return -1;

  begin_op();
80105534:	e8 27 da ff ff       	call   80102f60 <begin_op>

  if(omode & O_CREATE){
    ip = create(path, T_FILE, 0, 0);
80105539:	8b 45 e0             	mov    -0x20(%ebp),%eax
  if(omode & O_CREATE){
8010553c:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
80105540:	75 76                	jne    801055b8 <sys_open+0xb8>
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
80105542:	83 ec 0c             	sub    $0xc,%esp
80105545:	50                   	push   %eax
80105546:	e8 45 cc ff ff       	call   80102190 <namei>
8010554b:	83 c4 10             	add    $0x10,%esp
8010554e:	89 c7                	mov    %eax,%edi
80105550:	85 c0                	test   %eax,%eax
80105552:	74 7e                	je     801055d2 <sys_open+0xd2>
      end_op();
      return -1;
    }
    ilock(ip);
80105554:	83 ec 0c             	sub    $0xc,%esp
80105557:	50                   	push   %eax
80105558:	e8 13 c3 ff ff       	call   80101870 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
8010555d:	83 c4 10             	add    $0x10,%esp
80105560:	66 83 7f 50 01       	cmpw   $0x1,0x50(%edi)
80105565:	0f 84 bd 00 00 00    	je     80105628 <sys_open+0x128>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
8010556b:	e8 50 b9 ff ff       	call   80100ec0 <filealloc>
80105570:	89 c6                	mov    %eax,%esi
80105572:	85 c0                	test   %eax,%eax
80105574:	74 26                	je     8010559c <sys_open+0x9c>
  struct proc *curproc = myproc();
80105576:	e8 65 e6 ff ff       	call   80103be0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
8010557b:	31 db                	xor    %ebx,%ebx
8010557d:	8d 76 00             	lea    0x0(%esi),%esi
    if(curproc->ofile[fd] == 0){
80105580:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105584:	85 d2                	test   %edx,%edx
80105586:	74 58                	je     801055e0 <sys_open+0xe0>
  for(fd = 0; fd < NOFILE; fd++){
80105588:	83 c3 01             	add    $0x1,%ebx
8010558b:	83 fb 10             	cmp    $0x10,%ebx
8010558e:	75 f0                	jne    80105580 <sys_open+0x80>
    if(f)
      fileclose(f);
80105590:	83 ec 0c             	sub    $0xc,%esp
80105593:	56                   	push   %esi
80105594:	e8 e7 b9 ff ff       	call   80100f80 <fileclose>
80105599:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
8010559c:	83 ec 0c             	sub    $0xc,%esp
8010559f:	57                   	push   %edi
801055a0:	e8 6b c5 ff ff       	call   80101b10 <iunlockput>
    end_op();
801055a5:	e8 26 da ff ff       	call   80102fd0 <end_op>
    return -1;
801055aa:	83 c4 10             	add    $0x10,%esp
    return -1;
801055ad:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801055b2:	eb 65                	jmp    80105619 <sys_open+0x119>
801055b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    ip = create(path, T_FILE, 0, 0);
801055b8:	83 ec 0c             	sub    $0xc,%esp
801055bb:	31 c9                	xor    %ecx,%ecx
801055bd:	ba 02 00 00 00       	mov    $0x2,%edx
801055c2:	6a 00                	push   $0x0
801055c4:	e8 57 f8 ff ff       	call   80104e20 <create>
    if(ip == 0){
801055c9:	83 c4 10             	add    $0x10,%esp
    ip = create(path, T_FILE, 0, 0);
801055cc:	89 c7                	mov    %eax,%edi
    if(ip == 0){
801055ce:	85 c0                	test   %eax,%eax
801055d0:	75 99                	jne    8010556b <sys_open+0x6b>
      end_op();
801055d2:	e8 f9 d9 ff ff       	call   80102fd0 <end_op>
      return -1;
801055d7:	eb d4                	jmp    801055ad <sys_open+0xad>
801055d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  }
  iunlock(ip);
801055e0:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
801055e3:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  iunlock(ip);
801055e7:	57                   	push   %edi
801055e8:	e8 63 c3 ff ff       	call   80101950 <iunlock>
  end_op();
801055ed:	e8 de d9 ff ff       	call   80102fd0 <end_op>

  f->type = FD_INODE;
801055f2:	c7 06 02 00 00 00    	movl   $0x2,(%esi)
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
801055f8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
801055fb:	83 c4 10             	add    $0x10,%esp
  f->ip = ip;
801055fe:	89 7e 10             	mov    %edi,0x10(%esi)
  f->readable = !(omode & O_WRONLY);
80105601:	89 d0                	mov    %edx,%eax
  f->off = 0;
80105603:	c7 46 14 00 00 00 00 	movl   $0x0,0x14(%esi)
  f->readable = !(omode & O_WRONLY);
8010560a:	f7 d0                	not    %eax
8010560c:	83 e0 01             	and    $0x1,%eax
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
8010560f:	83 e2 03             	and    $0x3,%edx
  f->readable = !(omode & O_WRONLY);
80105612:	88 46 08             	mov    %al,0x8(%esi)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105615:	0f 95 46 09          	setne  0x9(%esi)
  return fd;
}
80105619:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010561c:	89 d8                	mov    %ebx,%eax
8010561e:	5b                   	pop    %ebx
8010561f:	5e                   	pop    %esi
80105620:	5f                   	pop    %edi
80105621:	5d                   	pop    %ebp
80105622:	c3                   	ret
80105623:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(ip->type == T_DIR && omode != O_RDONLY){
80105628:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010562b:	85 c9                	test   %ecx,%ecx
8010562d:	0f 84 38 ff ff ff    	je     8010556b <sys_open+0x6b>
80105633:	e9 64 ff ff ff       	jmp    8010559c <sys_open+0x9c>
80105638:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010563f:	00 

80105640 <sys_mkdir>:

int
sys_mkdir(void)
{
80105640:	55                   	push   %ebp
80105641:	89 e5                	mov    %esp,%ebp
80105643:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80105646:	e8 15 d9 ff ff       	call   80102f60 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
8010564b:	83 ec 08             	sub    $0x8,%esp
8010564e:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105651:	50                   	push   %eax
80105652:	6a 00                	push   $0x0
80105654:	e8 d7 f6 ff ff       	call   80104d30 <argstr>
80105659:	83 c4 10             	add    $0x10,%esp
8010565c:	85 c0                	test   %eax,%eax
8010565e:	78 30                	js     80105690 <sys_mkdir+0x50>
80105660:	83 ec 0c             	sub    $0xc,%esp
80105663:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105666:	31 c9                	xor    %ecx,%ecx
80105668:	ba 01 00 00 00       	mov    $0x1,%edx
8010566d:	6a 00                	push   $0x0
8010566f:	e8 ac f7 ff ff       	call   80104e20 <create>
80105674:	83 c4 10             	add    $0x10,%esp
80105677:	85 c0                	test   %eax,%eax
80105679:	74 15                	je     80105690 <sys_mkdir+0x50>
    end_op();
    return -1;
  }
  iunlockput(ip);
8010567b:	83 ec 0c             	sub    $0xc,%esp
8010567e:	50                   	push   %eax
8010567f:	e8 8c c4 ff ff       	call   80101b10 <iunlockput>
  end_op();
80105684:	e8 47 d9 ff ff       	call   80102fd0 <end_op>
  return 0;
80105689:	83 c4 10             	add    $0x10,%esp
8010568c:	31 c0                	xor    %eax,%eax
}
8010568e:	c9                   	leave
8010568f:	c3                   	ret
    end_op();
80105690:	e8 3b d9 ff ff       	call   80102fd0 <end_op>
    return -1;
80105695:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010569a:	c9                   	leave
8010569b:	c3                   	ret
8010569c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801056a0 <sys_mknod>:

int
sys_mknod(void)
{
801056a0:	55                   	push   %ebp
801056a1:	89 e5                	mov    %esp,%ebp
801056a3:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
801056a6:	e8 b5 d8 ff ff       	call   80102f60 <begin_op>
  if((argstr(0, &path)) < 0 ||
801056ab:	83 ec 08             	sub    $0x8,%esp
801056ae:	8d 45 ec             	lea    -0x14(%ebp),%eax
801056b1:	50                   	push   %eax
801056b2:	6a 00                	push   $0x0
801056b4:	e8 77 f6 ff ff       	call   80104d30 <argstr>
801056b9:	83 c4 10             	add    $0x10,%esp
801056bc:	85 c0                	test   %eax,%eax
801056be:	78 60                	js     80105720 <sys_mknod+0x80>
     argint(1, &major) < 0 ||
801056c0:	83 ec 08             	sub    $0x8,%esp
801056c3:	8d 45 f0             	lea    -0x10(%ebp),%eax
801056c6:	50                   	push   %eax
801056c7:	6a 01                	push   $0x1
801056c9:	e8 a2 f5 ff ff       	call   80104c70 <argint>
  if((argstr(0, &path)) < 0 ||
801056ce:	83 c4 10             	add    $0x10,%esp
801056d1:	85 c0                	test   %eax,%eax
801056d3:	78 4b                	js     80105720 <sys_mknod+0x80>
     argint(2, &minor) < 0 ||
801056d5:	83 ec 08             	sub    $0x8,%esp
801056d8:	8d 45 f4             	lea    -0xc(%ebp),%eax
801056db:	50                   	push   %eax
801056dc:	6a 02                	push   $0x2
801056de:	e8 8d f5 ff ff       	call   80104c70 <argint>
     argint(1, &major) < 0 ||
801056e3:	83 c4 10             	add    $0x10,%esp
801056e6:	85 c0                	test   %eax,%eax
801056e8:	78 36                	js     80105720 <sys_mknod+0x80>
     (ip = create(path, T_DEV, major, minor)) == 0){
801056ea:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
801056ee:	83 ec 0c             	sub    $0xc,%esp
801056f1:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
801056f5:	ba 03 00 00 00       	mov    $0x3,%edx
801056fa:	50                   	push   %eax
801056fb:	8b 45 ec             	mov    -0x14(%ebp),%eax
801056fe:	e8 1d f7 ff ff       	call   80104e20 <create>
     argint(2, &minor) < 0 ||
80105703:	83 c4 10             	add    $0x10,%esp
80105706:	85 c0                	test   %eax,%eax
80105708:	74 16                	je     80105720 <sys_mknod+0x80>
    end_op();
    return -1;
  }
  iunlockput(ip);
8010570a:	83 ec 0c             	sub    $0xc,%esp
8010570d:	50                   	push   %eax
8010570e:	e8 fd c3 ff ff       	call   80101b10 <iunlockput>
  end_op();
80105713:	e8 b8 d8 ff ff       	call   80102fd0 <end_op>
  return 0;
80105718:	83 c4 10             	add    $0x10,%esp
8010571b:	31 c0                	xor    %eax,%eax
}
8010571d:	c9                   	leave
8010571e:	c3                   	ret
8010571f:	90                   	nop
    end_op();
80105720:	e8 ab d8 ff ff       	call   80102fd0 <end_op>
    return -1;
80105725:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010572a:	c9                   	leave
8010572b:	c3                   	ret
8010572c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105730 <sys_chdir>:

int
sys_chdir(void)
{
80105730:	55                   	push   %ebp
80105731:	89 e5                	mov    %esp,%ebp
80105733:	56                   	push   %esi
80105734:	53                   	push   %ebx
80105735:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
80105738:	e8 a3 e4 ff ff       	call   80103be0 <myproc>
8010573d:	89 c6                	mov    %eax,%esi
  
  begin_op();
8010573f:	e8 1c d8 ff ff       	call   80102f60 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
80105744:	83 ec 08             	sub    $0x8,%esp
80105747:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010574a:	50                   	push   %eax
8010574b:	6a 00                	push   $0x0
8010574d:	e8 de f5 ff ff       	call   80104d30 <argstr>
80105752:	83 c4 10             	add    $0x10,%esp
80105755:	85 c0                	test   %eax,%eax
80105757:	78 77                	js     801057d0 <sys_chdir+0xa0>
80105759:	83 ec 0c             	sub    $0xc,%esp
8010575c:	ff 75 f4             	push   -0xc(%ebp)
8010575f:	e8 2c ca ff ff       	call   80102190 <namei>
80105764:	83 c4 10             	add    $0x10,%esp
80105767:	89 c3                	mov    %eax,%ebx
80105769:	85 c0                	test   %eax,%eax
8010576b:	74 63                	je     801057d0 <sys_chdir+0xa0>
    end_op();
    return -1;
  }
  ilock(ip);
8010576d:	83 ec 0c             	sub    $0xc,%esp
80105770:	50                   	push   %eax
80105771:	e8 fa c0 ff ff       	call   80101870 <ilock>
  if(ip->type != T_DIR){
80105776:	83 c4 10             	add    $0x10,%esp
80105779:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
8010577e:	75 30                	jne    801057b0 <sys_chdir+0x80>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80105780:	83 ec 0c             	sub    $0xc,%esp
80105783:	53                   	push   %ebx
80105784:	e8 c7 c1 ff ff       	call   80101950 <iunlock>
  iput(curproc->cwd);
80105789:	58                   	pop    %eax
8010578a:	ff 76 68             	push   0x68(%esi)
8010578d:	e8 0e c2 ff ff       	call   801019a0 <iput>
  end_op();
80105792:	e8 39 d8 ff ff       	call   80102fd0 <end_op>
  curproc->cwd = ip;
80105797:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
8010579a:	83 c4 10             	add    $0x10,%esp
8010579d:	31 c0                	xor    %eax,%eax
}
8010579f:	8d 65 f8             	lea    -0x8(%ebp),%esp
801057a2:	5b                   	pop    %ebx
801057a3:	5e                   	pop    %esi
801057a4:	5d                   	pop    %ebp
801057a5:	c3                   	ret
801057a6:	66 90                	xchg   %ax,%ax
801057a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801057af:	00 
    iunlockput(ip);
801057b0:	83 ec 0c             	sub    $0xc,%esp
801057b3:	53                   	push   %ebx
801057b4:	e8 57 c3 ff ff       	call   80101b10 <iunlockput>
    end_op();
801057b9:	e8 12 d8 ff ff       	call   80102fd0 <end_op>
    return -1;
801057be:	83 c4 10             	add    $0x10,%esp
    return -1;
801057c1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057c6:	eb d7                	jmp    8010579f <sys_chdir+0x6f>
801057c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801057cf:	00 
    end_op();
801057d0:	e8 fb d7 ff ff       	call   80102fd0 <end_op>
    return -1;
801057d5:	eb ea                	jmp    801057c1 <sys_chdir+0x91>
801057d7:	90                   	nop
801057d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801057df:	00 

801057e0 <sys_exec>:

int
sys_exec(void)
{
801057e0:	55                   	push   %ebp
801057e1:	89 e5                	mov    %esp,%ebp
801057e3:	57                   	push   %edi
801057e4:	56                   	push   %esi
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
801057e5:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
{
801057eb:	53                   	push   %ebx
801057ec:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
801057f2:	50                   	push   %eax
801057f3:	6a 00                	push   $0x0
801057f5:	e8 36 f5 ff ff       	call   80104d30 <argstr>
801057fa:	83 c4 10             	add    $0x10,%esp
801057fd:	85 c0                	test   %eax,%eax
801057ff:	0f 88 85 00 00 00    	js     8010588a <sys_exec+0xaa>
80105805:	83 ec 08             	sub    $0x8,%esp
80105808:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
8010580e:	50                   	push   %eax
8010580f:	6a 01                	push   $0x1
80105811:	e8 5a f4 ff ff       	call   80104c70 <argint>
80105816:	83 c4 10             	add    $0x10,%esp
80105819:	85 c0                	test   %eax,%eax
8010581b:	78 6d                	js     8010588a <sys_exec+0xaa>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
8010581d:	83 ec 04             	sub    $0x4,%esp
80105820:	8d b5 68 ff ff ff    	lea    -0x98(%ebp),%esi
  for(i=0;; i++){
80105826:	31 db                	xor    %ebx,%ebx
  memset(argv, 0, sizeof(argv));
80105828:	68 80 00 00 00       	push   $0x80
8010582d:	6a 00                	push   $0x0
8010582f:	56                   	push   %esi
80105830:	e8 6b f1 ff ff       	call   801049a0 <memset>
80105835:	83 c4 10             	add    $0x10,%esp
80105838:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010583f:	00 
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
80105840:	83 ec 08             	sub    $0x8,%esp
80105843:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80105849:	50                   	push   %eax
8010584a:	8d 04 9d 00 00 00 00 	lea    0x0(,%ebx,4),%eax
80105851:	03 85 60 ff ff ff    	add    -0xa0(%ebp),%eax
80105857:	50                   	push   %eax
80105858:	e8 73 f3 ff ff       	call   80104bd0 <fetchint>
8010585d:	83 c4 10             	add    $0x10,%esp
80105860:	85 c0                	test   %eax,%eax
80105862:	78 26                	js     8010588a <sys_exec+0xaa>
      return -1;
    if(uarg == 0){
80105864:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
8010586a:	85 c0                	test   %eax,%eax
8010586c:	74 32                	je     801058a0 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
8010586e:	83 ec 08             	sub    $0x8,%esp
80105871:	8d 14 9e             	lea    (%esi,%ebx,4),%edx
80105874:	52                   	push   %edx
80105875:	50                   	push   %eax
80105876:	e8 95 f3 ff ff       	call   80104c10 <fetchstr>
8010587b:	83 c4 10             	add    $0x10,%esp
8010587e:	85 c0                	test   %eax,%eax
80105880:	78 08                	js     8010588a <sys_exec+0xaa>
  for(i=0;; i++){
80105882:	83 c3 01             	add    $0x1,%ebx
    if(i >= NELEM(argv))
80105885:	83 fb 20             	cmp    $0x20,%ebx
80105888:	75 b6                	jne    80105840 <sys_exec+0x60>
      return -1;
  }
  return exec(path, argv);
}
8010588a:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return -1;
8010588d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105892:	5b                   	pop    %ebx
80105893:	5e                   	pop    %esi
80105894:	5f                   	pop    %edi
80105895:	5d                   	pop    %ebp
80105896:	c3                   	ret
80105897:	90                   	nop
80105898:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010589f:	00 
      argv[i] = 0;
801058a0:	c7 84 9d 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%ebx,4)
801058a7:	00 00 00 00 
  return exec(path, argv);
801058ab:	83 ec 08             	sub    $0x8,%esp
801058ae:	56                   	push   %esi
801058af:	ff b5 5c ff ff ff    	push   -0xa4(%ebp)
801058b5:	e8 56 b2 ff ff       	call   80100b10 <exec>
801058ba:	83 c4 10             	add    $0x10,%esp
}
801058bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801058c0:	5b                   	pop    %ebx
801058c1:	5e                   	pop    %esi
801058c2:	5f                   	pop    %edi
801058c3:	5d                   	pop    %ebp
801058c4:	c3                   	ret
801058c5:	8d 76 00             	lea    0x0(%esi),%esi
801058c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801058cf:	00 

801058d0 <sys_pipe>:

int
sys_pipe(void)
{
801058d0:	55                   	push   %ebp
801058d1:	89 e5                	mov    %esp,%ebp
801058d3:	57                   	push   %edi
801058d4:	56                   	push   %esi
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
801058d5:	8d 45 dc             	lea    -0x24(%ebp),%eax
{
801058d8:	53                   	push   %ebx
801058d9:	83 ec 20             	sub    $0x20,%esp
  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
801058dc:	6a 08                	push   $0x8
801058de:	50                   	push   %eax
801058df:	6a 00                	push   $0x0
801058e1:	e8 da f3 ff ff       	call   80104cc0 <argptr>
801058e6:	83 c4 10             	add    $0x10,%esp
801058e9:	85 c0                	test   %eax,%eax
801058eb:	0f 88 93 00 00 00    	js     80105984 <sys_pipe+0xb4>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
801058f1:	83 ec 08             	sub    $0x8,%esp
801058f4:	8d 45 e4             	lea    -0x1c(%ebp),%eax
801058f7:	50                   	push   %eax
801058f8:	8d 45 e0             	lea    -0x20(%ebp),%eax
801058fb:	50                   	push   %eax
801058fc:	e8 3f dd ff ff       	call   80103640 <pipealloc>
80105901:	83 c4 10             	add    $0x10,%esp
80105904:	85 c0                	test   %eax,%eax
80105906:	78 7c                	js     80105984 <sys_pipe+0xb4>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105908:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(fd = 0; fd < NOFILE; fd++){
8010590b:	31 db                	xor    %ebx,%ebx
  struct proc *curproc = myproc();
8010590d:	e8 ce e2 ff ff       	call   80103be0 <myproc>
    if(curproc->ofile[fd] == 0){
80105912:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
80105916:	85 f6                	test   %esi,%esi
80105918:	74 16                	je     80105930 <sys_pipe+0x60>
8010591a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(fd = 0; fd < NOFILE; fd++){
80105920:	83 c3 01             	add    $0x1,%ebx
80105923:	83 fb 10             	cmp    $0x10,%ebx
80105926:	74 45                	je     8010596d <sys_pipe+0x9d>
    if(curproc->ofile[fd] == 0){
80105928:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
8010592c:	85 f6                	test   %esi,%esi
8010592e:	75 f0                	jne    80105920 <sys_pipe+0x50>
      curproc->ofile[fd] = f;
80105930:	8d 73 08             	lea    0x8(%ebx),%esi
80105933:	89 7c b0 08          	mov    %edi,0x8(%eax,%esi,4)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105937:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  struct proc *curproc = myproc();
8010593a:	e8 a1 e2 ff ff       	call   80103be0 <myproc>
8010593f:	89 c2                	mov    %eax,%edx
  for(fd = 0; fd < NOFILE; fd++){
80105941:	31 c0                	xor    %eax,%eax
80105943:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80105948:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010594f:	00 
    if(curproc->ofile[fd] == 0){
80105950:	8b 4c 82 28          	mov    0x28(%edx,%eax,4),%ecx
80105954:	85 c9                	test   %ecx,%ecx
80105956:	74 38                	je     80105990 <sys_pipe+0xc0>
  for(fd = 0; fd < NOFILE; fd++){
80105958:	83 c0 01             	add    $0x1,%eax
8010595b:	83 f8 10             	cmp    $0x10,%eax
8010595e:	75 f0                	jne    80105950 <sys_pipe+0x80>
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
80105960:	e8 7b e2 ff ff       	call   80103be0 <myproc>
80105965:	c7 44 b0 08 00 00 00 	movl   $0x0,0x8(%eax,%esi,4)
8010596c:	00 
    fileclose(rf);
8010596d:	83 ec 0c             	sub    $0xc,%esp
80105970:	ff 75 e0             	push   -0x20(%ebp)
80105973:	e8 08 b6 ff ff       	call   80100f80 <fileclose>
    fileclose(wf);
80105978:	58                   	pop    %eax
80105979:	ff 75 e4             	push   -0x1c(%ebp)
8010597c:	e8 ff b5 ff ff       	call   80100f80 <fileclose>
    return -1;
80105981:	83 c4 10             	add    $0x10,%esp
    return -1;
80105984:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105989:	eb 16                	jmp    801059a1 <sys_pipe+0xd1>
8010598b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      curproc->ofile[fd] = f;
80105990:	89 7c 82 28          	mov    %edi,0x28(%edx,%eax,4)
  }
  fd[0] = fd0;
80105994:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105997:	89 1a                	mov    %ebx,(%edx)
  fd[1] = fd1;
80105999:	8b 55 dc             	mov    -0x24(%ebp),%edx
8010599c:	89 42 04             	mov    %eax,0x4(%edx)
  return 0;
8010599f:	31 c0                	xor    %eax,%eax
}
801059a1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801059a4:	5b                   	pop    %ebx
801059a5:	5e                   	pop    %esi
801059a6:	5f                   	pop    %edi
801059a7:	5d                   	pop    %ebp
801059a8:	c3                   	ret
801059a9:	66 90                	xchg   %ax,%ax
801059ab:	66 90                	xchg   %ax,%ax
801059ad:	66 90                	xchg   %ax,%ax
801059af:	90                   	nop

801059b0 <sys_fork>:
#include "proc.h"

int
sys_fork(void)
{
  return fork();
801059b0:	e9 cb e3 ff ff       	jmp    80103d80 <fork>
801059b5:	8d 76 00             	lea    0x0(%esi),%esi
801059b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801059bf:	00 

801059c0 <sys_exit>:
}

int
sys_exit(void)
{
801059c0:	55                   	push   %ebp
801059c1:	89 e5                	mov    %esp,%ebp
801059c3:	83 ec 08             	sub    $0x8,%esp
  exit();
801059c6:	e8 25 e6 ff ff       	call   80103ff0 <exit>
  return 0;  // not reached
}
801059cb:	31 c0                	xor    %eax,%eax
801059cd:	c9                   	leave
801059ce:	c3                   	ret
801059cf:	90                   	nop

801059d0 <sys_wait>:

int
sys_wait(void)
{
  return wait();
801059d0:	e9 5b e7 ff ff       	jmp    80104130 <wait>
801059d5:	8d 76 00             	lea    0x0(%esi),%esi
801059d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801059df:	00 

801059e0 <sys_kill>:
}

int
sys_kill(void)
{
801059e0:	55                   	push   %ebp
801059e1:	89 e5                	mov    %esp,%ebp
801059e3:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
801059e6:	8d 45 f4             	lea    -0xc(%ebp),%eax
801059e9:	50                   	push   %eax
801059ea:	6a 00                	push   $0x0
801059ec:	e8 7f f2 ff ff       	call   80104c70 <argint>
801059f1:	83 c4 10             	add    $0x10,%esp
801059f4:	85 c0                	test   %eax,%eax
801059f6:	78 18                	js     80105a10 <sys_kill+0x30>
    return -1;
  return kill(pid);
801059f8:	83 ec 0c             	sub    $0xc,%esp
801059fb:	ff 75 f4             	push   -0xc(%ebp)
801059fe:	e8 dd e9 ff ff       	call   801043e0 <kill>
80105a03:	83 c4 10             	add    $0x10,%esp
}
80105a06:	c9                   	leave
80105a07:	c3                   	ret
80105a08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a0f:	00 
80105a10:	c9                   	leave
    return -1;
80105a11:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105a16:	c3                   	ret
80105a17:	90                   	nop
80105a18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a1f:	00 

80105a20 <sys_getpid>:

int
sys_getpid(void)
{
80105a20:	55                   	push   %ebp
80105a21:	89 e5                	mov    %esp,%ebp
80105a23:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80105a26:	e8 b5 e1 ff ff       	call   80103be0 <myproc>
80105a2b:	8b 40 10             	mov    0x10(%eax),%eax
}
80105a2e:	c9                   	leave
80105a2f:	c3                   	ret

80105a30 <sys_sbrk>:

int
sys_sbrk(void)
{
80105a30:	55                   	push   %ebp
80105a31:	89 e5                	mov    %esp,%ebp
80105a33:	53                   	push   %ebx
  int addr;
  int n;

  if(argint(0, &n) < 0)
80105a34:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105a37:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
80105a3a:	50                   	push   %eax
80105a3b:	6a 00                	push   $0x0
80105a3d:	e8 2e f2 ff ff       	call   80104c70 <argint>
80105a42:	83 c4 10             	add    $0x10,%esp
80105a45:	85 c0                	test   %eax,%eax
80105a47:	78 27                	js     80105a70 <sys_sbrk+0x40>
    return -1;
  addr = myproc()->sz;
80105a49:	e8 92 e1 ff ff       	call   80103be0 <myproc>
  if(growproc(n) < 0)
80105a4e:	83 ec 0c             	sub    $0xc,%esp
  addr = myproc()->sz;
80105a51:	8b 18                	mov    (%eax),%ebx
  if(growproc(n) < 0)
80105a53:	ff 75 f4             	push   -0xc(%ebp)
80105a56:	e8 a5 e2 ff ff       	call   80103d00 <growproc>
80105a5b:	83 c4 10             	add    $0x10,%esp
80105a5e:	85 c0                	test   %eax,%eax
80105a60:	78 0e                	js     80105a70 <sys_sbrk+0x40>
  addr = myproc()->sz;
80105a62:	89 d8                	mov    %ebx,%eax
    return -1;
  return addr;
}
80105a64:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105a67:	c9                   	leave
80105a68:	c3                   	ret
80105a69:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105a70:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105a75:	eb ed                	jmp    80105a64 <sys_sbrk+0x34>
80105a77:	90                   	nop
80105a78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a7f:	00 

80105a80 <sys_sleep>:

int
sys_sleep(void)
{
80105a80:	55                   	push   %ebp
80105a81:	89 e5                	mov    %esp,%ebp
80105a83:	53                   	push   %ebx
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
80105a84:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105a87:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
80105a8a:	50                   	push   %eax
80105a8b:	6a 00                	push   $0x0
80105a8d:	e8 de f1 ff ff       	call   80104c70 <argint>
80105a92:	83 c4 10             	add    $0x10,%esp
80105a95:	85 c0                	test   %eax,%eax
80105a97:	78 64                	js     80105afd <sys_sleep+0x7d>
    return -1;
  acquire(&tickslock);
80105a99:	83 ec 0c             	sub    $0xc,%esp
80105a9c:	68 80 3c 11 80       	push   $0x80113c80
80105aa1:	e8 da ed ff ff       	call   80104880 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
80105aa6:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105aa9:	83 c4 10             	add    $0x10,%esp
80105aac:	85 d2                	test   %edx,%edx
80105aae:	74 58                	je     80105b08 <sys_sleep+0x88>
  ticks0 = ticks;
80105ab0:	8b 1d 60 3c 11 80    	mov    0x80113c60,%ebx
80105ab6:	eb 29                	jmp    80105ae1 <sys_sleep+0x61>
80105ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105abf:	00 
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80105ac0:	83 ec 08             	sub    $0x8,%esp
80105ac3:	68 80 3c 11 80       	push   $0x80113c80
80105ac8:	68 60 3c 11 80       	push   $0x80113c60
80105acd:	e8 ee e7 ff ff       	call   801042c0 <sleep>
  while(ticks - ticks0 < n){
80105ad2:	a1 60 3c 11 80       	mov    0x80113c60,%eax
80105ad7:	83 c4 10             	add    $0x10,%esp
80105ada:	29 d8                	sub    %ebx,%eax
80105adc:	3b 45 f4             	cmp    -0xc(%ebp),%eax
80105adf:	73 27                	jae    80105b08 <sys_sleep+0x88>
    if(myproc()->killed){
80105ae1:	e8 fa e0 ff ff       	call   80103be0 <myproc>
80105ae6:	8b 40 24             	mov    0x24(%eax),%eax
80105ae9:	85 c0                	test   %eax,%eax
80105aeb:	74 d3                	je     80105ac0 <sys_sleep+0x40>
      release(&tickslock);
80105aed:	83 ec 0c             	sub    $0xc,%esp
80105af0:	68 80 3c 11 80       	push   $0x80113c80
80105af5:	e8 26 ed ff ff       	call   80104820 <release>
      return -1;
80105afa:	83 c4 10             	add    $0x10,%esp
    return -1;
80105afd:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b02:	eb 16                	jmp    80105b1a <sys_sleep+0x9a>
80105b04:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  release(&tickslock);
80105b08:	83 ec 0c             	sub    $0xc,%esp
80105b0b:	68 80 3c 11 80       	push   $0x80113c80
80105b10:	e8 0b ed ff ff       	call   80104820 <release>
  return 0;
80105b15:	83 c4 10             	add    $0x10,%esp
80105b18:	31 c0                	xor    %eax,%eax
}
80105b1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105b1d:	c9                   	leave
80105b1e:	c3                   	ret
80105b1f:	90                   	nop

80105b20 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
80105b20:	55                   	push   %ebp
80105b21:	89 e5                	mov    %esp,%ebp
80105b23:	53                   	push   %ebx
80105b24:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
80105b27:	68 80 3c 11 80       	push   $0x80113c80
80105b2c:	e8 4f ed ff ff       	call   80104880 <acquire>
  xticks = ticks;
80105b31:	8b 1d 60 3c 11 80    	mov    0x80113c60,%ebx
  release(&tickslock);
80105b37:	c7 04 24 80 3c 11 80 	movl   $0x80113c80,(%esp)
80105b3e:	e8 dd ec ff ff       	call   80104820 <release>
  return xticks;
}
80105b43:	89 d8                	mov    %ebx,%eax
80105b45:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105b48:	c9                   	leave
80105b49:	c3                   	ret
80105b4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105b50 <sys_freepages>:

// Q2: Return the number of free physical pages.
int
sys_freepages(void)
{
  return freepages_count();
80105b50:	e9 db cc ff ff       	jmp    80102830 <freepages_count>
80105b55:	8d 76 00             	lea    0x0(%esi),%esi
80105b58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105b5f:	00 

80105b60 <sys_va2pa>:
}

// Q2: Translate a user virtual address to a physical address.
int
sys_va2pa(void)
{
80105b60:	55                   	push   %ebp
80105b61:	89 e5                	mov    %esp,%ebp
80105b63:	53                   	push   %ebx
  int va;

  if(argint(0, &va) < 0)
80105b64:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105b67:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &va) < 0)
80105b6a:	50                   	push   %eax
80105b6b:	6a 00                	push   $0x0
80105b6d:	e8 fe f0 ff ff       	call   80104c70 <argint>
80105b72:	83 c4 10             	add    $0x10,%esp
80105b75:	85 c0                	test   %eax,%eax
80105b77:	78 1f                	js     80105b98 <sys_va2pa+0x38>
    return -1;

  return va2pa(myproc()->pgdir, (uint)va);
80105b79:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105b7c:	e8 5f e0 ff ff       	call   80103be0 <myproc>
80105b81:	83 ec 08             	sub    $0x8,%esp
80105b84:	53                   	push   %ebx
80105b85:	ff 70 04             	push   0x4(%eax)
80105b88:	e8 33 12 00 00       	call   80106dc0 <va2pa>
80105b8d:	83 c4 10             	add    $0x10,%esp
}
80105b90:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105b93:	c9                   	leave
80105b94:	c3                   	ret
80105b95:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105b98:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b9d:	eb f1                	jmp    80105b90 <sys_va2pa+0x30>

80105b9f <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
80105b9f:	1e                   	push   %ds
  pushl %es
80105ba0:	06                   	push   %es
  pushl %fs
80105ba1:	0f a0                	push   %fs
  pushl %gs
80105ba3:	0f a8                	push   %gs
  pushal
80105ba5:	60                   	pusha
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80105ba6:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80105baa:	8e d8                	mov    %eax,%ds
  movw %ax, %es
80105bac:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
80105bae:	54                   	push   %esp
  call trap
80105baf:	e8 2c 01 00 00       	call   80105ce0 <trap>
  addl $4, %esp
80105bb4:	83 c4 04             	add    $0x4,%esp

80105bb7 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80105bb7:	61                   	popa
  popl %gs
80105bb8:	0f a9                	pop    %gs
  popl %fs
80105bba:	0f a1                	pop    %fs
  popl %es
80105bbc:	07                   	pop    %es
  popl %ds
80105bbd:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
80105bbe:	83 c4 08             	add    $0x8,%esp
  iret
80105bc1:	cf                   	iret
80105bc2:	66 90                	xchg   %ax,%ax
80105bc4:	66 90                	xchg   %ax,%ax
80105bc6:	66 90                	xchg   %ax,%ax
80105bc8:	66 90                	xchg   %ax,%ax
80105bca:	66 90                	xchg   %ax,%ax
80105bcc:	66 90                	xchg   %ax,%ax
80105bce:	66 90                	xchg   %ax,%ax
80105bd0:	66 90                	xchg   %ax,%ax
80105bd2:	66 90                	xchg   %ax,%ax
80105bd4:	66 90                	xchg   %ax,%ax
80105bd6:	66 90                	xchg   %ax,%ax
80105bd8:	66 90                	xchg   %ax,%ax
80105bda:	66 90                	xchg   %ax,%ax
80105bdc:	66 90                	xchg   %ax,%ax
80105bde:	66 90                	xchg   %ax,%ax
80105be0:	66 90                	xchg   %ax,%ax
80105be2:	66 90                	xchg   %ax,%ax
80105be4:	66 90                	xchg   %ax,%ax
80105be6:	66 90                	xchg   %ax,%ax
80105be8:	66 90                	xchg   %ax,%ax
80105bea:	66 90                	xchg   %ax,%ax
80105bec:	66 90                	xchg   %ax,%ax
80105bee:	66 90                	xchg   %ax,%ax
80105bf0:	66 90                	xchg   %ax,%ax
80105bf2:	66 90                	xchg   %ax,%ax
80105bf4:	66 90                	xchg   %ax,%ax
80105bf6:	66 90                	xchg   %ax,%ax
80105bf8:	66 90                	xchg   %ax,%ax
80105bfa:	66 90                	xchg   %ax,%ax
80105bfc:	66 90                	xchg   %ax,%ax
80105bfe:	66 90                	xchg   %ax,%ax

80105c00 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
80105c00:	55                   	push   %ebp
  int i;

  for(i = 0; i < 256; i++)
80105c01:	31 c0                	xor    %eax,%eax
{
80105c03:	89 e5                	mov    %esp,%ebp
80105c05:	83 ec 08             	sub    $0x8,%esp
80105c08:	eb 36                	jmp    80105c40 <tvinit+0x40>
80105c0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80105c10:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c17:	00 
80105c18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c1f:	00 
80105c20:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c27:	00 
80105c28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c2f:	00 
80105c30:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c37:	00 
80105c38:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c3f:	00 
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80105c40:	8b 14 85 08 a0 10 80 	mov    -0x7fef5ff8(,%eax,4),%edx
80105c47:	c7 04 c5 c2 3c 11 80 	movl   $0x8e000008,-0x7feec33e(,%eax,8)
80105c4e:	08 00 00 8e 
80105c52:	66 89 14 c5 c0 3c 11 	mov    %dx,-0x7feec340(,%eax,8)
80105c59:	80 
80105c5a:	c1 ea 10             	shr    $0x10,%edx
80105c5d:	66 89 14 c5 c6 3c 11 	mov    %dx,-0x7feec33a(,%eax,8)
80105c64:	80 
  for(i = 0; i < 256; i++)
80105c65:	83 c0 01             	add    $0x1,%eax
80105c68:	3d 00 01 00 00       	cmp    $0x100,%eax
80105c6d:	75 d1                	jne    80105c40 <tvinit+0x40>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
80105c6f:	83 ec 08             	sub    $0x8,%esp
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105c72:	a1 08 a1 10 80       	mov    0x8010a108,%eax
80105c77:	c7 05 c2 3e 11 80 08 	movl   $0xef000008,0x80113ec2
80105c7e:	00 00 ef 
  initlock(&tickslock, "time");
80105c81:	68 8e 79 10 80       	push   $0x8010798e
80105c86:	68 80 3c 11 80       	push   $0x80113c80
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105c8b:	66 a3 c0 3e 11 80    	mov    %ax,0x80113ec0
80105c91:	c1 e8 10             	shr    $0x10,%eax
80105c94:	66 a3 c6 3e 11 80    	mov    %ax,0x80113ec6
  initlock(&tickslock, "time");
80105c9a:	e8 c1 e9 ff ff       	call   80104660 <initlock>
}
80105c9f:	83 c4 10             	add    $0x10,%esp
80105ca2:	c9                   	leave
80105ca3:	c3                   	ret
80105ca4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80105ca8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105caf:	00 

80105cb0 <idtinit>:

void
idtinit(void)
{
80105cb0:	55                   	push   %ebp
  pd[0] = size-1;
80105cb1:	b8 ff 07 00 00       	mov    $0x7ff,%eax
80105cb6:	89 e5                	mov    %esp,%ebp
80105cb8:	83 ec 10             	sub    $0x10,%esp
80105cbb:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80105cbf:	b8 c0 3c 11 80       	mov    $0x80113cc0,%eax
80105cc4:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80105cc8:	c1 e8 10             	shr    $0x10,%eax
80105ccb:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80105ccf:	8d 45 fa             	lea    -0x6(%ebp),%eax
80105cd2:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80105cd5:	c9                   	leave
80105cd6:	c3                   	ret
80105cd7:	90                   	nop
80105cd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105cdf:	00 

80105ce0 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80105ce0:	55                   	push   %ebp
80105ce1:	89 e5                	mov    %esp,%ebp
80105ce3:	57                   	push   %edi
80105ce4:	56                   	push   %esi
80105ce5:	53                   	push   %ebx
80105ce6:	83 ec 1c             	sub    $0x1c,%esp
80105ce9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(tf->trapno == T_SYSCALL){
80105cec:	8b 43 30             	mov    0x30(%ebx),%eax
80105cef:	83 f8 40             	cmp    $0x40,%eax
80105cf2:	0f 84 68 01 00 00    	je     80105e60 <trap+0x180>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
80105cf8:	83 e8 20             	sub    $0x20,%eax
80105cfb:	83 f8 1f             	cmp    $0x1f,%eax
80105cfe:	0f 87 7c 00 00 00    	ja     80105d80 <trap+0xa0>
80105d04:	ff 24 85 e0 7e 10 80 	jmp    *-0x7fef8120(,%eax,4)
80105d0b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
80105d10:	e8 0b c6 ff ff       	call   80102320 <ideintr>
    lapiceoi();
80105d15:	e8 86 cd ff ff       	call   80102aa0 <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105d1a:	e8 c1 de ff ff       	call   80103be0 <myproc>
80105d1f:	85 c0                	test   %eax,%eax
80105d21:	74 1a                	je     80105d3d <trap+0x5d>
80105d23:	e8 b8 de ff ff       	call   80103be0 <myproc>
80105d28:	8b 50 24             	mov    0x24(%eax),%edx
80105d2b:	85 d2                	test   %edx,%edx
80105d2d:	74 0e                	je     80105d3d <trap+0x5d>
80105d2f:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80105d33:	f7 d0                	not    %eax
80105d35:	a8 03                	test   $0x3,%al
80105d37:	0f 84 eb 01 00 00    	je     80105f28 <trap+0x248>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80105d3d:	e8 9e de ff ff       	call   80103be0 <myproc>
80105d42:	85 c0                	test   %eax,%eax
80105d44:	74 0f                	je     80105d55 <trap+0x75>
80105d46:	e8 95 de ff ff       	call   80103be0 <myproc>
80105d4b:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
80105d4f:	0f 84 ab 00 00 00    	je     80105e00 <trap+0x120>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105d55:	e8 86 de ff ff       	call   80103be0 <myproc>
80105d5a:	85 c0                	test   %eax,%eax
80105d5c:	74 1a                	je     80105d78 <trap+0x98>
80105d5e:	e8 7d de ff ff       	call   80103be0 <myproc>
80105d63:	8b 40 24             	mov    0x24(%eax),%eax
80105d66:	85 c0                	test   %eax,%eax
80105d68:	74 0e                	je     80105d78 <trap+0x98>
80105d6a:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80105d6e:	f7 d0                	not    %eax
80105d70:	a8 03                	test   $0x3,%al
80105d72:	0f 84 15 01 00 00    	je     80105e8d <trap+0x1ad>
    exit();
}
80105d78:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105d7b:	5b                   	pop    %ebx
80105d7c:	5e                   	pop    %esi
80105d7d:	5f                   	pop    %edi
80105d7e:	5d                   	pop    %ebp
80105d7f:	c3                   	ret
    if(myproc() == 0 || (tf->cs&3) == 0){
80105d80:	e8 5b de ff ff       	call   80103be0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105d85:	8b 73 38             	mov    0x38(%ebx),%esi
80105d88:	89 75 e4             	mov    %esi,-0x1c(%ebp)
    if(myproc() == 0 || (tf->cs&3) == 0){
80105d8b:	85 c0                	test   %eax,%eax
80105d8d:	0f 84 af 01 00 00    	je     80105f42 <trap+0x262>
80105d93:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
80105d97:	0f 84 a5 01 00 00    	je     80105f42 <trap+0x262>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
80105d9d:	0f 20 d7             	mov    %cr2,%edi
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105da0:	e8 1b de ff ff       	call   80103bc0 <cpuid>
80105da5:	8b 4b 30             	mov    0x30(%ebx),%ecx
80105da8:	89 45 d8             	mov    %eax,-0x28(%ebp)
80105dab:	8b 43 34             	mov    0x34(%ebx),%eax
80105dae:	89 4d dc             	mov    %ecx,-0x24(%ebp)
80105db1:	89 45 e0             	mov    %eax,-0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80105db4:	e8 27 de ff ff       	call   80103be0 <myproc>
80105db9:	8d 70 6c             	lea    0x6c(%eax),%esi
80105dbc:	e8 1f de ff ff       	call   80103be0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105dc1:	57                   	push   %edi
80105dc2:	ff 75 e4             	push   -0x1c(%ebp)
80105dc5:	8b 55 d8             	mov    -0x28(%ebp),%edx
80105dc8:	52                   	push   %edx
80105dc9:	ff 75 e0             	push   -0x20(%ebp)
80105dcc:	8b 4d dc             	mov    -0x24(%ebp),%ecx
80105dcf:	51                   	push   %ecx
80105dd0:	56                   	push   %esi
80105dd1:	ff 70 10             	push   0x10(%eax)
80105dd4:	68 bc 7b 10 80       	push   $0x80107bbc
80105dd9:	e8 f2 a8 ff ff       	call   801006d0 <cprintf>
    myproc()->killed = 1;
80105dde:	83 c4 20             	add    $0x20,%esp
80105de1:	e8 fa dd ff ff       	call   80103be0 <myproc>
80105de6:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105ded:	e8 ee dd ff ff       	call   80103be0 <myproc>
80105df2:	85 c0                	test   %eax,%eax
80105df4:	0f 85 29 ff ff ff    	jne    80105d23 <trap+0x43>
80105dfa:	e9 3e ff ff ff       	jmp    80105d3d <trap+0x5d>
80105dff:	90                   	nop
  if(myproc() && myproc()->state == RUNNING &&
80105e00:	83 7b 30 20          	cmpl   $0x20,0x30(%ebx)
80105e04:	0f 85 4b ff ff ff    	jne    80105d55 <trap+0x75>
    yield();
80105e0a:	e8 61 e4 ff ff       	call   80104270 <yield>
80105e0f:	e9 41 ff ff ff       	jmp    80105d55 <trap+0x75>
80105e14:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80105e18:	8b 4b 38             	mov    0x38(%ebx),%ecx
80105e1b:	0f b7 53 3c          	movzwl 0x3c(%ebx),%edx
80105e1f:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80105e22:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80105e25:	e8 96 dd ff ff       	call   80103bc0 <cpuid>
80105e2a:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80105e2d:	51                   	push   %ecx
80105e2e:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80105e31:	52                   	push   %edx
80105e32:	50                   	push   %eax
80105e33:	68 64 7b 10 80       	push   $0x80107b64
80105e38:	e8 93 a8 ff ff       	call   801006d0 <cprintf>
    lapiceoi();
80105e3d:	e8 5e cc ff ff       	call   80102aa0 <lapiceoi>
    break;
80105e42:	83 c4 10             	add    $0x10,%esp
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105e45:	e8 96 dd ff ff       	call   80103be0 <myproc>
80105e4a:	85 c0                	test   %eax,%eax
80105e4c:	0f 85 d1 fe ff ff    	jne    80105d23 <trap+0x43>
80105e52:	e9 e6 fe ff ff       	jmp    80105d3d <trap+0x5d>
80105e57:	90                   	nop
80105e58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105e5f:	00 
    if(myproc()->killed)
80105e60:	e8 7b dd ff ff       	call   80103be0 <myproc>
80105e65:	8b 70 24             	mov    0x24(%eax),%esi
80105e68:	85 f6                	test   %esi,%esi
80105e6a:	0f 85 c8 00 00 00    	jne    80105f38 <trap+0x258>
    myproc()->tf = tf;
80105e70:	e8 6b dd ff ff       	call   80103be0 <myproc>
80105e75:	89 58 18             	mov    %ebx,0x18(%eax)
    syscall();
80105e78:	e8 33 ef ff ff       	call   80104db0 <syscall>
    if(myproc()->killed)
80105e7d:	e8 5e dd ff ff       	call   80103be0 <myproc>
80105e82:	8b 48 24             	mov    0x24(%eax),%ecx
80105e85:	85 c9                	test   %ecx,%ecx
80105e87:	0f 84 eb fe ff ff    	je     80105d78 <trap+0x98>
}
80105e8d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105e90:	5b                   	pop    %ebx
80105e91:	5e                   	pop    %esi
80105e92:	5f                   	pop    %edi
80105e93:	5d                   	pop    %ebp
      exit();
80105e94:	e9 57 e1 ff ff       	jmp    80103ff0 <exit>
80105e99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    uartintr();
80105ea0:	e8 4b 02 00 00       	call   801060f0 <uartintr>
    lapiceoi();
80105ea5:	e8 f6 cb ff ff       	call   80102aa0 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105eaa:	e8 31 dd ff ff       	call   80103be0 <myproc>
80105eaf:	85 c0                	test   %eax,%eax
80105eb1:	0f 85 6c fe ff ff    	jne    80105d23 <trap+0x43>
80105eb7:	e9 81 fe ff ff       	jmp    80105d3d <trap+0x5d>
80105ebc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    kbdintr();
80105ec0:	e8 9b ca ff ff       	call   80102960 <kbdintr>
    lapiceoi();
80105ec5:	e8 d6 cb ff ff       	call   80102aa0 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105eca:	e8 11 dd ff ff       	call   80103be0 <myproc>
80105ecf:	85 c0                	test   %eax,%eax
80105ed1:	0f 85 4c fe ff ff    	jne    80105d23 <trap+0x43>
80105ed7:	e9 61 fe ff ff       	jmp    80105d3d <trap+0x5d>
80105edc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(cpuid() == 0){
80105ee0:	e8 db dc ff ff       	call   80103bc0 <cpuid>
80105ee5:	85 c0                	test   %eax,%eax
80105ee7:	0f 85 28 fe ff ff    	jne    80105d15 <trap+0x35>
      acquire(&tickslock);
80105eed:	83 ec 0c             	sub    $0xc,%esp
80105ef0:	68 80 3c 11 80       	push   $0x80113c80
80105ef5:	e8 86 e9 ff ff       	call   80104880 <acquire>
      ticks++;
80105efa:	83 05 60 3c 11 80 01 	addl   $0x1,0x80113c60
      wakeup(&ticks);
80105f01:	c7 04 24 60 3c 11 80 	movl   $0x80113c60,(%esp)
80105f08:	e8 73 e4 ff ff       	call   80104380 <wakeup>
      release(&tickslock);
80105f0d:	c7 04 24 80 3c 11 80 	movl   $0x80113c80,(%esp)
80105f14:	e8 07 e9 ff ff       	call   80104820 <release>
80105f19:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
80105f1c:	e9 f4 fd ff ff       	jmp    80105d15 <trap+0x35>
80105f21:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    exit();
80105f28:	e8 c3 e0 ff ff       	call   80103ff0 <exit>
80105f2d:	e9 0b fe ff ff       	jmp    80105d3d <trap+0x5d>
80105f32:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      exit();
80105f38:	e8 b3 e0 ff ff       	call   80103ff0 <exit>
80105f3d:	e9 2e ff ff ff       	jmp    80105e70 <trap+0x190>
80105f42:	0f 20 d2             	mov    %cr2,%edx
80105f45:	89 55 e0             	mov    %edx,-0x20(%ebp)
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
80105f48:	e8 73 dc ff ff       	call   80103bc0 <cpuid>
80105f4d:	8b 55 e0             	mov    -0x20(%ebp),%edx
80105f50:	83 ec 0c             	sub    $0xc,%esp
80105f53:	52                   	push   %edx
80105f54:	ff 75 e4             	push   -0x1c(%ebp)
80105f57:	50                   	push   %eax
80105f58:	ff 73 30             	push   0x30(%ebx)
80105f5b:	68 88 7b 10 80       	push   $0x80107b88
80105f60:	e8 6b a7 ff ff       	call   801006d0 <cprintf>
      panic("trap");
80105f65:	83 c4 14             	add    $0x14,%esp
80105f68:	68 93 79 10 80       	push   $0x80107993
80105f6d:	e8 2e a4 ff ff       	call   801003a0 <panic>
80105f72:	66 90                	xchg   %ax,%ax
80105f74:	66 90                	xchg   %ax,%ax
80105f76:	66 90                	xchg   %ax,%ax
80105f78:	66 90                	xchg   %ax,%ax
80105f7a:	66 90                	xchg   %ax,%ax
80105f7c:	66 90                	xchg   %ax,%ax
80105f7e:	66 90                	xchg   %ax,%ax

80105f80 <uartgetc>:
}

static int
uartgetc(void)
{
  if(!uart)
80105f80:	a1 c0 44 11 80       	mov    0x801144c0,%eax
80105f85:	85 c0                	test   %eax,%eax
80105f87:	74 17                	je     80105fa0 <uartgetc+0x20>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80105f89:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105f8e:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
80105f8f:	a8 01                	test   $0x1,%al
80105f91:	74 0d                	je     80105fa0 <uartgetc+0x20>
80105f93:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105f98:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
80105f99:	0f b6 c0             	movzbl %al,%eax
80105f9c:	c3                   	ret
80105f9d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105fa0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105fa5:	c3                   	ret
80105fa6:	66 90                	xchg   %ax,%ax
80105fa8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105faf:	00 

80105fb0 <uartinit>:
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80105fb0:	31 c0                	xor    %eax,%eax
80105fb2:	ba fa 03 00 00       	mov    $0x3fa,%edx
80105fb7:	ee                   	out    %al,(%dx)
80105fb8:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
80105fbd:	ba fb 03 00 00       	mov    $0x3fb,%edx
80105fc2:	ee                   	out    %al,(%dx)
80105fc3:	b8 0c 00 00 00       	mov    $0xc,%eax
80105fc8:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105fcd:	ee                   	out    %al,(%dx)
80105fce:	31 c0                	xor    %eax,%eax
80105fd0:	ba f9 03 00 00       	mov    $0x3f9,%edx
80105fd5:	ee                   	out    %al,(%dx)
80105fd6:	b8 03 00 00 00       	mov    $0x3,%eax
80105fdb:	ba fb 03 00 00       	mov    $0x3fb,%edx
80105fe0:	ee                   	out    %al,(%dx)
80105fe1:	ba fc 03 00 00       	mov    $0x3fc,%edx
80105fe6:	31 c0                	xor    %eax,%eax
80105fe8:	ee                   	out    %al,(%dx)
80105fe9:	b8 01 00 00 00       	mov    $0x1,%eax
80105fee:	ba f9 03 00 00       	mov    $0x3f9,%edx
80105ff3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80105ff4:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105ff9:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
80105ffa:	3c ff                	cmp    $0xff,%al
80105ffc:	0f 84 8e 00 00 00    	je     80106090 <uartinit+0xe0>
{
80106002:	55                   	push   %ebp
80106003:	ba fa 03 00 00       	mov    $0x3fa,%edx
80106008:	89 e5                	mov    %esp,%ebp
8010600a:	57                   	push   %edi
8010600b:	56                   	push   %esi
8010600c:	53                   	push   %ebx
8010600d:	83 ec 24             	sub    $0x24,%esp
  uart = 1;
80106010:	c7 05 c0 44 11 80 01 	movl   $0x1,0x801144c0
80106017:	00 00 00 
8010601a:	ec                   	in     (%dx),%al
8010601b:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106020:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
80106021:	6a 00                	push   $0x0
  for(p="xv6...\n"; *p; p++)
80106023:	bf 98 79 10 80       	mov    $0x80107998,%edi
  ioapicenable(IRQ_COM1, 0);
80106028:	6a 04                	push   $0x4
8010602a:	e8 51 c5 ff ff       	call   80102580 <ioapicenable>
8010602f:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
80106032:	c6 45 e7 78          	movb   $0x78,-0x19(%ebp)
80106036:	66 90                	xchg   %ax,%ax
80106038:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010603f:	00 
  if(!uart)
80106040:	a1 c0 44 11 80       	mov    0x801144c0,%eax
80106045:	bb 80 00 00 00       	mov    $0x80,%ebx
8010604a:	85 c0                	test   %eax,%eax
8010604c:	75 14                	jne    80106062 <uartinit+0xb2>
8010604e:	eb 26                	jmp    80106076 <uartinit+0xc6>
    microdelay(10);
80106050:	83 ec 0c             	sub    $0xc,%esp
80106053:	6a 0a                	push   $0xa
80106055:	e8 66 ca ff ff       	call   80102ac0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
8010605a:	83 c4 10             	add    $0x10,%esp
8010605d:	83 eb 01             	sub    $0x1,%ebx
80106060:	74 0a                	je     8010606c <uartinit+0xbc>
80106062:	ba fd 03 00 00       	mov    $0x3fd,%edx
80106067:	ec                   	in     (%dx),%al
80106068:	a8 20                	test   $0x20,%al
8010606a:	74 e4                	je     80106050 <uartinit+0xa0>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010606c:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
80106070:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106075:	ee                   	out    %al,(%dx)
  for(p="xv6...\n"; *p; p++)
80106076:	0f b6 47 01          	movzbl 0x1(%edi),%eax
8010607a:	83 c7 01             	add    $0x1,%edi
8010607d:	88 45 e7             	mov    %al,-0x19(%ebp)
80106080:	81 ff 9f 79 10 80    	cmp    $0x8010799f,%edi
80106086:	75 b8                	jne    80106040 <uartinit+0x90>
}
80106088:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010608b:	5b                   	pop    %ebx
8010608c:	5e                   	pop    %esi
8010608d:	5f                   	pop    %edi
8010608e:	5d                   	pop    %ebp
8010608f:	c3                   	ret
80106090:	c3                   	ret
80106091:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106098:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010609f:	00 

801060a0 <uartputc>:
  if(!uart)
801060a0:	a1 c0 44 11 80       	mov    0x801144c0,%eax
801060a5:	85 c0                	test   %eax,%eax
801060a7:	74 3f                	je     801060e8 <uartputc+0x48>
{
801060a9:	55                   	push   %ebp
801060aa:	89 e5                	mov    %esp,%ebp
801060ac:	56                   	push   %esi
801060ad:	53                   	push   %ebx
801060ae:	bb 80 00 00 00       	mov    $0x80,%ebx
801060b3:	eb 15                	jmp    801060ca <uartputc+0x2a>
801060b5:	8d 76 00             	lea    0x0(%esi),%esi
    microdelay(10);
801060b8:	83 ec 0c             	sub    $0xc,%esp
801060bb:	6a 0a                	push   $0xa
801060bd:	e8 fe c9 ff ff       	call   80102ac0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
801060c2:	83 c4 10             	add    $0x10,%esp
801060c5:	83 eb 01             	sub    $0x1,%ebx
801060c8:	74 0a                	je     801060d4 <uartputc+0x34>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801060ca:	ba fd 03 00 00       	mov    $0x3fd,%edx
801060cf:	ec                   	in     (%dx),%al
801060d0:	a8 20                	test   $0x20,%al
801060d2:	74 e4                	je     801060b8 <uartputc+0x18>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801060d4:	8b 45 08             	mov    0x8(%ebp),%eax
801060d7:	ba f8 03 00 00       	mov    $0x3f8,%edx
801060dc:	ee                   	out    %al,(%dx)
}
801060dd:	8d 65 f8             	lea    -0x8(%ebp),%esp
801060e0:	5b                   	pop    %ebx
801060e1:	5e                   	pop    %esi
801060e2:	5d                   	pop    %ebp
801060e3:	c3                   	ret
801060e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801060e8:	c3                   	ret
801060e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801060f0 <uartintr>:

void
uartintr(void)
{
801060f0:	55                   	push   %ebp
801060f1:	89 e5                	mov    %esp,%ebp
801060f3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
801060f6:	68 80 5f 10 80       	push   $0x80105f80
801060fb:	e8 d0 a7 ff ff       	call   801008d0 <consoleintr>
}
80106100:	83 c4 10             	add    $0x10,%esp
80106103:	c9                   	leave
80106104:	c3                   	ret

80106105 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
80106105:	6a 00                	push   $0x0
  pushl $0
80106107:	6a 00                	push   $0x0
  jmp alltraps
80106109:	e9 91 fa ff ff       	jmp    80105b9f <alltraps>

8010610e <vector1>:
.globl vector1
vector1:
  pushl $0
8010610e:	6a 00                	push   $0x0
  pushl $1
80106110:	6a 01                	push   $0x1
  jmp alltraps
80106112:	e9 88 fa ff ff       	jmp    80105b9f <alltraps>

80106117 <vector2>:
.globl vector2
vector2:
  pushl $0
80106117:	6a 00                	push   $0x0
  pushl $2
80106119:	6a 02                	push   $0x2
  jmp alltraps
8010611b:	e9 7f fa ff ff       	jmp    80105b9f <alltraps>

80106120 <vector3>:
.globl vector3
vector3:
  pushl $0
80106120:	6a 00                	push   $0x0
  pushl $3
80106122:	6a 03                	push   $0x3
  jmp alltraps
80106124:	e9 76 fa ff ff       	jmp    80105b9f <alltraps>

80106129 <vector4>:
.globl vector4
vector4:
  pushl $0
80106129:	6a 00                	push   $0x0
  pushl $4
8010612b:	6a 04                	push   $0x4
  jmp alltraps
8010612d:	e9 6d fa ff ff       	jmp    80105b9f <alltraps>

80106132 <vector5>:
.globl vector5
vector5:
  pushl $0
80106132:	6a 00                	push   $0x0
  pushl $5
80106134:	6a 05                	push   $0x5
  jmp alltraps
80106136:	e9 64 fa ff ff       	jmp    80105b9f <alltraps>

8010613b <vector6>:
.globl vector6
vector6:
  pushl $0
8010613b:	6a 00                	push   $0x0
  pushl $6
8010613d:	6a 06                	push   $0x6
  jmp alltraps
8010613f:	e9 5b fa ff ff       	jmp    80105b9f <alltraps>

80106144 <vector7>:
.globl vector7
vector7:
  pushl $0
80106144:	6a 00                	push   $0x0
  pushl $7
80106146:	6a 07                	push   $0x7
  jmp alltraps
80106148:	e9 52 fa ff ff       	jmp    80105b9f <alltraps>

8010614d <vector8>:
.globl vector8
vector8:
  pushl $8
8010614d:	6a 08                	push   $0x8
  jmp alltraps
8010614f:	e9 4b fa ff ff       	jmp    80105b9f <alltraps>

80106154 <vector9>:
.globl vector9
vector9:
  pushl $0
80106154:	6a 00                	push   $0x0
  pushl $9
80106156:	6a 09                	push   $0x9
  jmp alltraps
80106158:	e9 42 fa ff ff       	jmp    80105b9f <alltraps>

8010615d <vector10>:
.globl vector10
vector10:
  pushl $10
8010615d:	6a 0a                	push   $0xa
  jmp alltraps
8010615f:	e9 3b fa ff ff       	jmp    80105b9f <alltraps>

80106164 <vector11>:
.globl vector11
vector11:
  pushl $11
80106164:	6a 0b                	push   $0xb
  jmp alltraps
80106166:	e9 34 fa ff ff       	jmp    80105b9f <alltraps>

8010616b <vector12>:
.globl vector12
vector12:
  pushl $12
8010616b:	6a 0c                	push   $0xc
  jmp alltraps
8010616d:	e9 2d fa ff ff       	jmp    80105b9f <alltraps>

80106172 <vector13>:
.globl vector13
vector13:
  pushl $13
80106172:	6a 0d                	push   $0xd
  jmp alltraps
80106174:	e9 26 fa ff ff       	jmp    80105b9f <alltraps>

80106179 <vector14>:
.globl vector14
vector14:
  pushl $14
80106179:	6a 0e                	push   $0xe
  jmp alltraps
8010617b:	e9 1f fa ff ff       	jmp    80105b9f <alltraps>

80106180 <vector15>:
.globl vector15
vector15:
  pushl $0
80106180:	6a 00                	push   $0x0
  pushl $15
80106182:	6a 0f                	push   $0xf
  jmp alltraps
80106184:	e9 16 fa ff ff       	jmp    80105b9f <alltraps>

80106189 <vector16>:
.globl vector16
vector16:
  pushl $0
80106189:	6a 00                	push   $0x0
  pushl $16
8010618b:	6a 10                	push   $0x10
  jmp alltraps
8010618d:	e9 0d fa ff ff       	jmp    80105b9f <alltraps>

80106192 <vector17>:
.globl vector17
vector17:
  pushl $17
80106192:	6a 11                	push   $0x11
  jmp alltraps
80106194:	e9 06 fa ff ff       	jmp    80105b9f <alltraps>

80106199 <vector18>:
.globl vector18
vector18:
  pushl $0
80106199:	6a 00                	push   $0x0
  pushl $18
8010619b:	6a 12                	push   $0x12
  jmp alltraps
8010619d:	e9 fd f9 ff ff       	jmp    80105b9f <alltraps>

801061a2 <vector19>:
.globl vector19
vector19:
  pushl $0
801061a2:	6a 00                	push   $0x0
  pushl $19
801061a4:	6a 13                	push   $0x13
  jmp alltraps
801061a6:	e9 f4 f9 ff ff       	jmp    80105b9f <alltraps>

801061ab <vector20>:
.globl vector20
vector20:
  pushl $0
801061ab:	6a 00                	push   $0x0
  pushl $20
801061ad:	6a 14                	push   $0x14
  jmp alltraps
801061af:	e9 eb f9 ff ff       	jmp    80105b9f <alltraps>

801061b4 <vector21>:
.globl vector21
vector21:
  pushl $0
801061b4:	6a 00                	push   $0x0
  pushl $21
801061b6:	6a 15                	push   $0x15
  jmp alltraps
801061b8:	e9 e2 f9 ff ff       	jmp    80105b9f <alltraps>

801061bd <vector22>:
.globl vector22
vector22:
  pushl $0
801061bd:	6a 00                	push   $0x0
  pushl $22
801061bf:	6a 16                	push   $0x16
  jmp alltraps
801061c1:	e9 d9 f9 ff ff       	jmp    80105b9f <alltraps>

801061c6 <vector23>:
.globl vector23
vector23:
  pushl $0
801061c6:	6a 00                	push   $0x0
  pushl $23
801061c8:	6a 17                	push   $0x17
  jmp alltraps
801061ca:	e9 d0 f9 ff ff       	jmp    80105b9f <alltraps>

801061cf <vector24>:
.globl vector24
vector24:
  pushl $0
801061cf:	6a 00                	push   $0x0
  pushl $24
801061d1:	6a 18                	push   $0x18
  jmp alltraps
801061d3:	e9 c7 f9 ff ff       	jmp    80105b9f <alltraps>

801061d8 <vector25>:
.globl vector25
vector25:
  pushl $0
801061d8:	6a 00                	push   $0x0
  pushl $25
801061da:	6a 19                	push   $0x19
  jmp alltraps
801061dc:	e9 be f9 ff ff       	jmp    80105b9f <alltraps>

801061e1 <vector26>:
.globl vector26
vector26:
  pushl $0
801061e1:	6a 00                	push   $0x0
  pushl $26
801061e3:	6a 1a                	push   $0x1a
  jmp alltraps
801061e5:	e9 b5 f9 ff ff       	jmp    80105b9f <alltraps>

801061ea <vector27>:
.globl vector27
vector27:
  pushl $0
801061ea:	6a 00                	push   $0x0
  pushl $27
801061ec:	6a 1b                	push   $0x1b
  jmp alltraps
801061ee:	e9 ac f9 ff ff       	jmp    80105b9f <alltraps>

801061f3 <vector28>:
.globl vector28
vector28:
  pushl $0
801061f3:	6a 00                	push   $0x0
  pushl $28
801061f5:	6a 1c                	push   $0x1c
  jmp alltraps
801061f7:	e9 a3 f9 ff ff       	jmp    80105b9f <alltraps>

801061fc <vector29>:
.globl vector29
vector29:
  pushl $0
801061fc:	6a 00                	push   $0x0
  pushl $29
801061fe:	6a 1d                	push   $0x1d
  jmp alltraps
80106200:	e9 9a f9 ff ff       	jmp    80105b9f <alltraps>

80106205 <vector30>:
.globl vector30
vector30:
  pushl $0
80106205:	6a 00                	push   $0x0
  pushl $30
80106207:	6a 1e                	push   $0x1e
  jmp alltraps
80106209:	e9 91 f9 ff ff       	jmp    80105b9f <alltraps>

8010620e <vector31>:
.globl vector31
vector31:
  pushl $0
8010620e:	6a 00                	push   $0x0
  pushl $31
80106210:	6a 1f                	push   $0x1f
  jmp alltraps
80106212:	e9 88 f9 ff ff       	jmp    80105b9f <alltraps>

80106217 <vector32>:
.globl vector32
vector32:
  pushl $0
80106217:	6a 00                	push   $0x0
  pushl $32
80106219:	6a 20                	push   $0x20
  jmp alltraps
8010621b:	e9 7f f9 ff ff       	jmp    80105b9f <alltraps>

80106220 <vector33>:
.globl vector33
vector33:
  pushl $0
80106220:	6a 00                	push   $0x0
  pushl $33
80106222:	6a 21                	push   $0x21
  jmp alltraps
80106224:	e9 76 f9 ff ff       	jmp    80105b9f <alltraps>

80106229 <vector34>:
.globl vector34
vector34:
  pushl $0
80106229:	6a 00                	push   $0x0
  pushl $34
8010622b:	6a 22                	push   $0x22
  jmp alltraps
8010622d:	e9 6d f9 ff ff       	jmp    80105b9f <alltraps>

80106232 <vector35>:
.globl vector35
vector35:
  pushl $0
80106232:	6a 00                	push   $0x0
  pushl $35
80106234:	6a 23                	push   $0x23
  jmp alltraps
80106236:	e9 64 f9 ff ff       	jmp    80105b9f <alltraps>

8010623b <vector36>:
.globl vector36
vector36:
  pushl $0
8010623b:	6a 00                	push   $0x0
  pushl $36
8010623d:	6a 24                	push   $0x24
  jmp alltraps
8010623f:	e9 5b f9 ff ff       	jmp    80105b9f <alltraps>

80106244 <vector37>:
.globl vector37
vector37:
  pushl $0
80106244:	6a 00                	push   $0x0
  pushl $37
80106246:	6a 25                	push   $0x25
  jmp alltraps
80106248:	e9 52 f9 ff ff       	jmp    80105b9f <alltraps>

8010624d <vector38>:
.globl vector38
vector38:
  pushl $0
8010624d:	6a 00                	push   $0x0
  pushl $38
8010624f:	6a 26                	push   $0x26
  jmp alltraps
80106251:	e9 49 f9 ff ff       	jmp    80105b9f <alltraps>

80106256 <vector39>:
.globl vector39
vector39:
  pushl $0
80106256:	6a 00                	push   $0x0
  pushl $39
80106258:	6a 27                	push   $0x27
  jmp alltraps
8010625a:	e9 40 f9 ff ff       	jmp    80105b9f <alltraps>

8010625f <vector40>:
.globl vector40
vector40:
  pushl $0
8010625f:	6a 00                	push   $0x0
  pushl $40
80106261:	6a 28                	push   $0x28
  jmp alltraps
80106263:	e9 37 f9 ff ff       	jmp    80105b9f <alltraps>

80106268 <vector41>:
.globl vector41
vector41:
  pushl $0
80106268:	6a 00                	push   $0x0
  pushl $41
8010626a:	6a 29                	push   $0x29
  jmp alltraps
8010626c:	e9 2e f9 ff ff       	jmp    80105b9f <alltraps>

80106271 <vector42>:
.globl vector42
vector42:
  pushl $0
80106271:	6a 00                	push   $0x0
  pushl $42
80106273:	6a 2a                	push   $0x2a
  jmp alltraps
80106275:	e9 25 f9 ff ff       	jmp    80105b9f <alltraps>

8010627a <vector43>:
.globl vector43
vector43:
  pushl $0
8010627a:	6a 00                	push   $0x0
  pushl $43
8010627c:	6a 2b                	push   $0x2b
  jmp alltraps
8010627e:	e9 1c f9 ff ff       	jmp    80105b9f <alltraps>

80106283 <vector44>:
.globl vector44
vector44:
  pushl $0
80106283:	6a 00                	push   $0x0
  pushl $44
80106285:	6a 2c                	push   $0x2c
  jmp alltraps
80106287:	e9 13 f9 ff ff       	jmp    80105b9f <alltraps>

8010628c <vector45>:
.globl vector45
vector45:
  pushl $0
8010628c:	6a 00                	push   $0x0
  pushl $45
8010628e:	6a 2d                	push   $0x2d
  jmp alltraps
80106290:	e9 0a f9 ff ff       	jmp    80105b9f <alltraps>

80106295 <vector46>:
.globl vector46
vector46:
  pushl $0
80106295:	6a 00                	push   $0x0
  pushl $46
80106297:	6a 2e                	push   $0x2e
  jmp alltraps
80106299:	e9 01 f9 ff ff       	jmp    80105b9f <alltraps>

8010629e <vector47>:
.globl vector47
vector47:
  pushl $0
8010629e:	6a 00                	push   $0x0
  pushl $47
801062a0:	6a 2f                	push   $0x2f
  jmp alltraps
801062a2:	e9 f8 f8 ff ff       	jmp    80105b9f <alltraps>

801062a7 <vector48>:
.globl vector48
vector48:
  pushl $0
801062a7:	6a 00                	push   $0x0
  pushl $48
801062a9:	6a 30                	push   $0x30
  jmp alltraps
801062ab:	e9 ef f8 ff ff       	jmp    80105b9f <alltraps>

801062b0 <vector49>:
.globl vector49
vector49:
  pushl $0
801062b0:	6a 00                	push   $0x0
  pushl $49
801062b2:	6a 31                	push   $0x31
  jmp alltraps
801062b4:	e9 e6 f8 ff ff       	jmp    80105b9f <alltraps>

801062b9 <vector50>:
.globl vector50
vector50:
  pushl $0
801062b9:	6a 00                	push   $0x0
  pushl $50
801062bb:	6a 32                	push   $0x32
  jmp alltraps
801062bd:	e9 dd f8 ff ff       	jmp    80105b9f <alltraps>

801062c2 <vector51>:
.globl vector51
vector51:
  pushl $0
801062c2:	6a 00                	push   $0x0
  pushl $51
801062c4:	6a 33                	push   $0x33
  jmp alltraps
801062c6:	e9 d4 f8 ff ff       	jmp    80105b9f <alltraps>

801062cb <vector52>:
.globl vector52
vector52:
  pushl $0
801062cb:	6a 00                	push   $0x0
  pushl $52
801062cd:	6a 34                	push   $0x34
  jmp alltraps
801062cf:	e9 cb f8 ff ff       	jmp    80105b9f <alltraps>

801062d4 <vector53>:
.globl vector53
vector53:
  pushl $0
801062d4:	6a 00                	push   $0x0
  pushl $53
801062d6:	6a 35                	push   $0x35
  jmp alltraps
801062d8:	e9 c2 f8 ff ff       	jmp    80105b9f <alltraps>

801062dd <vector54>:
.globl vector54
vector54:
  pushl $0
801062dd:	6a 00                	push   $0x0
  pushl $54
801062df:	6a 36                	push   $0x36
  jmp alltraps
801062e1:	e9 b9 f8 ff ff       	jmp    80105b9f <alltraps>

801062e6 <vector55>:
.globl vector55
vector55:
  pushl $0
801062e6:	6a 00                	push   $0x0
  pushl $55
801062e8:	6a 37                	push   $0x37
  jmp alltraps
801062ea:	e9 b0 f8 ff ff       	jmp    80105b9f <alltraps>

801062ef <vector56>:
.globl vector56
vector56:
  pushl $0
801062ef:	6a 00                	push   $0x0
  pushl $56
801062f1:	6a 38                	push   $0x38
  jmp alltraps
801062f3:	e9 a7 f8 ff ff       	jmp    80105b9f <alltraps>

801062f8 <vector57>:
.globl vector57
vector57:
  pushl $0
801062f8:	6a 00                	push   $0x0
  pushl $57
801062fa:	6a 39                	push   $0x39
  jmp alltraps
801062fc:	e9 9e f8 ff ff       	jmp    80105b9f <alltraps>

80106301 <vector58>:
.globl vector58
vector58:
  pushl $0
80106301:	6a 00                	push   $0x0
  pushl $58
80106303:	6a 3a                	push   $0x3a
  jmp alltraps
80106305:	e9 95 f8 ff ff       	jmp    80105b9f <alltraps>

8010630a <vector59>:
.globl vector59
vector59:
  pushl $0
8010630a:	6a 00                	push   $0x0
  pushl $59
8010630c:	6a 3b                	push   $0x3b
  jmp alltraps
8010630e:	e9 8c f8 ff ff       	jmp    80105b9f <alltraps>

80106313 <vector60>:
.globl vector60
vector60:
  pushl $0
80106313:	6a 00                	push   $0x0
  pushl $60
80106315:	6a 3c                	push   $0x3c
  jmp alltraps
80106317:	e9 83 f8 ff ff       	jmp    80105b9f <alltraps>

8010631c <vector61>:
.globl vector61
vector61:
  pushl $0
8010631c:	6a 00                	push   $0x0
  pushl $61
8010631e:	6a 3d                	push   $0x3d
  jmp alltraps
80106320:	e9 7a f8 ff ff       	jmp    80105b9f <alltraps>

80106325 <vector62>:
.globl vector62
vector62:
  pushl $0
80106325:	6a 00                	push   $0x0
  pushl $62
80106327:	6a 3e                	push   $0x3e
  jmp alltraps
80106329:	e9 71 f8 ff ff       	jmp    80105b9f <alltraps>

8010632e <vector63>:
.globl vector63
vector63:
  pushl $0
8010632e:	6a 00                	push   $0x0
  pushl $63
80106330:	6a 3f                	push   $0x3f
  jmp alltraps
80106332:	e9 68 f8 ff ff       	jmp    80105b9f <alltraps>

80106337 <vector64>:
.globl vector64
vector64:
  pushl $0
80106337:	6a 00                	push   $0x0
  pushl $64
80106339:	6a 40                	push   $0x40
  jmp alltraps
8010633b:	e9 5f f8 ff ff       	jmp    80105b9f <alltraps>

80106340 <vector65>:
.globl vector65
vector65:
  pushl $0
80106340:	6a 00                	push   $0x0
  pushl $65
80106342:	6a 41                	push   $0x41
  jmp alltraps
80106344:	e9 56 f8 ff ff       	jmp    80105b9f <alltraps>

80106349 <vector66>:
.globl vector66
vector66:
  pushl $0
80106349:	6a 00                	push   $0x0
  pushl $66
8010634b:	6a 42                	push   $0x42
  jmp alltraps
8010634d:	e9 4d f8 ff ff       	jmp    80105b9f <alltraps>

80106352 <vector67>:
.globl vector67
vector67:
  pushl $0
80106352:	6a 00                	push   $0x0
  pushl $67
80106354:	6a 43                	push   $0x43
  jmp alltraps
80106356:	e9 44 f8 ff ff       	jmp    80105b9f <alltraps>

8010635b <vector68>:
.globl vector68
vector68:
  pushl $0
8010635b:	6a 00                	push   $0x0
  pushl $68
8010635d:	6a 44                	push   $0x44
  jmp alltraps
8010635f:	e9 3b f8 ff ff       	jmp    80105b9f <alltraps>

80106364 <vector69>:
.globl vector69
vector69:
  pushl $0
80106364:	6a 00                	push   $0x0
  pushl $69
80106366:	6a 45                	push   $0x45
  jmp alltraps
80106368:	e9 32 f8 ff ff       	jmp    80105b9f <alltraps>

8010636d <vector70>:
.globl vector70
vector70:
  pushl $0
8010636d:	6a 00                	push   $0x0
  pushl $70
8010636f:	6a 46                	push   $0x46
  jmp alltraps
80106371:	e9 29 f8 ff ff       	jmp    80105b9f <alltraps>

80106376 <vector71>:
.globl vector71
vector71:
  pushl $0
80106376:	6a 00                	push   $0x0
  pushl $71
80106378:	6a 47                	push   $0x47
  jmp alltraps
8010637a:	e9 20 f8 ff ff       	jmp    80105b9f <alltraps>

8010637f <vector72>:
.globl vector72
vector72:
  pushl $0
8010637f:	6a 00                	push   $0x0
  pushl $72
80106381:	6a 48                	push   $0x48
  jmp alltraps
80106383:	e9 17 f8 ff ff       	jmp    80105b9f <alltraps>

80106388 <vector73>:
.globl vector73
vector73:
  pushl $0
80106388:	6a 00                	push   $0x0
  pushl $73
8010638a:	6a 49                	push   $0x49
  jmp alltraps
8010638c:	e9 0e f8 ff ff       	jmp    80105b9f <alltraps>

80106391 <vector74>:
.globl vector74
vector74:
  pushl $0
80106391:	6a 00                	push   $0x0
  pushl $74
80106393:	6a 4a                	push   $0x4a
  jmp alltraps
80106395:	e9 05 f8 ff ff       	jmp    80105b9f <alltraps>

8010639a <vector75>:
.globl vector75
vector75:
  pushl $0
8010639a:	6a 00                	push   $0x0
  pushl $75
8010639c:	6a 4b                	push   $0x4b
  jmp alltraps
8010639e:	e9 fc f7 ff ff       	jmp    80105b9f <alltraps>

801063a3 <vector76>:
.globl vector76
vector76:
  pushl $0
801063a3:	6a 00                	push   $0x0
  pushl $76
801063a5:	6a 4c                	push   $0x4c
  jmp alltraps
801063a7:	e9 f3 f7 ff ff       	jmp    80105b9f <alltraps>

801063ac <vector77>:
.globl vector77
vector77:
  pushl $0
801063ac:	6a 00                	push   $0x0
  pushl $77
801063ae:	6a 4d                	push   $0x4d
  jmp alltraps
801063b0:	e9 ea f7 ff ff       	jmp    80105b9f <alltraps>

801063b5 <vector78>:
.globl vector78
vector78:
  pushl $0
801063b5:	6a 00                	push   $0x0
  pushl $78
801063b7:	6a 4e                	push   $0x4e
  jmp alltraps
801063b9:	e9 e1 f7 ff ff       	jmp    80105b9f <alltraps>

801063be <vector79>:
.globl vector79
vector79:
  pushl $0
801063be:	6a 00                	push   $0x0
  pushl $79
801063c0:	6a 4f                	push   $0x4f
  jmp alltraps
801063c2:	e9 d8 f7 ff ff       	jmp    80105b9f <alltraps>

801063c7 <vector80>:
.globl vector80
vector80:
  pushl $0
801063c7:	6a 00                	push   $0x0
  pushl $80
801063c9:	6a 50                	push   $0x50
  jmp alltraps
801063cb:	e9 cf f7 ff ff       	jmp    80105b9f <alltraps>

801063d0 <vector81>:
.globl vector81
vector81:
  pushl $0
801063d0:	6a 00                	push   $0x0
  pushl $81
801063d2:	6a 51                	push   $0x51
  jmp alltraps
801063d4:	e9 c6 f7 ff ff       	jmp    80105b9f <alltraps>

801063d9 <vector82>:
.globl vector82
vector82:
  pushl $0
801063d9:	6a 00                	push   $0x0
  pushl $82
801063db:	6a 52                	push   $0x52
  jmp alltraps
801063dd:	e9 bd f7 ff ff       	jmp    80105b9f <alltraps>

801063e2 <vector83>:
.globl vector83
vector83:
  pushl $0
801063e2:	6a 00                	push   $0x0
  pushl $83
801063e4:	6a 53                	push   $0x53
  jmp alltraps
801063e6:	e9 b4 f7 ff ff       	jmp    80105b9f <alltraps>

801063eb <vector84>:
.globl vector84
vector84:
  pushl $0
801063eb:	6a 00                	push   $0x0
  pushl $84
801063ed:	6a 54                	push   $0x54
  jmp alltraps
801063ef:	e9 ab f7 ff ff       	jmp    80105b9f <alltraps>

801063f4 <vector85>:
.globl vector85
vector85:
  pushl $0
801063f4:	6a 00                	push   $0x0
  pushl $85
801063f6:	6a 55                	push   $0x55
  jmp alltraps
801063f8:	e9 a2 f7 ff ff       	jmp    80105b9f <alltraps>

801063fd <vector86>:
.globl vector86
vector86:
  pushl $0
801063fd:	6a 00                	push   $0x0
  pushl $86
801063ff:	6a 56                	push   $0x56
  jmp alltraps
80106401:	e9 99 f7 ff ff       	jmp    80105b9f <alltraps>

80106406 <vector87>:
.globl vector87
vector87:
  pushl $0
80106406:	6a 00                	push   $0x0
  pushl $87
80106408:	6a 57                	push   $0x57
  jmp alltraps
8010640a:	e9 90 f7 ff ff       	jmp    80105b9f <alltraps>

8010640f <vector88>:
.globl vector88
vector88:
  pushl $0
8010640f:	6a 00                	push   $0x0
  pushl $88
80106411:	6a 58                	push   $0x58
  jmp alltraps
80106413:	e9 87 f7 ff ff       	jmp    80105b9f <alltraps>

80106418 <vector89>:
.globl vector89
vector89:
  pushl $0
80106418:	6a 00                	push   $0x0
  pushl $89
8010641a:	6a 59                	push   $0x59
  jmp alltraps
8010641c:	e9 7e f7 ff ff       	jmp    80105b9f <alltraps>

80106421 <vector90>:
.globl vector90
vector90:
  pushl $0
80106421:	6a 00                	push   $0x0
  pushl $90
80106423:	6a 5a                	push   $0x5a
  jmp alltraps
80106425:	e9 75 f7 ff ff       	jmp    80105b9f <alltraps>

8010642a <vector91>:
.globl vector91
vector91:
  pushl $0
8010642a:	6a 00                	push   $0x0
  pushl $91
8010642c:	6a 5b                	push   $0x5b
  jmp alltraps
8010642e:	e9 6c f7 ff ff       	jmp    80105b9f <alltraps>

80106433 <vector92>:
.globl vector92
vector92:
  pushl $0
80106433:	6a 00                	push   $0x0
  pushl $92
80106435:	6a 5c                	push   $0x5c
  jmp alltraps
80106437:	e9 63 f7 ff ff       	jmp    80105b9f <alltraps>

8010643c <vector93>:
.globl vector93
vector93:
  pushl $0
8010643c:	6a 00                	push   $0x0
  pushl $93
8010643e:	6a 5d                	push   $0x5d
  jmp alltraps
80106440:	e9 5a f7 ff ff       	jmp    80105b9f <alltraps>

80106445 <vector94>:
.globl vector94
vector94:
  pushl $0
80106445:	6a 00                	push   $0x0
  pushl $94
80106447:	6a 5e                	push   $0x5e
  jmp alltraps
80106449:	e9 51 f7 ff ff       	jmp    80105b9f <alltraps>

8010644e <vector95>:
.globl vector95
vector95:
  pushl $0
8010644e:	6a 00                	push   $0x0
  pushl $95
80106450:	6a 5f                	push   $0x5f
  jmp alltraps
80106452:	e9 48 f7 ff ff       	jmp    80105b9f <alltraps>

80106457 <vector96>:
.globl vector96
vector96:
  pushl $0
80106457:	6a 00                	push   $0x0
  pushl $96
80106459:	6a 60                	push   $0x60
  jmp alltraps
8010645b:	e9 3f f7 ff ff       	jmp    80105b9f <alltraps>

80106460 <vector97>:
.globl vector97
vector97:
  pushl $0
80106460:	6a 00                	push   $0x0
  pushl $97
80106462:	6a 61                	push   $0x61
  jmp alltraps
80106464:	e9 36 f7 ff ff       	jmp    80105b9f <alltraps>

80106469 <vector98>:
.globl vector98
vector98:
  pushl $0
80106469:	6a 00                	push   $0x0
  pushl $98
8010646b:	6a 62                	push   $0x62
  jmp alltraps
8010646d:	e9 2d f7 ff ff       	jmp    80105b9f <alltraps>

80106472 <vector99>:
.globl vector99
vector99:
  pushl $0
80106472:	6a 00                	push   $0x0
  pushl $99
80106474:	6a 63                	push   $0x63
  jmp alltraps
80106476:	e9 24 f7 ff ff       	jmp    80105b9f <alltraps>

8010647b <vector100>:
.globl vector100
vector100:
  pushl $0
8010647b:	6a 00                	push   $0x0
  pushl $100
8010647d:	6a 64                	push   $0x64
  jmp alltraps
8010647f:	e9 1b f7 ff ff       	jmp    80105b9f <alltraps>

80106484 <vector101>:
.globl vector101
vector101:
  pushl $0
80106484:	6a 00                	push   $0x0
  pushl $101
80106486:	6a 65                	push   $0x65
  jmp alltraps
80106488:	e9 12 f7 ff ff       	jmp    80105b9f <alltraps>

8010648d <vector102>:
.globl vector102
vector102:
  pushl $0
8010648d:	6a 00                	push   $0x0
  pushl $102
8010648f:	6a 66                	push   $0x66
  jmp alltraps
80106491:	e9 09 f7 ff ff       	jmp    80105b9f <alltraps>

80106496 <vector103>:
.globl vector103
vector103:
  pushl $0
80106496:	6a 00                	push   $0x0
  pushl $103
80106498:	6a 67                	push   $0x67
  jmp alltraps
8010649a:	e9 00 f7 ff ff       	jmp    80105b9f <alltraps>

8010649f <vector104>:
.globl vector104
vector104:
  pushl $0
8010649f:	6a 00                	push   $0x0
  pushl $104
801064a1:	6a 68                	push   $0x68
  jmp alltraps
801064a3:	e9 f7 f6 ff ff       	jmp    80105b9f <alltraps>

801064a8 <vector105>:
.globl vector105
vector105:
  pushl $0
801064a8:	6a 00                	push   $0x0
  pushl $105
801064aa:	6a 69                	push   $0x69
  jmp alltraps
801064ac:	e9 ee f6 ff ff       	jmp    80105b9f <alltraps>

801064b1 <vector106>:
.globl vector106
vector106:
  pushl $0
801064b1:	6a 00                	push   $0x0
  pushl $106
801064b3:	6a 6a                	push   $0x6a
  jmp alltraps
801064b5:	e9 e5 f6 ff ff       	jmp    80105b9f <alltraps>

801064ba <vector107>:
.globl vector107
vector107:
  pushl $0
801064ba:	6a 00                	push   $0x0
  pushl $107
801064bc:	6a 6b                	push   $0x6b
  jmp alltraps
801064be:	e9 dc f6 ff ff       	jmp    80105b9f <alltraps>

801064c3 <vector108>:
.globl vector108
vector108:
  pushl $0
801064c3:	6a 00                	push   $0x0
  pushl $108
801064c5:	6a 6c                	push   $0x6c
  jmp alltraps
801064c7:	e9 d3 f6 ff ff       	jmp    80105b9f <alltraps>

801064cc <vector109>:
.globl vector109
vector109:
  pushl $0
801064cc:	6a 00                	push   $0x0
  pushl $109
801064ce:	6a 6d                	push   $0x6d
  jmp alltraps
801064d0:	e9 ca f6 ff ff       	jmp    80105b9f <alltraps>

801064d5 <vector110>:
.globl vector110
vector110:
  pushl $0
801064d5:	6a 00                	push   $0x0
  pushl $110
801064d7:	6a 6e                	push   $0x6e
  jmp alltraps
801064d9:	e9 c1 f6 ff ff       	jmp    80105b9f <alltraps>

801064de <vector111>:
.globl vector111
vector111:
  pushl $0
801064de:	6a 00                	push   $0x0
  pushl $111
801064e0:	6a 6f                	push   $0x6f
  jmp alltraps
801064e2:	e9 b8 f6 ff ff       	jmp    80105b9f <alltraps>

801064e7 <vector112>:
.globl vector112
vector112:
  pushl $0
801064e7:	6a 00                	push   $0x0
  pushl $112
801064e9:	6a 70                	push   $0x70
  jmp alltraps
801064eb:	e9 af f6 ff ff       	jmp    80105b9f <alltraps>

801064f0 <vector113>:
.globl vector113
vector113:
  pushl $0
801064f0:	6a 00                	push   $0x0
  pushl $113
801064f2:	6a 71                	push   $0x71
  jmp alltraps
801064f4:	e9 a6 f6 ff ff       	jmp    80105b9f <alltraps>

801064f9 <vector114>:
.globl vector114
vector114:
  pushl $0
801064f9:	6a 00                	push   $0x0
  pushl $114
801064fb:	6a 72                	push   $0x72
  jmp alltraps
801064fd:	e9 9d f6 ff ff       	jmp    80105b9f <alltraps>

80106502 <vector115>:
.globl vector115
vector115:
  pushl $0
80106502:	6a 00                	push   $0x0
  pushl $115
80106504:	6a 73                	push   $0x73
  jmp alltraps
80106506:	e9 94 f6 ff ff       	jmp    80105b9f <alltraps>

8010650b <vector116>:
.globl vector116
vector116:
  pushl $0
8010650b:	6a 00                	push   $0x0
  pushl $116
8010650d:	6a 74                	push   $0x74
  jmp alltraps
8010650f:	e9 8b f6 ff ff       	jmp    80105b9f <alltraps>

80106514 <vector117>:
.globl vector117
vector117:
  pushl $0
80106514:	6a 00                	push   $0x0
  pushl $117
80106516:	6a 75                	push   $0x75
  jmp alltraps
80106518:	e9 82 f6 ff ff       	jmp    80105b9f <alltraps>

8010651d <vector118>:
.globl vector118
vector118:
  pushl $0
8010651d:	6a 00                	push   $0x0
  pushl $118
8010651f:	6a 76                	push   $0x76
  jmp alltraps
80106521:	e9 79 f6 ff ff       	jmp    80105b9f <alltraps>

80106526 <vector119>:
.globl vector119
vector119:
  pushl $0
80106526:	6a 00                	push   $0x0
  pushl $119
80106528:	6a 77                	push   $0x77
  jmp alltraps
8010652a:	e9 70 f6 ff ff       	jmp    80105b9f <alltraps>

8010652f <vector120>:
.globl vector120
vector120:
  pushl $0
8010652f:	6a 00                	push   $0x0
  pushl $120
80106531:	6a 78                	push   $0x78
  jmp alltraps
80106533:	e9 67 f6 ff ff       	jmp    80105b9f <alltraps>

80106538 <vector121>:
.globl vector121
vector121:
  pushl $0
80106538:	6a 00                	push   $0x0
  pushl $121
8010653a:	6a 79                	push   $0x79
  jmp alltraps
8010653c:	e9 5e f6 ff ff       	jmp    80105b9f <alltraps>

80106541 <vector122>:
.globl vector122
vector122:
  pushl $0
80106541:	6a 00                	push   $0x0
  pushl $122
80106543:	6a 7a                	push   $0x7a
  jmp alltraps
80106545:	e9 55 f6 ff ff       	jmp    80105b9f <alltraps>

8010654a <vector123>:
.globl vector123
vector123:
  pushl $0
8010654a:	6a 00                	push   $0x0
  pushl $123
8010654c:	6a 7b                	push   $0x7b
  jmp alltraps
8010654e:	e9 4c f6 ff ff       	jmp    80105b9f <alltraps>

80106553 <vector124>:
.globl vector124
vector124:
  pushl $0
80106553:	6a 00                	push   $0x0
  pushl $124
80106555:	6a 7c                	push   $0x7c
  jmp alltraps
80106557:	e9 43 f6 ff ff       	jmp    80105b9f <alltraps>

8010655c <vector125>:
.globl vector125
vector125:
  pushl $0
8010655c:	6a 00                	push   $0x0
  pushl $125
8010655e:	6a 7d                	push   $0x7d
  jmp alltraps
80106560:	e9 3a f6 ff ff       	jmp    80105b9f <alltraps>

80106565 <vector126>:
.globl vector126
vector126:
  pushl $0
80106565:	6a 00                	push   $0x0
  pushl $126
80106567:	6a 7e                	push   $0x7e
  jmp alltraps
80106569:	e9 31 f6 ff ff       	jmp    80105b9f <alltraps>

8010656e <vector127>:
.globl vector127
vector127:
  pushl $0
8010656e:	6a 00                	push   $0x0
  pushl $127
80106570:	6a 7f                	push   $0x7f
  jmp alltraps
80106572:	e9 28 f6 ff ff       	jmp    80105b9f <alltraps>

80106577 <vector128>:
.globl vector128
vector128:
  pushl $0
80106577:	6a 00                	push   $0x0
  pushl $128
80106579:	68 80 00 00 00       	push   $0x80
  jmp alltraps
8010657e:	e9 1c f6 ff ff       	jmp    80105b9f <alltraps>

80106583 <vector129>:
.globl vector129
vector129:
  pushl $0
80106583:	6a 00                	push   $0x0
  pushl $129
80106585:	68 81 00 00 00       	push   $0x81
  jmp alltraps
8010658a:	e9 10 f6 ff ff       	jmp    80105b9f <alltraps>

8010658f <vector130>:
.globl vector130
vector130:
  pushl $0
8010658f:	6a 00                	push   $0x0
  pushl $130
80106591:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80106596:	e9 04 f6 ff ff       	jmp    80105b9f <alltraps>

8010659b <vector131>:
.globl vector131
vector131:
  pushl $0
8010659b:	6a 00                	push   $0x0
  pushl $131
8010659d:	68 83 00 00 00       	push   $0x83
  jmp alltraps
801065a2:	e9 f8 f5 ff ff       	jmp    80105b9f <alltraps>

801065a7 <vector132>:
.globl vector132
vector132:
  pushl $0
801065a7:	6a 00                	push   $0x0
  pushl $132
801065a9:	68 84 00 00 00       	push   $0x84
  jmp alltraps
801065ae:	e9 ec f5 ff ff       	jmp    80105b9f <alltraps>

801065b3 <vector133>:
.globl vector133
vector133:
  pushl $0
801065b3:	6a 00                	push   $0x0
  pushl $133
801065b5:	68 85 00 00 00       	push   $0x85
  jmp alltraps
801065ba:	e9 e0 f5 ff ff       	jmp    80105b9f <alltraps>

801065bf <vector134>:
.globl vector134
vector134:
  pushl $0
801065bf:	6a 00                	push   $0x0
  pushl $134
801065c1:	68 86 00 00 00       	push   $0x86
  jmp alltraps
801065c6:	e9 d4 f5 ff ff       	jmp    80105b9f <alltraps>

801065cb <vector135>:
.globl vector135
vector135:
  pushl $0
801065cb:	6a 00                	push   $0x0
  pushl $135
801065cd:	68 87 00 00 00       	push   $0x87
  jmp alltraps
801065d2:	e9 c8 f5 ff ff       	jmp    80105b9f <alltraps>

801065d7 <vector136>:
.globl vector136
vector136:
  pushl $0
801065d7:	6a 00                	push   $0x0
  pushl $136
801065d9:	68 88 00 00 00       	push   $0x88
  jmp alltraps
801065de:	e9 bc f5 ff ff       	jmp    80105b9f <alltraps>

801065e3 <vector137>:
.globl vector137
vector137:
  pushl $0
801065e3:	6a 00                	push   $0x0
  pushl $137
801065e5:	68 89 00 00 00       	push   $0x89
  jmp alltraps
801065ea:	e9 b0 f5 ff ff       	jmp    80105b9f <alltraps>

801065ef <vector138>:
.globl vector138
vector138:
  pushl $0
801065ef:	6a 00                	push   $0x0
  pushl $138
801065f1:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
801065f6:	e9 a4 f5 ff ff       	jmp    80105b9f <alltraps>

801065fb <vector139>:
.globl vector139
vector139:
  pushl $0
801065fb:	6a 00                	push   $0x0
  pushl $139
801065fd:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
80106602:	e9 98 f5 ff ff       	jmp    80105b9f <alltraps>

80106607 <vector140>:
.globl vector140
vector140:
  pushl $0
80106607:	6a 00                	push   $0x0
  pushl $140
80106609:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
8010660e:	e9 8c f5 ff ff       	jmp    80105b9f <alltraps>

80106613 <vector141>:
.globl vector141
vector141:
  pushl $0
80106613:	6a 00                	push   $0x0
  pushl $141
80106615:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
8010661a:	e9 80 f5 ff ff       	jmp    80105b9f <alltraps>

8010661f <vector142>:
.globl vector142
vector142:
  pushl $0
8010661f:	6a 00                	push   $0x0
  pushl $142
80106621:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
80106626:	e9 74 f5 ff ff       	jmp    80105b9f <alltraps>

8010662b <vector143>:
.globl vector143
vector143:
  pushl $0
8010662b:	6a 00                	push   $0x0
  pushl $143
8010662d:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80106632:	e9 68 f5 ff ff       	jmp    80105b9f <alltraps>

80106637 <vector144>:
.globl vector144
vector144:
  pushl $0
80106637:	6a 00                	push   $0x0
  pushl $144
80106639:	68 90 00 00 00       	push   $0x90
  jmp alltraps
8010663e:	e9 5c f5 ff ff       	jmp    80105b9f <alltraps>

80106643 <vector145>:
.globl vector145
vector145:
  pushl $0
80106643:	6a 00                	push   $0x0
  pushl $145
80106645:	68 91 00 00 00       	push   $0x91
  jmp alltraps
8010664a:	e9 50 f5 ff ff       	jmp    80105b9f <alltraps>

8010664f <vector146>:
.globl vector146
vector146:
  pushl $0
8010664f:	6a 00                	push   $0x0
  pushl $146
80106651:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80106656:	e9 44 f5 ff ff       	jmp    80105b9f <alltraps>

8010665b <vector147>:
.globl vector147
vector147:
  pushl $0
8010665b:	6a 00                	push   $0x0
  pushl $147
8010665d:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80106662:	e9 38 f5 ff ff       	jmp    80105b9f <alltraps>

80106667 <vector148>:
.globl vector148
vector148:
  pushl $0
80106667:	6a 00                	push   $0x0
  pushl $148
80106669:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010666e:	e9 2c f5 ff ff       	jmp    80105b9f <alltraps>

80106673 <vector149>:
.globl vector149
vector149:
  pushl $0
80106673:	6a 00                	push   $0x0
  pushl $149
80106675:	68 95 00 00 00       	push   $0x95
  jmp alltraps
8010667a:	e9 20 f5 ff ff       	jmp    80105b9f <alltraps>

8010667f <vector150>:
.globl vector150
vector150:
  pushl $0
8010667f:	6a 00                	push   $0x0
  pushl $150
80106681:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80106686:	e9 14 f5 ff ff       	jmp    80105b9f <alltraps>

8010668b <vector151>:
.globl vector151
vector151:
  pushl $0
8010668b:	6a 00                	push   $0x0
  pushl $151
8010668d:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80106692:	e9 08 f5 ff ff       	jmp    80105b9f <alltraps>

80106697 <vector152>:
.globl vector152
vector152:
  pushl $0
80106697:	6a 00                	push   $0x0
  pushl $152
80106699:	68 98 00 00 00       	push   $0x98
  jmp alltraps
8010669e:	e9 fc f4 ff ff       	jmp    80105b9f <alltraps>

801066a3 <vector153>:
.globl vector153
vector153:
  pushl $0
801066a3:	6a 00                	push   $0x0
  pushl $153
801066a5:	68 99 00 00 00       	push   $0x99
  jmp alltraps
801066aa:	e9 f0 f4 ff ff       	jmp    80105b9f <alltraps>

801066af <vector154>:
.globl vector154
vector154:
  pushl $0
801066af:	6a 00                	push   $0x0
  pushl $154
801066b1:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
801066b6:	e9 e4 f4 ff ff       	jmp    80105b9f <alltraps>

801066bb <vector155>:
.globl vector155
vector155:
  pushl $0
801066bb:	6a 00                	push   $0x0
  pushl $155
801066bd:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
801066c2:	e9 d8 f4 ff ff       	jmp    80105b9f <alltraps>

801066c7 <vector156>:
.globl vector156
vector156:
  pushl $0
801066c7:	6a 00                	push   $0x0
  pushl $156
801066c9:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
801066ce:	e9 cc f4 ff ff       	jmp    80105b9f <alltraps>

801066d3 <vector157>:
.globl vector157
vector157:
  pushl $0
801066d3:	6a 00                	push   $0x0
  pushl $157
801066d5:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
801066da:	e9 c0 f4 ff ff       	jmp    80105b9f <alltraps>

801066df <vector158>:
.globl vector158
vector158:
  pushl $0
801066df:	6a 00                	push   $0x0
  pushl $158
801066e1:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
801066e6:	e9 b4 f4 ff ff       	jmp    80105b9f <alltraps>

801066eb <vector159>:
.globl vector159
vector159:
  pushl $0
801066eb:	6a 00                	push   $0x0
  pushl $159
801066ed:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
801066f2:	e9 a8 f4 ff ff       	jmp    80105b9f <alltraps>

801066f7 <vector160>:
.globl vector160
vector160:
  pushl $0
801066f7:	6a 00                	push   $0x0
  pushl $160
801066f9:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
801066fe:	e9 9c f4 ff ff       	jmp    80105b9f <alltraps>

80106703 <vector161>:
.globl vector161
vector161:
  pushl $0
80106703:	6a 00                	push   $0x0
  pushl $161
80106705:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
8010670a:	e9 90 f4 ff ff       	jmp    80105b9f <alltraps>

8010670f <vector162>:
.globl vector162
vector162:
  pushl $0
8010670f:	6a 00                	push   $0x0
  pushl $162
80106711:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
80106716:	e9 84 f4 ff ff       	jmp    80105b9f <alltraps>

8010671b <vector163>:
.globl vector163
vector163:
  pushl $0
8010671b:	6a 00                	push   $0x0
  pushl $163
8010671d:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
80106722:	e9 78 f4 ff ff       	jmp    80105b9f <alltraps>

80106727 <vector164>:
.globl vector164
vector164:
  pushl $0
80106727:	6a 00                	push   $0x0
  pushl $164
80106729:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
8010672e:	e9 6c f4 ff ff       	jmp    80105b9f <alltraps>

80106733 <vector165>:
.globl vector165
vector165:
  pushl $0
80106733:	6a 00                	push   $0x0
  pushl $165
80106735:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
8010673a:	e9 60 f4 ff ff       	jmp    80105b9f <alltraps>

8010673f <vector166>:
.globl vector166
vector166:
  pushl $0
8010673f:	6a 00                	push   $0x0
  pushl $166
80106741:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80106746:	e9 54 f4 ff ff       	jmp    80105b9f <alltraps>

8010674b <vector167>:
.globl vector167
vector167:
  pushl $0
8010674b:	6a 00                	push   $0x0
  pushl $167
8010674d:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80106752:	e9 48 f4 ff ff       	jmp    80105b9f <alltraps>

80106757 <vector168>:
.globl vector168
vector168:
  pushl $0
80106757:	6a 00                	push   $0x0
  pushl $168
80106759:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
8010675e:	e9 3c f4 ff ff       	jmp    80105b9f <alltraps>

80106763 <vector169>:
.globl vector169
vector169:
  pushl $0
80106763:	6a 00                	push   $0x0
  pushl $169
80106765:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
8010676a:	e9 30 f4 ff ff       	jmp    80105b9f <alltraps>

8010676f <vector170>:
.globl vector170
vector170:
  pushl $0
8010676f:	6a 00                	push   $0x0
  pushl $170
80106771:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80106776:	e9 24 f4 ff ff       	jmp    80105b9f <alltraps>

8010677b <vector171>:
.globl vector171
vector171:
  pushl $0
8010677b:	6a 00                	push   $0x0
  pushl $171
8010677d:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80106782:	e9 18 f4 ff ff       	jmp    80105b9f <alltraps>

80106787 <vector172>:
.globl vector172
vector172:
  pushl $0
80106787:	6a 00                	push   $0x0
  pushl $172
80106789:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
8010678e:	e9 0c f4 ff ff       	jmp    80105b9f <alltraps>

80106793 <vector173>:
.globl vector173
vector173:
  pushl $0
80106793:	6a 00                	push   $0x0
  pushl $173
80106795:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
8010679a:	e9 00 f4 ff ff       	jmp    80105b9f <alltraps>

8010679f <vector174>:
.globl vector174
vector174:
  pushl $0
8010679f:	6a 00                	push   $0x0
  pushl $174
801067a1:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
801067a6:	e9 f4 f3 ff ff       	jmp    80105b9f <alltraps>

801067ab <vector175>:
.globl vector175
vector175:
  pushl $0
801067ab:	6a 00                	push   $0x0
  pushl $175
801067ad:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
801067b2:	e9 e8 f3 ff ff       	jmp    80105b9f <alltraps>

801067b7 <vector176>:
.globl vector176
vector176:
  pushl $0
801067b7:	6a 00                	push   $0x0
  pushl $176
801067b9:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
801067be:	e9 dc f3 ff ff       	jmp    80105b9f <alltraps>

801067c3 <vector177>:
.globl vector177
vector177:
  pushl $0
801067c3:	6a 00                	push   $0x0
  pushl $177
801067c5:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
801067ca:	e9 d0 f3 ff ff       	jmp    80105b9f <alltraps>

801067cf <vector178>:
.globl vector178
vector178:
  pushl $0
801067cf:	6a 00                	push   $0x0
  pushl $178
801067d1:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
801067d6:	e9 c4 f3 ff ff       	jmp    80105b9f <alltraps>

801067db <vector179>:
.globl vector179
vector179:
  pushl $0
801067db:	6a 00                	push   $0x0
  pushl $179
801067dd:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
801067e2:	e9 b8 f3 ff ff       	jmp    80105b9f <alltraps>

801067e7 <vector180>:
.globl vector180
vector180:
  pushl $0
801067e7:	6a 00                	push   $0x0
  pushl $180
801067e9:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
801067ee:	e9 ac f3 ff ff       	jmp    80105b9f <alltraps>

801067f3 <vector181>:
.globl vector181
vector181:
  pushl $0
801067f3:	6a 00                	push   $0x0
  pushl $181
801067f5:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
801067fa:	e9 a0 f3 ff ff       	jmp    80105b9f <alltraps>

801067ff <vector182>:
.globl vector182
vector182:
  pushl $0
801067ff:	6a 00                	push   $0x0
  pushl $182
80106801:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
80106806:	e9 94 f3 ff ff       	jmp    80105b9f <alltraps>

8010680b <vector183>:
.globl vector183
vector183:
  pushl $0
8010680b:	6a 00                	push   $0x0
  pushl $183
8010680d:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
80106812:	e9 88 f3 ff ff       	jmp    80105b9f <alltraps>

80106817 <vector184>:
.globl vector184
vector184:
  pushl $0
80106817:	6a 00                	push   $0x0
  pushl $184
80106819:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
8010681e:	e9 7c f3 ff ff       	jmp    80105b9f <alltraps>

80106823 <vector185>:
.globl vector185
vector185:
  pushl $0
80106823:	6a 00                	push   $0x0
  pushl $185
80106825:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
8010682a:	e9 70 f3 ff ff       	jmp    80105b9f <alltraps>

8010682f <vector186>:
.globl vector186
vector186:
  pushl $0
8010682f:	6a 00                	push   $0x0
  pushl $186
80106831:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80106836:	e9 64 f3 ff ff       	jmp    80105b9f <alltraps>

8010683b <vector187>:
.globl vector187
vector187:
  pushl $0
8010683b:	6a 00                	push   $0x0
  pushl $187
8010683d:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80106842:	e9 58 f3 ff ff       	jmp    80105b9f <alltraps>

80106847 <vector188>:
.globl vector188
vector188:
  pushl $0
80106847:	6a 00                	push   $0x0
  pushl $188
80106849:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
8010684e:	e9 4c f3 ff ff       	jmp    80105b9f <alltraps>

80106853 <vector189>:
.globl vector189
vector189:
  pushl $0
80106853:	6a 00                	push   $0x0
  pushl $189
80106855:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
8010685a:	e9 40 f3 ff ff       	jmp    80105b9f <alltraps>

8010685f <vector190>:
.globl vector190
vector190:
  pushl $0
8010685f:	6a 00                	push   $0x0
  pushl $190
80106861:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80106866:	e9 34 f3 ff ff       	jmp    80105b9f <alltraps>

8010686b <vector191>:
.globl vector191
vector191:
  pushl $0
8010686b:	6a 00                	push   $0x0
  pushl $191
8010686d:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80106872:	e9 28 f3 ff ff       	jmp    80105b9f <alltraps>

80106877 <vector192>:
.globl vector192
vector192:
  pushl $0
80106877:	6a 00                	push   $0x0
  pushl $192
80106879:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
8010687e:	e9 1c f3 ff ff       	jmp    80105b9f <alltraps>

80106883 <vector193>:
.globl vector193
vector193:
  pushl $0
80106883:	6a 00                	push   $0x0
  pushl $193
80106885:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
8010688a:	e9 10 f3 ff ff       	jmp    80105b9f <alltraps>

8010688f <vector194>:
.globl vector194
vector194:
  pushl $0
8010688f:	6a 00                	push   $0x0
  pushl $194
80106891:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80106896:	e9 04 f3 ff ff       	jmp    80105b9f <alltraps>

8010689b <vector195>:
.globl vector195
vector195:
  pushl $0
8010689b:	6a 00                	push   $0x0
  pushl $195
8010689d:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
801068a2:	e9 f8 f2 ff ff       	jmp    80105b9f <alltraps>

801068a7 <vector196>:
.globl vector196
vector196:
  pushl $0
801068a7:	6a 00                	push   $0x0
  pushl $196
801068a9:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
801068ae:	e9 ec f2 ff ff       	jmp    80105b9f <alltraps>

801068b3 <vector197>:
.globl vector197
vector197:
  pushl $0
801068b3:	6a 00                	push   $0x0
  pushl $197
801068b5:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
801068ba:	e9 e0 f2 ff ff       	jmp    80105b9f <alltraps>

801068bf <vector198>:
.globl vector198
vector198:
  pushl $0
801068bf:	6a 00                	push   $0x0
  pushl $198
801068c1:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
801068c6:	e9 d4 f2 ff ff       	jmp    80105b9f <alltraps>

801068cb <vector199>:
.globl vector199
vector199:
  pushl $0
801068cb:	6a 00                	push   $0x0
  pushl $199
801068cd:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
801068d2:	e9 c8 f2 ff ff       	jmp    80105b9f <alltraps>

801068d7 <vector200>:
.globl vector200
vector200:
  pushl $0
801068d7:	6a 00                	push   $0x0
  pushl $200
801068d9:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
801068de:	e9 bc f2 ff ff       	jmp    80105b9f <alltraps>

801068e3 <vector201>:
.globl vector201
vector201:
  pushl $0
801068e3:	6a 00                	push   $0x0
  pushl $201
801068e5:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
801068ea:	e9 b0 f2 ff ff       	jmp    80105b9f <alltraps>

801068ef <vector202>:
.globl vector202
vector202:
  pushl $0
801068ef:	6a 00                	push   $0x0
  pushl $202
801068f1:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
801068f6:	e9 a4 f2 ff ff       	jmp    80105b9f <alltraps>

801068fb <vector203>:
.globl vector203
vector203:
  pushl $0
801068fb:	6a 00                	push   $0x0
  pushl $203
801068fd:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
80106902:	e9 98 f2 ff ff       	jmp    80105b9f <alltraps>

80106907 <vector204>:
.globl vector204
vector204:
  pushl $0
80106907:	6a 00                	push   $0x0
  pushl $204
80106909:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
8010690e:	e9 8c f2 ff ff       	jmp    80105b9f <alltraps>

80106913 <vector205>:
.globl vector205
vector205:
  pushl $0
80106913:	6a 00                	push   $0x0
  pushl $205
80106915:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
8010691a:	e9 80 f2 ff ff       	jmp    80105b9f <alltraps>

8010691f <vector206>:
.globl vector206
vector206:
  pushl $0
8010691f:	6a 00                	push   $0x0
  pushl $206
80106921:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
80106926:	e9 74 f2 ff ff       	jmp    80105b9f <alltraps>

8010692b <vector207>:
.globl vector207
vector207:
  pushl $0
8010692b:	6a 00                	push   $0x0
  pushl $207
8010692d:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80106932:	e9 68 f2 ff ff       	jmp    80105b9f <alltraps>

80106937 <vector208>:
.globl vector208
vector208:
  pushl $0
80106937:	6a 00                	push   $0x0
  pushl $208
80106939:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
8010693e:	e9 5c f2 ff ff       	jmp    80105b9f <alltraps>

80106943 <vector209>:
.globl vector209
vector209:
  pushl $0
80106943:	6a 00                	push   $0x0
  pushl $209
80106945:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
8010694a:	e9 50 f2 ff ff       	jmp    80105b9f <alltraps>

8010694f <vector210>:
.globl vector210
vector210:
  pushl $0
8010694f:	6a 00                	push   $0x0
  pushl $210
80106951:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80106956:	e9 44 f2 ff ff       	jmp    80105b9f <alltraps>

8010695b <vector211>:
.globl vector211
vector211:
  pushl $0
8010695b:	6a 00                	push   $0x0
  pushl $211
8010695d:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80106962:	e9 38 f2 ff ff       	jmp    80105b9f <alltraps>

80106967 <vector212>:
.globl vector212
vector212:
  pushl $0
80106967:	6a 00                	push   $0x0
  pushl $212
80106969:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
8010696e:	e9 2c f2 ff ff       	jmp    80105b9f <alltraps>

80106973 <vector213>:
.globl vector213
vector213:
  pushl $0
80106973:	6a 00                	push   $0x0
  pushl $213
80106975:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
8010697a:	e9 20 f2 ff ff       	jmp    80105b9f <alltraps>

8010697f <vector214>:
.globl vector214
vector214:
  pushl $0
8010697f:	6a 00                	push   $0x0
  pushl $214
80106981:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80106986:	e9 14 f2 ff ff       	jmp    80105b9f <alltraps>

8010698b <vector215>:
.globl vector215
vector215:
  pushl $0
8010698b:	6a 00                	push   $0x0
  pushl $215
8010698d:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80106992:	e9 08 f2 ff ff       	jmp    80105b9f <alltraps>

80106997 <vector216>:
.globl vector216
vector216:
  pushl $0
80106997:	6a 00                	push   $0x0
  pushl $216
80106999:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
8010699e:	e9 fc f1 ff ff       	jmp    80105b9f <alltraps>

801069a3 <vector217>:
.globl vector217
vector217:
  pushl $0
801069a3:	6a 00                	push   $0x0
  pushl $217
801069a5:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
801069aa:	e9 f0 f1 ff ff       	jmp    80105b9f <alltraps>

801069af <vector218>:
.globl vector218
vector218:
  pushl $0
801069af:	6a 00                	push   $0x0
  pushl $218
801069b1:	68 da 00 00 00       	push   $0xda
  jmp alltraps
801069b6:	e9 e4 f1 ff ff       	jmp    80105b9f <alltraps>

801069bb <vector219>:
.globl vector219
vector219:
  pushl $0
801069bb:	6a 00                	push   $0x0
  pushl $219
801069bd:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
801069c2:	e9 d8 f1 ff ff       	jmp    80105b9f <alltraps>

801069c7 <vector220>:
.globl vector220
vector220:
  pushl $0
801069c7:	6a 00                	push   $0x0
  pushl $220
801069c9:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
801069ce:	e9 cc f1 ff ff       	jmp    80105b9f <alltraps>

801069d3 <vector221>:
.globl vector221
vector221:
  pushl $0
801069d3:	6a 00                	push   $0x0
  pushl $221
801069d5:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
801069da:	e9 c0 f1 ff ff       	jmp    80105b9f <alltraps>

801069df <vector222>:
.globl vector222
vector222:
  pushl $0
801069df:	6a 00                	push   $0x0
  pushl $222
801069e1:	68 de 00 00 00       	push   $0xde
  jmp alltraps
801069e6:	e9 b4 f1 ff ff       	jmp    80105b9f <alltraps>

801069eb <vector223>:
.globl vector223
vector223:
  pushl $0
801069eb:	6a 00                	push   $0x0
  pushl $223
801069ed:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
801069f2:	e9 a8 f1 ff ff       	jmp    80105b9f <alltraps>

801069f7 <vector224>:
.globl vector224
vector224:
  pushl $0
801069f7:	6a 00                	push   $0x0
  pushl $224
801069f9:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
801069fe:	e9 9c f1 ff ff       	jmp    80105b9f <alltraps>

80106a03 <vector225>:
.globl vector225
vector225:
  pushl $0
80106a03:	6a 00                	push   $0x0
  pushl $225
80106a05:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
80106a0a:	e9 90 f1 ff ff       	jmp    80105b9f <alltraps>

80106a0f <vector226>:
.globl vector226
vector226:
  pushl $0
80106a0f:	6a 00                	push   $0x0
  pushl $226
80106a11:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
80106a16:	e9 84 f1 ff ff       	jmp    80105b9f <alltraps>

80106a1b <vector227>:
.globl vector227
vector227:
  pushl $0
80106a1b:	6a 00                	push   $0x0
  pushl $227
80106a1d:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
80106a22:	e9 78 f1 ff ff       	jmp    80105b9f <alltraps>

80106a27 <vector228>:
.globl vector228
vector228:
  pushl $0
80106a27:	6a 00                	push   $0x0
  pushl $228
80106a29:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
80106a2e:	e9 6c f1 ff ff       	jmp    80105b9f <alltraps>

80106a33 <vector229>:
.globl vector229
vector229:
  pushl $0
80106a33:	6a 00                	push   $0x0
  pushl $229
80106a35:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
80106a3a:	e9 60 f1 ff ff       	jmp    80105b9f <alltraps>

80106a3f <vector230>:
.globl vector230
vector230:
  pushl $0
80106a3f:	6a 00                	push   $0x0
  pushl $230
80106a41:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80106a46:	e9 54 f1 ff ff       	jmp    80105b9f <alltraps>

80106a4b <vector231>:
.globl vector231
vector231:
  pushl $0
80106a4b:	6a 00                	push   $0x0
  pushl $231
80106a4d:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80106a52:	e9 48 f1 ff ff       	jmp    80105b9f <alltraps>

80106a57 <vector232>:
.globl vector232
vector232:
  pushl $0
80106a57:	6a 00                	push   $0x0
  pushl $232
80106a59:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80106a5e:	e9 3c f1 ff ff       	jmp    80105b9f <alltraps>

80106a63 <vector233>:
.globl vector233
vector233:
  pushl $0
80106a63:	6a 00                	push   $0x0
  pushl $233
80106a65:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80106a6a:	e9 30 f1 ff ff       	jmp    80105b9f <alltraps>

80106a6f <vector234>:
.globl vector234
vector234:
  pushl $0
80106a6f:	6a 00                	push   $0x0
  pushl $234
80106a71:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80106a76:	e9 24 f1 ff ff       	jmp    80105b9f <alltraps>

80106a7b <vector235>:
.globl vector235
vector235:
  pushl $0
80106a7b:	6a 00                	push   $0x0
  pushl $235
80106a7d:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80106a82:	e9 18 f1 ff ff       	jmp    80105b9f <alltraps>

80106a87 <vector236>:
.globl vector236
vector236:
  pushl $0
80106a87:	6a 00                	push   $0x0
  pushl $236
80106a89:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80106a8e:	e9 0c f1 ff ff       	jmp    80105b9f <alltraps>

80106a93 <vector237>:
.globl vector237
vector237:
  pushl $0
80106a93:	6a 00                	push   $0x0
  pushl $237
80106a95:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80106a9a:	e9 00 f1 ff ff       	jmp    80105b9f <alltraps>

80106a9f <vector238>:
.globl vector238
vector238:
  pushl $0
80106a9f:	6a 00                	push   $0x0
  pushl $238
80106aa1:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80106aa6:	e9 f4 f0 ff ff       	jmp    80105b9f <alltraps>

80106aab <vector239>:
.globl vector239
vector239:
  pushl $0
80106aab:	6a 00                	push   $0x0
  pushl $239
80106aad:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80106ab2:	e9 e8 f0 ff ff       	jmp    80105b9f <alltraps>

80106ab7 <vector240>:
.globl vector240
vector240:
  pushl $0
80106ab7:	6a 00                	push   $0x0
  pushl $240
80106ab9:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80106abe:	e9 dc f0 ff ff       	jmp    80105b9f <alltraps>

80106ac3 <vector241>:
.globl vector241
vector241:
  pushl $0
80106ac3:	6a 00                	push   $0x0
  pushl $241
80106ac5:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80106aca:	e9 d0 f0 ff ff       	jmp    80105b9f <alltraps>

80106acf <vector242>:
.globl vector242
vector242:
  pushl $0
80106acf:	6a 00                	push   $0x0
  pushl $242
80106ad1:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80106ad6:	e9 c4 f0 ff ff       	jmp    80105b9f <alltraps>

80106adb <vector243>:
.globl vector243
vector243:
  pushl $0
80106adb:	6a 00                	push   $0x0
  pushl $243
80106add:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80106ae2:	e9 b8 f0 ff ff       	jmp    80105b9f <alltraps>

80106ae7 <vector244>:
.globl vector244
vector244:
  pushl $0
80106ae7:	6a 00                	push   $0x0
  pushl $244
80106ae9:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80106aee:	e9 ac f0 ff ff       	jmp    80105b9f <alltraps>

80106af3 <vector245>:
.globl vector245
vector245:
  pushl $0
80106af3:	6a 00                	push   $0x0
  pushl $245
80106af5:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80106afa:	e9 a0 f0 ff ff       	jmp    80105b9f <alltraps>

80106aff <vector246>:
.globl vector246
vector246:
  pushl $0
80106aff:	6a 00                	push   $0x0
  pushl $246
80106b01:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80106b06:	e9 94 f0 ff ff       	jmp    80105b9f <alltraps>

80106b0b <vector247>:
.globl vector247
vector247:
  pushl $0
80106b0b:	6a 00                	push   $0x0
  pushl $247
80106b0d:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80106b12:	e9 88 f0 ff ff       	jmp    80105b9f <alltraps>

80106b17 <vector248>:
.globl vector248
vector248:
  pushl $0
80106b17:	6a 00                	push   $0x0
  pushl $248
80106b19:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80106b1e:	e9 7c f0 ff ff       	jmp    80105b9f <alltraps>

80106b23 <vector249>:
.globl vector249
vector249:
  pushl $0
80106b23:	6a 00                	push   $0x0
  pushl $249
80106b25:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80106b2a:	e9 70 f0 ff ff       	jmp    80105b9f <alltraps>

80106b2f <vector250>:
.globl vector250
vector250:
  pushl $0
80106b2f:	6a 00                	push   $0x0
  pushl $250
80106b31:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80106b36:	e9 64 f0 ff ff       	jmp    80105b9f <alltraps>

80106b3b <vector251>:
.globl vector251
vector251:
  pushl $0
80106b3b:	6a 00                	push   $0x0
  pushl $251
80106b3d:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80106b42:	e9 58 f0 ff ff       	jmp    80105b9f <alltraps>

80106b47 <vector252>:
.globl vector252
vector252:
  pushl $0
80106b47:	6a 00                	push   $0x0
  pushl $252
80106b49:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80106b4e:	e9 4c f0 ff ff       	jmp    80105b9f <alltraps>

80106b53 <vector253>:
.globl vector253
vector253:
  pushl $0
80106b53:	6a 00                	push   $0x0
  pushl $253
80106b55:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80106b5a:	e9 40 f0 ff ff       	jmp    80105b9f <alltraps>

80106b5f <vector254>:
.globl vector254
vector254:
  pushl $0
80106b5f:	6a 00                	push   $0x0
  pushl $254
80106b61:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80106b66:	e9 34 f0 ff ff       	jmp    80105b9f <alltraps>

80106b6b <vector255>:
.globl vector255
vector255:
  pushl $0
80106b6b:	6a 00                	push   $0x0
  pushl $255
80106b6d:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80106b72:	e9 28 f0 ff ff       	jmp    80105b9f <alltraps>
80106b77:	66 90                	xchg   %ax,%ax
80106b79:	66 90                	xchg   %ax,%ax
80106b7b:	66 90                	xchg   %ax,%ax
80106b7d:	66 90                	xchg   %ax,%ax
80106b7f:	90                   	nop

80106b80 <deallocuvm.part.0>:
// Deallocate user pages to bring the process size from oldsz to
// newsz. oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz. oldsz can be larger than the actual
// process size. Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106b80:	55                   	push   %ebp
80106b81:	89 e5                	mov    %esp,%ebp
80106b83:	57                   	push   %edi
80106b84:	56                   	push   %esi
80106b85:	53                   	push   %ebx
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
80106b86:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
80106b8c:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106b92:	83 ec 1c             	sub    $0x1c,%esp
  for(; a  < oldsz; a += PGSIZE){
80106b95:	39 d3                	cmp    %edx,%ebx
80106b97:	73 6c                	jae    80106c05 <deallocuvm.part.0+0x85>
80106b99:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80106b9c:	89 c6                	mov    %eax,%esi
80106b9e:	89 d7                	mov    %edx,%edi
80106ba0:	eb 28                	jmp    80106bca <deallocuvm.part.0+0x4a>
80106ba2:	eb 1c                	jmp    80106bc0 <deallocuvm.part.0+0x40>
80106ba4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80106ba8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106baf:	00 
80106bb0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106bb7:	00 
80106bb8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106bbf:	00 
    pte = walkpgdir(pgdir, (char*)a, 0);
    if(!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
80106bc0:	8d 5a 01             	lea    0x1(%edx),%ebx
80106bc3:	c1 e3 16             	shl    $0x16,%ebx
  for(; a  < oldsz; a += PGSIZE){
80106bc6:	39 fb                	cmp    %edi,%ebx
80106bc8:	73 38                	jae    80106c02 <deallocuvm.part.0+0x82>
  pde = &pgdir[PDX(va)];
80106bca:	89 da                	mov    %ebx,%edx
80106bcc:	c1 ea 16             	shr    $0x16,%edx
  if(*pde & PTE_P){
80106bcf:	8b 04 96             	mov    (%esi,%edx,4),%eax
80106bd2:	a8 01                	test   $0x1,%al
80106bd4:	74 ea                	je     80106bc0 <deallocuvm.part.0+0x40>
  return &pgtab[PTX(va)];
80106bd6:	89 d9                	mov    %ebx,%ecx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106bd8:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106bdd:	c1 e9 0a             	shr    $0xa,%ecx
80106be0:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
80106be6:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
    if(!pte)
80106bed:	85 c0                	test   %eax,%eax
80106bef:	74 cf                	je     80106bc0 <deallocuvm.part.0+0x40>
    else if((*pte & PTE_P) != 0){
80106bf1:	8b 10                	mov    (%eax),%edx
80106bf3:	f6 c2 01             	test   $0x1,%dl
80106bf6:	75 18                	jne    80106c10 <deallocuvm.part.0+0x90>
  for(; a  < oldsz; a += PGSIZE){
80106bf8:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106bfe:	39 fb                	cmp    %edi,%ebx
80106c00:	72 c8                	jb     80106bca <deallocuvm.part.0+0x4a>
80106c02:	8b 4d e0             	mov    -0x20(%ebp),%ecx
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
}
80106c05:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106c08:	89 c8                	mov    %ecx,%eax
80106c0a:	5b                   	pop    %ebx
80106c0b:	5e                   	pop    %esi
80106c0c:	5f                   	pop    %edi
80106c0d:	5d                   	pop    %ebp
80106c0e:	c3                   	ret
80106c0f:	90                   	nop
      if(pa == 0)
80106c10:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80106c16:	74 26                	je     80106c3e <deallocuvm.part.0+0xbe>
      kfree(v);
80106c18:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
80106c1b:	81 c2 00 00 00 80    	add    $0x80000000,%edx
80106c21:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(; a  < oldsz; a += PGSIZE){
80106c24:	81 c3 00 10 00 00    	add    $0x1000,%ebx
      kfree(v);
80106c2a:	52                   	push   %edx
80106c2b:	e8 90 b9 ff ff       	call   801025c0 <kfree>
      *pte = 0;
80106c30:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  for(; a  < oldsz; a += PGSIZE){
80106c33:	83 c4 10             	add    $0x10,%esp
      *pte = 0;
80106c36:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80106c3c:	eb 88                	jmp    80106bc6 <deallocuvm.part.0+0x46>
        panic("kfree");
80106c3e:	83 ec 0c             	sub    $0xc,%esp
80106c41:	68 6c 77 10 80       	push   $0x8010776c
80106c46:	e8 55 97 ff ff       	call   801003a0 <panic>
80106c4b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80106c50 <mappages>:
{
80106c50:	55                   	push   %ebp
80106c51:	89 e5                	mov    %esp,%ebp
80106c53:	57                   	push   %edi
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c54:	8d 7c 0a ff          	lea    -0x1(%edx,%ecx,1),%edi
{
80106c58:	56                   	push   %esi
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c59:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
80106c5f:	89 c6                	mov    %eax,%esi
{
80106c61:	53                   	push   %ebx
  a = (char*)PGROUNDDOWN((uint)va);
80106c62:	89 d3                	mov    %edx,%ebx
80106c64:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
{
80106c6a:	83 ec 1c             	sub    $0x1c,%esp
80106c6d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c70:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106c73:	29 d9                	sub    %ebx,%ecx
80106c75:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80106c78:	eb 42                	jmp    80106cbc <mappages+0x6c>
80106c7a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80106c80:	89 da                	mov    %ebx,%edx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106c82:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106c87:	c1 ea 0a             	shr    $0xa,%edx
80106c8a:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80106c90:	8d 94 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%edx
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80106c97:	85 d2                	test   %edx,%edx
80106c99:	74 6d                	je     80106d08 <mappages+0xb8>
    if(*pte & PTE_P)
80106c9b:	f6 02 01             	testb  $0x1,(%edx)
80106c9e:	0f 85 7e 00 00 00    	jne    80106d22 <mappages+0xd2>
    *pte = pa | perm | PTE_P;
80106ca4:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106ca7:	01 d8                	add    %ebx,%eax
80106ca9:	0b 45 0c             	or     0xc(%ebp),%eax
80106cac:	83 c8 01             	or     $0x1,%eax
80106caf:	89 02                	mov    %eax,(%edx)
    if(a == last)
80106cb1:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
80106cb4:	74 62                	je     80106d18 <mappages+0xc8>
    a += PGSIZE;
80106cb6:	81 c3 00 10 00 00    	add    $0x1000,%ebx
  pde = &pgdir[PDX(va)];
80106cbc:	89 d8                	mov    %ebx,%eax
80106cbe:	c1 e8 16             	shr    $0x16,%eax
80106cc1:	8d 3c 86             	lea    (%esi,%eax,4),%edi
  if(*pde & PTE_P){
80106cc4:	8b 07                	mov    (%edi),%eax
80106cc6:	a8 01                	test   $0x1,%al
80106cc8:	75 b6                	jne    80106c80 <mappages+0x30>
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80106cca:	e8 e1 ba ff ff       	call   801027b0 <kalloc>
80106ccf:	85 c0                	test   %eax,%eax
80106cd1:	74 35                	je     80106d08 <mappages+0xb8>
    memset(pgtab, 0, PGSIZE);
80106cd3:	83 ec 04             	sub    $0x4,%esp
80106cd6:	68 00 10 00 00       	push   $0x1000
80106cdb:	6a 00                	push   $0x0
80106cdd:	50                   	push   %eax
80106cde:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106ce1:	e8 ba dc ff ff       	call   801049a0 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106ce6:	8b 55 dc             	mov    -0x24(%ebp),%edx
  return &pgtab[PTX(va)];
80106ce9:	83 c4 10             	add    $0x10,%esp
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106cec:	8d 82 00 00 00 80    	lea    -0x80000000(%edx),%eax
80106cf2:	83 c8 07             	or     $0x7,%eax
80106cf5:	89 07                	mov    %eax,(%edi)
  return &pgtab[PTX(va)];
80106cf7:	89 d8                	mov    %ebx,%eax
80106cf9:	c1 e8 0a             	shr    $0xa,%eax
80106cfc:	25 fc 0f 00 00       	and    $0xffc,%eax
80106d01:	01 c2                	add    %eax,%edx
80106d03:	eb 96                	jmp    80106c9b <mappages+0x4b>
80106d05:	8d 76 00             	lea    0x0(%esi),%esi
}
80106d08:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80106d0b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106d10:	5b                   	pop    %ebx
80106d11:	5e                   	pop    %esi
80106d12:	5f                   	pop    %edi
80106d13:	5d                   	pop    %ebp
80106d14:	c3                   	ret
80106d15:	8d 76 00             	lea    0x0(%esi),%esi
80106d18:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80106d1b:	31 c0                	xor    %eax,%eax
}
80106d1d:	5b                   	pop    %ebx
80106d1e:	5e                   	pop    %esi
80106d1f:	5f                   	pop    %edi
80106d20:	5d                   	pop    %ebp
80106d21:	c3                   	ret
      panic("remap");
80106d22:	83 ec 0c             	sub    $0xc,%esp
80106d25:	68 a0 79 10 80       	push   $0x801079a0
80106d2a:	e8 71 96 ff ff       	call   801003a0 <panic>
80106d2f:	90                   	nop

80106d30 <seginit>:
{
80106d30:	55                   	push   %ebp
80106d31:	89 e5                	mov    %esp,%ebp
80106d33:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
80106d36:	e8 85 ce ff ff       	call   80103bc0 <cpuid>
  pd[0] = size-1;
80106d3b:	ba 2f 00 00 00       	mov    $0x2f,%edx
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
80106d40:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80106d46:	c7 80 18 18 11 80 ff 	movl   $0xffff,-0x7feee7e8(%eax)
80106d4d:	ff 00 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80106d50:	c7 80 20 18 11 80 ff 	movl   $0xffff,-0x7feee7e0(%eax)
80106d57:	ff 00 00 
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80106d5a:	c7 80 28 18 11 80 ff 	movl   $0xffff,-0x7feee7d8(%eax)
80106d61:	ff 00 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80106d64:	c7 80 30 18 11 80 ff 	movl   $0xffff,-0x7feee7d0(%eax)
80106d6b:	ff 00 00 
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
80106d6e:	c7 80 1c 18 11 80 00 	movl   $0xcf9a00,-0x7feee7e4(%eax)
80106d75:	9a cf 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80106d78:	c7 80 24 18 11 80 00 	movl   $0xcf9200,-0x7feee7dc(%eax)
80106d7f:	92 cf 00 
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80106d82:	c7 80 2c 18 11 80 00 	movl   $0xcffa00,-0x7feee7d4(%eax)
80106d89:	fa cf 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80106d8c:	c7 80 34 18 11 80 00 	movl   $0xcff200,-0x7feee7cc(%eax)
80106d93:	f2 cf 00 
  lgdt(c->gdt, sizeof(c->gdt));
80106d96:	05 10 18 11 80       	add    $0x80111810,%eax
80106d9b:	66 89 55 f2          	mov    %dx,-0xe(%ebp)
  pd[1] = (uint)p;
80106d9f:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80106da3:	c1 e8 10             	shr    $0x10,%eax
80106da6:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
80106daa:	8d 45 f2             	lea    -0xe(%ebp),%eax
80106dad:	0f 01 10             	lgdtl  (%eax)
}
80106db0:	c9                   	leave
80106db1:	c3                   	ret
80106db2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80106db8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106dbf:	00 

80106dc0 <va2pa>:
{
80106dc0:	55                   	push   %ebp
80106dc1:	89 e5                	mov    %esp,%ebp
80106dc3:	53                   	push   %ebx
80106dc4:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(va >= KERNBASE)
80106dc7:	85 c0                	test   %eax,%eax
80106dc9:	78 55                	js     80106e20 <va2pa+0x60>
  if(*pde & PTE_P){
80106dcb:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80106dce:	89 c1                	mov    %eax,%ecx
80106dd0:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80106dd3:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
    return -1;
80106dd6:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  if(*pde & PTE_P){
80106ddb:	f6 c2 01             	test   $0x1,%dl
80106dde:	74 35                	je     80106e15 <va2pa+0x55>
  return &pgtab[PTX(va)];
80106de0:	89 c3                	mov    %eax,%ebx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106de2:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
80106de8:	c1 eb 0a             	shr    $0xa,%ebx
80106deb:	81 e3 fc 0f 00 00    	and    $0xffc,%ebx
80106df1:	8d 94 1a 00 00 00 80 	lea    -0x80000000(%edx,%ebx,1),%edx
  if(pte == 0)
80106df8:	85 d2                	test   %edx,%edx
80106dfa:	74 19                	je     80106e15 <va2pa+0x55>
  if(!(*pte & PTE_P) || !(*pte & PTE_U))
80106dfc:	8b 12                	mov    (%edx),%edx
  return (int)(PTE_ADDR(*pte) | (va & (PGSIZE - 1)));
80106dfe:	25 ff 0f 00 00       	and    $0xfff,%eax
80106e03:	89 d3                	mov    %edx,%ebx
80106e05:	f7 d2                	not    %edx
80106e07:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80106e0d:	09 d8                	or     %ebx,%eax
80106e0f:	83 e2 05             	and    $0x5,%edx
80106e12:	0f 44 c8             	cmove  %eax,%ecx
}
80106e15:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80106e18:	89 c8                	mov    %ecx,%eax
80106e1a:	c9                   	leave
80106e1b:	c3                   	ret
80106e1c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80106e20:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
80106e25:	eb ee                	jmp    80106e15 <va2pa+0x55>
80106e27:	90                   	nop
80106e28:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106e2f:	00 

80106e30 <switchkvm>:
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80106e30:	a1 c4 44 11 80       	mov    0x801144c4,%eax
80106e35:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
80106e3a:	0f 22 d8             	mov    %eax,%cr3
}
80106e3d:	c3                   	ret
80106e3e:	66 90                	xchg   %ax,%ax

80106e40 <switchuvm>:
{
80106e40:	55                   	push   %ebp
80106e41:	89 e5                	mov    %esp,%ebp
80106e43:	57                   	push   %edi
80106e44:	56                   	push   %esi
80106e45:	53                   	push   %ebx
80106e46:	83 ec 1c             	sub    $0x1c,%esp
80106e49:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(p == 0)
80106e4c:	85 db                	test   %ebx,%ebx
80106e4e:	0f 84 c9 00 00 00    	je     80106f1d <switchuvm+0xdd>
  if(p->kstack == 0)
80106e54:	8b 43 08             	mov    0x8(%ebx),%eax
80106e57:	85 c0                	test   %eax,%eax
80106e59:	0f 84 d8 00 00 00    	je     80106f37 <switchuvm+0xf7>
  if(p->pgdir == 0)
80106e5f:	8b 43 04             	mov    0x4(%ebx),%eax
80106e62:	85 c0                	test   %eax,%eax
80106e64:	0f 84 c0 00 00 00    	je     80106f2a <switchuvm+0xea>
  pushcli();
80106e6a:	e8 b1 d8 ff ff       	call   80104720 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80106e6f:	e8 cc cc ff ff       	call   80103b40 <mycpu>
80106e74:	89 c6                	mov    %eax,%esi
80106e76:	e8 c5 cc ff ff       	call   80103b40 <mycpu>
80106e7b:	8d 78 08             	lea    0x8(%eax),%edi
80106e7e:	e8 bd cc ff ff       	call   80103b40 <mycpu>
80106e83:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106e86:	e8 b5 cc ff ff       	call   80103b40 <mycpu>
80106e8b:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80106e8e:	ba 67 00 00 00       	mov    $0x67,%edx
80106e93:	66 89 be 9a 00 00 00 	mov    %di,0x9a(%esi)
80106e9a:	83 c0 08             	add    $0x8,%eax
80106e9d:	66 89 96 98 00 00 00 	mov    %dx,0x98(%esi)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106ea4:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80106ea9:	83 c1 08             	add    $0x8,%ecx
80106eac:	c1 e8 18             	shr    $0x18,%eax
80106eaf:	c1 e9 10             	shr    $0x10,%ecx
80106eb2:	88 86 9f 00 00 00    	mov    %al,0x9f(%esi)
80106eb8:	88 8e 9c 00 00 00    	mov    %cl,0x9c(%esi)
80106ebe:	b9 99 40 00 00       	mov    $0x4099,%ecx
80106ec3:	66 89 8e 9d 00 00 00 	mov    %cx,0x9d(%esi)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80106eca:	be 10 00 00 00       	mov    $0x10,%esi
  mycpu()->gdt[SEG_TSS].s = 0;
80106ecf:	e8 6c cc ff ff       	call   80103b40 <mycpu>
80106ed4:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80106edb:	e8 60 cc ff ff       	call   80103b40 <mycpu>
80106ee0:	66 89 70 10          	mov    %si,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80106ee4:	8b 73 08             	mov    0x8(%ebx),%esi
80106ee7:	81 c6 00 10 00 00    	add    $0x1000,%esi
80106eed:	e8 4e cc ff ff       	call   80103b40 <mycpu>
80106ef2:	89 70 0c             	mov    %esi,0xc(%eax)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106ef5:	e8 46 cc ff ff       	call   80103b40 <mycpu>
80106efa:	66 89 78 6e          	mov    %di,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
80106efe:	b8 28 00 00 00       	mov    $0x28,%eax
80106f03:	0f 00 d8             	ltr    %eax
  lcr3(V2P(p->pgdir));  // switch to process's address space
80106f06:	8b 43 04             	mov    0x4(%ebx),%eax
80106f09:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
80106f0e:	0f 22 d8             	mov    %eax,%cr3
}
80106f11:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106f14:	5b                   	pop    %ebx
80106f15:	5e                   	pop    %esi
80106f16:	5f                   	pop    %edi
80106f17:	5d                   	pop    %ebp
  popcli();
80106f18:	e9 53 d8 ff ff       	jmp    80104770 <popcli>
    panic("switchuvm: no process");
80106f1d:	83 ec 0c             	sub    $0xc,%esp
80106f20:	68 a6 79 10 80       	push   $0x801079a6
80106f25:	e8 76 94 ff ff       	call   801003a0 <panic>
    panic("switchuvm: no pgdir");
80106f2a:	83 ec 0c             	sub    $0xc,%esp
80106f2d:	68 d1 79 10 80       	push   $0x801079d1
80106f32:	e8 69 94 ff ff       	call   801003a0 <panic>
    panic("switchuvm: no kstack");
80106f37:	83 ec 0c             	sub    $0xc,%esp
80106f3a:	68 bc 79 10 80       	push   $0x801079bc
80106f3f:	e8 5c 94 ff ff       	call   801003a0 <panic>
80106f44:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80106f48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106f4f:	00 

80106f50 <inituvm>:
{
80106f50:	55                   	push   %ebp
80106f51:	89 e5                	mov    %esp,%ebp
80106f53:	57                   	push   %edi
80106f54:	56                   	push   %esi
80106f55:	53                   	push   %ebx
80106f56:	83 ec 1c             	sub    $0x1c,%esp
80106f59:	8b 45 08             	mov    0x8(%ebp),%eax
80106f5c:	8b 75 10             	mov    0x10(%ebp),%esi
80106f5f:	8b 7d 0c             	mov    0xc(%ebp),%edi
80106f62:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(sz >= PGSIZE)
80106f65:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
80106f6b:	77 49                	ja     80106fb6 <inituvm+0x66>
  mem = kalloc();
80106f6d:	e8 3e b8 ff ff       	call   801027b0 <kalloc>
  memset(mem, 0, PGSIZE);
80106f72:	83 ec 04             	sub    $0x4,%esp
80106f75:	68 00 10 00 00       	push   $0x1000
  mem = kalloc();
80106f7a:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
80106f7c:	6a 00                	push   $0x0
80106f7e:	50                   	push   %eax
80106f7f:	e8 1c da ff ff       	call   801049a0 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
80106f84:	58                   	pop    %eax
80106f85:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80106f8b:	5a                   	pop    %edx
80106f8c:	6a 06                	push   $0x6
80106f8e:	b9 00 10 00 00       	mov    $0x1000,%ecx
80106f93:	31 d2                	xor    %edx,%edx
80106f95:	50                   	push   %eax
80106f96:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106f99:	e8 b2 fc ff ff       	call   80106c50 <mappages>
  memmove(mem, init, sz);
80106f9e:	83 c4 10             	add    $0x10,%esp
80106fa1:	89 75 10             	mov    %esi,0x10(%ebp)
80106fa4:	89 7d 0c             	mov    %edi,0xc(%ebp)
80106fa7:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80106faa:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106fad:	5b                   	pop    %ebx
80106fae:	5e                   	pop    %esi
80106faf:	5f                   	pop    %edi
80106fb0:	5d                   	pop    %ebp
  memmove(mem, init, sz);
80106fb1:	e9 7a da ff ff       	jmp    80104a30 <memmove>
    panic("inituvm: more than a page");
80106fb6:	83 ec 0c             	sub    $0xc,%esp
80106fb9:	68 e5 79 10 80       	push   $0x801079e5
80106fbe:	e8 dd 93 ff ff       	call   801003a0 <panic>
80106fc3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80106fc8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106fcf:	00 

80106fd0 <loaduvm>:
{
80106fd0:	55                   	push   %ebp
80106fd1:	89 e5                	mov    %esp,%ebp
80106fd3:	57                   	push   %edi
80106fd4:	56                   	push   %esi
80106fd5:	53                   	push   %ebx
80106fd6:	83 ec 0c             	sub    $0xc,%esp
  if((uint) addr % PGSIZE != 0)
80106fd9:	8b 75 0c             	mov    0xc(%ebp),%esi
{
80106fdc:	8b 7d 18             	mov    0x18(%ebp),%edi
  if((uint) addr % PGSIZE != 0)
80106fdf:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80106fe5:	0f 85 a2 00 00 00    	jne    8010708d <loaduvm+0xbd>
  for(i = 0; i < sz; i += PGSIZE){
80106feb:	85 ff                	test   %edi,%edi
80106fed:	74 7d                	je     8010706c <loaduvm+0x9c>
80106fef:	90                   	nop
  pde = &pgdir[PDX(va)];
80106ff0:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80106ff3:	8b 55 08             	mov    0x8(%ebp),%edx
80106ff6:	01 f0                	add    %esi,%eax
  pde = &pgdir[PDX(va)];
80106ff8:	89 c1                	mov    %eax,%ecx
80106ffa:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80106ffd:	8b 0c 8a             	mov    (%edx,%ecx,4),%ecx
80107000:	f6 c1 01             	test   $0x1,%cl
80107003:	75 13                	jne    80107018 <loaduvm+0x48>
      panic("loaduvm: address should exist");
80107005:	83 ec 0c             	sub    $0xc,%esp
80107008:	68 ff 79 10 80       	push   $0x801079ff
8010700d:	e8 8e 93 ff ff       	call   801003a0 <panic>
80107012:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80107018:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
8010701b:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
80107021:	25 fc 0f 00 00       	and    $0xffc,%eax
80107026:	8d 8c 01 00 00 00 80 	lea    -0x80000000(%ecx,%eax,1),%ecx
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
8010702d:	85 c9                	test   %ecx,%ecx
8010702f:	74 d4                	je     80107005 <loaduvm+0x35>
    if(sz - i < PGSIZE)
80107031:	89 fb                	mov    %edi,%ebx
80107033:	b8 00 10 00 00       	mov    $0x1000,%eax
80107038:	29 f3                	sub    %esi,%ebx
8010703a:	39 c3                	cmp    %eax,%ebx
8010703c:	0f 47 d8             	cmova  %eax,%ebx
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010703f:	53                   	push   %ebx
80107040:	8b 45 14             	mov    0x14(%ebp),%eax
80107043:	01 f0                	add    %esi,%eax
80107045:	50                   	push   %eax
    pa = PTE_ADDR(*pte);
80107046:	8b 01                	mov    (%ecx),%eax
80107048:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010704d:	05 00 00 00 80       	add    $0x80000000,%eax
80107052:	50                   	push   %eax
80107053:	ff 75 10             	push   0x10(%ebp)
80107056:	e8 35 ab ff ff       	call   80101b90 <readi>
8010705b:	83 c4 10             	add    $0x10,%esp
8010705e:	39 d8                	cmp    %ebx,%eax
80107060:	75 1e                	jne    80107080 <loaduvm+0xb0>
  for(i = 0; i < sz; i += PGSIZE){
80107062:	81 c6 00 10 00 00    	add    $0x1000,%esi
80107068:	39 fe                	cmp    %edi,%esi
8010706a:	72 84                	jb     80106ff0 <loaduvm+0x20>
}
8010706c:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
8010706f:	31 c0                	xor    %eax,%eax
}
80107071:	5b                   	pop    %ebx
80107072:	5e                   	pop    %esi
80107073:	5f                   	pop    %edi
80107074:	5d                   	pop    %ebp
80107075:	c3                   	ret
80107076:	66 90                	xchg   %ax,%ax
80107078:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010707f:	00 
80107080:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80107083:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80107088:	5b                   	pop    %ebx
80107089:	5e                   	pop    %esi
8010708a:	5f                   	pop    %edi
8010708b:	5d                   	pop    %ebp
8010708c:	c3                   	ret
    panic("loaduvm: addr must be page aligned");
8010708d:	83 ec 0c             	sub    $0xc,%esp
80107090:	68 00 7c 10 80       	push   $0x80107c00
80107095:	e8 06 93 ff ff       	call   801003a0 <panic>
8010709a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801070a0 <allocuvm>:
{
801070a0:	55                   	push   %ebp
801070a1:	89 e5                	mov    %esp,%ebp
801070a3:	57                   	push   %edi
801070a4:	56                   	push   %esi
801070a5:	53                   	push   %ebx
801070a6:	83 ec 1c             	sub    $0x1c,%esp
801070a9:	8b 75 10             	mov    0x10(%ebp),%esi
  if(newsz >= KERNBASE)
801070ac:	85 f6                	test   %esi,%esi
801070ae:	0f 88 99 00 00 00    	js     8010714d <allocuvm+0xad>
801070b4:	89 f2                	mov    %esi,%edx
  if(newsz < oldsz)
801070b6:	3b 75 0c             	cmp    0xc(%ebp),%esi
801070b9:	0f 82 a1 00 00 00    	jb     80107160 <allocuvm+0xc0>
  a = PGROUNDUP(oldsz);
801070bf:	8b 45 0c             	mov    0xc(%ebp),%eax
801070c2:	05 ff 0f 00 00       	add    $0xfff,%eax
801070c7:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801070cc:	89 c7                	mov    %eax,%edi
  for(; a < newsz; a += PGSIZE){
801070ce:	39 f0                	cmp    %esi,%eax
801070d0:	0f 83 8d 00 00 00    	jae    80107163 <allocuvm+0xc3>
801070d6:	89 75 e4             	mov    %esi,-0x1c(%ebp)
801070d9:	eb 45                	jmp    80107120 <allocuvm+0x80>
801070db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    memset(mem, 0, PGSIZE);
801070e0:	83 ec 04             	sub    $0x4,%esp
801070e3:	68 00 10 00 00       	push   $0x1000
801070e8:	6a 00                	push   $0x0
801070ea:	50                   	push   %eax
801070eb:	e8 b0 d8 ff ff       	call   801049a0 <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
801070f0:	58                   	pop    %eax
801070f1:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801070f7:	5a                   	pop    %edx
801070f8:	6a 06                	push   $0x6
801070fa:	b9 00 10 00 00       	mov    $0x1000,%ecx
801070ff:	89 fa                	mov    %edi,%edx
80107101:	50                   	push   %eax
80107102:	8b 45 08             	mov    0x8(%ebp),%eax
80107105:	e8 46 fb ff ff       	call   80106c50 <mappages>
8010710a:	83 c4 10             	add    $0x10,%esp
8010710d:	83 f8 ff             	cmp    $0xffffffff,%eax
80107110:	74 5e                	je     80107170 <allocuvm+0xd0>
  for(; a < newsz; a += PGSIZE){
80107112:	81 c7 00 10 00 00    	add    $0x1000,%edi
80107118:	39 f7                	cmp    %esi,%edi
8010711a:	0f 83 88 00 00 00    	jae    801071a8 <allocuvm+0x108>
    mem = kalloc();
80107120:	e8 8b b6 ff ff       	call   801027b0 <kalloc>
80107125:	89 c3                	mov    %eax,%ebx
    if(mem == 0){
80107127:	85 c0                	test   %eax,%eax
80107129:	75 b5                	jne    801070e0 <allocuvm+0x40>
      cprintf("allocuvm out of memory\n");
8010712b:	83 ec 0c             	sub    $0xc,%esp
8010712e:	68 1d 7a 10 80       	push   $0x80107a1d
80107133:	e8 98 95 ff ff       	call   801006d0 <cprintf>
  if(newsz >= oldsz)
80107138:	83 c4 10             	add    $0x10,%esp
8010713b:	3b 75 0c             	cmp    0xc(%ebp),%esi
8010713e:	74 0d                	je     8010714d <allocuvm+0xad>
80107140:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107143:	8b 45 08             	mov    0x8(%ebp),%eax
80107146:	89 f2                	mov    %esi,%edx
80107148:	e8 33 fa ff ff       	call   80106b80 <deallocuvm.part.0>
    return 0;
8010714d:	31 d2                	xor    %edx,%edx
}
8010714f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107152:	89 d0                	mov    %edx,%eax
80107154:	5b                   	pop    %ebx
80107155:	5e                   	pop    %esi
80107156:	5f                   	pop    %edi
80107157:	5d                   	pop    %ebp
80107158:	c3                   	ret
80107159:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return oldsz;
80107160:	8b 55 0c             	mov    0xc(%ebp),%edx
}
80107163:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107166:	89 d0                	mov    %edx,%eax
80107168:	5b                   	pop    %ebx
80107169:	5e                   	pop    %esi
8010716a:	5f                   	pop    %edi
8010716b:	5d                   	pop    %ebp
8010716c:	c3                   	ret
8010716d:	8d 76 00             	lea    0x0(%esi),%esi
      cprintf("allocuvm out of memory (2)\n");
80107170:	83 ec 0c             	sub    $0xc,%esp
80107173:	68 35 7a 10 80       	push   $0x80107a35
80107178:	e8 53 95 ff ff       	call   801006d0 <cprintf>
  if(newsz >= oldsz)
8010717d:	83 c4 10             	add    $0x10,%esp
80107180:	3b 75 0c             	cmp    0xc(%ebp),%esi
80107183:	74 0d                	je     80107192 <allocuvm+0xf2>
80107185:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107188:	8b 45 08             	mov    0x8(%ebp),%eax
8010718b:	89 f2                	mov    %esi,%edx
8010718d:	e8 ee f9 ff ff       	call   80106b80 <deallocuvm.part.0>
      kfree(mem);
80107192:	83 ec 0c             	sub    $0xc,%esp
80107195:	53                   	push   %ebx
80107196:	e8 25 b4 ff ff       	call   801025c0 <kfree>
      return 0;
8010719b:	83 c4 10             	add    $0x10,%esp
    return 0;
8010719e:	31 d2                	xor    %edx,%edx
801071a0:	eb ad                	jmp    8010714f <allocuvm+0xaf>
801071a2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801071a8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
}
801071ab:	8d 65 f4             	lea    -0xc(%ebp),%esp
801071ae:	5b                   	pop    %ebx
801071af:	5e                   	pop    %esi
801071b0:	89 d0                	mov    %edx,%eax
801071b2:	5f                   	pop    %edi
801071b3:	5d                   	pop    %ebp
801071b4:	c3                   	ret
801071b5:	8d 76 00             	lea    0x0(%esi),%esi
801071b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801071bf:	00 

801071c0 <deallocuvm>:
{
801071c0:	55                   	push   %ebp
801071c1:	89 e5                	mov    %esp,%ebp
801071c3:	8b 55 0c             	mov    0xc(%ebp),%edx
801071c6:	8b 4d 10             	mov    0x10(%ebp),%ecx
801071c9:	8b 45 08             	mov    0x8(%ebp),%eax
  if(newsz >= oldsz)
801071cc:	39 d1                	cmp    %edx,%ecx
801071ce:	73 10                	jae    801071e0 <deallocuvm+0x20>
}
801071d0:	5d                   	pop    %ebp
801071d1:	e9 aa f9 ff ff       	jmp    80106b80 <deallocuvm.part.0>
801071d6:	66 90                	xchg   %ax,%ax
801071d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801071df:	00 
801071e0:	89 d0                	mov    %edx,%eax
801071e2:	5d                   	pop    %ebp
801071e3:	c3                   	ret
801071e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801071e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801071ef:	00 

801071f0 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
801071f0:	55                   	push   %ebp
801071f1:	89 e5                	mov    %esp,%ebp
801071f3:	57                   	push   %edi
801071f4:	56                   	push   %esi
801071f5:	53                   	push   %ebx
801071f6:	83 ec 0c             	sub    $0xc,%esp
801071f9:	8b 75 08             	mov    0x8(%ebp),%esi
  uint i;

  if(pgdir == 0)
801071fc:	85 f6                	test   %esi,%esi
801071fe:	74 59                	je     80107259 <freevm+0x69>
  if(newsz >= oldsz)
80107200:	31 c9                	xor    %ecx,%ecx
80107202:	ba 00 00 00 80       	mov    $0x80000000,%edx
80107207:	89 f0                	mov    %esi,%eax
80107209:	89 f3                	mov    %esi,%ebx
8010720b:	e8 70 f9 ff ff       	call   80106b80 <deallocuvm.part.0>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for(i = 0; i < NPDENTRIES; i++){
80107210:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
80107216:	eb 0f                	jmp    80107227 <freevm+0x37>
80107218:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010721f:	00 
80107220:	83 c3 04             	add    $0x4,%ebx
80107223:	39 fb                	cmp    %edi,%ebx
80107225:	74 23                	je     8010724a <freevm+0x5a>
    if(pgdir[i] & PTE_P){
80107227:	8b 03                	mov    (%ebx),%eax
80107229:	a8 01                	test   $0x1,%al
8010722b:	74 f3                	je     80107220 <freevm+0x30>
      char * v = P2V(PTE_ADDR(pgdir[i]));
8010722d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      kfree(v);
80107232:	83 ec 0c             	sub    $0xc,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107235:	83 c3 04             	add    $0x4,%ebx
      char * v = P2V(PTE_ADDR(pgdir[i]));
80107238:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
8010723d:	50                   	push   %eax
8010723e:	e8 7d b3 ff ff       	call   801025c0 <kfree>
80107243:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107246:	39 fb                	cmp    %edi,%ebx
80107248:	75 dd                	jne    80107227 <freevm+0x37>
    }
  }
  kfree((char*)pgdir);
8010724a:	89 75 08             	mov    %esi,0x8(%ebp)
}
8010724d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107250:	5b                   	pop    %ebx
80107251:	5e                   	pop    %esi
80107252:	5f                   	pop    %edi
80107253:	5d                   	pop    %ebp
  kfree((char*)pgdir);
80107254:	e9 67 b3 ff ff       	jmp    801025c0 <kfree>
    panic("freevm: no pgdir");
80107259:	83 ec 0c             	sub    $0xc,%esp
8010725c:	68 51 7a 10 80       	push   $0x80107a51
80107261:	e8 3a 91 ff ff       	call   801003a0 <panic>
80107266:	66 90                	xchg   %ax,%ax
80107268:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010726f:	00 

80107270 <setupkvm>:
{
80107270:	55                   	push   %ebp
80107271:	89 e5                	mov    %esp,%ebp
80107273:	56                   	push   %esi
80107274:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
80107275:	e8 36 b5 ff ff       	call   801027b0 <kalloc>
8010727a:	85 c0                	test   %eax,%eax
8010727c:	74 5e                	je     801072dc <setupkvm+0x6c>
  memset(pgdir, 0, PGSIZE);
8010727e:	83 ec 04             	sub    $0x4,%esp
80107281:	89 c6                	mov    %eax,%esi
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107283:	bb 20 a4 10 80       	mov    $0x8010a420,%ebx
  memset(pgdir, 0, PGSIZE);
80107288:	68 00 10 00 00       	push   $0x1000
8010728d:	6a 00                	push   $0x0
8010728f:	50                   	push   %eax
80107290:	e8 0b d7 ff ff       	call   801049a0 <memset>
80107295:	83 c4 10             	add    $0x10,%esp
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
80107298:	8b 43 04             	mov    0x4(%ebx),%eax
8010729b:	83 ec 08             	sub    $0x8,%esp
8010729e:	8b 4b 08             	mov    0x8(%ebx),%ecx
801072a1:	8b 13                	mov    (%ebx),%edx
801072a3:	ff 73 0c             	push   0xc(%ebx)
801072a6:	50                   	push   %eax
801072a7:	29 c1                	sub    %eax,%ecx
801072a9:	89 f0                	mov    %esi,%eax
801072ab:	e8 a0 f9 ff ff       	call   80106c50 <mappages>
801072b0:	83 c4 10             	add    $0x10,%esp
801072b3:	83 f8 ff             	cmp    $0xffffffff,%eax
801072b6:	74 18                	je     801072d0 <setupkvm+0x60>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801072b8:	83 c3 10             	add    $0x10,%ebx
801072bb:	81 fb 60 a4 10 80    	cmp    $0x8010a460,%ebx
801072c1:	75 d5                	jne    80107298 <setupkvm+0x28>
}
801072c3:	8d 65 f8             	lea    -0x8(%ebp),%esp
801072c6:	89 f0                	mov    %esi,%eax
801072c8:	5b                   	pop    %ebx
801072c9:	5e                   	pop    %esi
801072ca:	5d                   	pop    %ebp
801072cb:	c3                   	ret
801072cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      freevm(pgdir);
801072d0:	83 ec 0c             	sub    $0xc,%esp
801072d3:	56                   	push   %esi
801072d4:	e8 17 ff ff ff       	call   801071f0 <freevm>
      return 0;
801072d9:	83 c4 10             	add    $0x10,%esp
}
801072dc:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return 0;
801072df:	31 f6                	xor    %esi,%esi
}
801072e1:	89 f0                	mov    %esi,%eax
801072e3:	5b                   	pop    %ebx
801072e4:	5e                   	pop    %esi
801072e5:	5d                   	pop    %ebp
801072e6:	c3                   	ret
801072e7:	90                   	nop
801072e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801072ef:	00 

801072f0 <kvmalloc>:
{
801072f0:	55                   	push   %ebp
801072f1:	89 e5                	mov    %esp,%ebp
801072f3:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
801072f6:	e8 75 ff ff ff       	call   80107270 <setupkvm>
801072fb:	a3 c4 44 11 80       	mov    %eax,0x801144c4
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107300:	05 00 00 00 80       	add    $0x80000000,%eax
80107305:	0f 22 d8             	mov    %eax,%cr3
}
80107308:	c9                   	leave
80107309:	c3                   	ret
8010730a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107310 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80107310:	55                   	push   %ebp
80107311:	89 e5                	mov    %esp,%ebp
80107313:	83 ec 08             	sub    $0x8,%esp
80107316:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107319:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
8010731c:	89 c1                	mov    %eax,%ecx
8010731e:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80107321:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107324:	f6 c2 01             	test   $0x1,%dl
80107327:	75 17                	jne    80107340 <clearpteu+0x30>
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if(pte == 0)
    panic("clearpteu");
80107329:	83 ec 0c             	sub    $0xc,%esp
8010732c:	68 62 7a 10 80       	push   $0x80107a62
80107331:	e8 6a 90 ff ff       	call   801003a0 <panic>
80107336:	66 90                	xchg   %ax,%ax
80107338:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010733f:	00 
  return &pgtab[PTX(va)];
80107340:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107343:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
80107349:	25 fc 0f 00 00       	and    $0xffc,%eax
8010734e:	8d 84 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%eax
  if(pte == 0)
80107355:	85 c0                	test   %eax,%eax
80107357:	74 d0                	je     80107329 <clearpteu+0x19>
  *pte &= ~PTE_U;
80107359:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
8010735c:	c9                   	leave
8010735d:	c3                   	ret
8010735e:	66 90                	xchg   %ax,%ax

80107360 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
80107360:	55                   	push   %ebp
80107361:	89 e5                	mov    %esp,%ebp
80107363:	57                   	push   %edi
80107364:	56                   	push   %esi
80107365:	53                   	push   %ebx
80107366:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
80107369:	e8 02 ff ff ff       	call   80107270 <setupkvm>
8010736e:	85 c0                	test   %eax,%eax
80107370:	0f 84 e1 00 00 00    	je     80107457 <copyuvm+0xf7>
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
80107376:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107379:	89 c2                	mov    %eax,%edx
8010737b:	85 c9                	test   %ecx,%ecx
8010737d:	0f 84 b5 00 00 00    	je     80107438 <copyuvm+0xd8>
80107383:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80107386:	31 ff                	xor    %edi,%edi
80107388:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010738f:	00 
  if(*pde & PTE_P){
80107390:	8b 4d 08             	mov    0x8(%ebp),%ecx
  pde = &pgdir[PDX(va)];
80107393:	89 f8                	mov    %edi,%eax
80107395:	c1 e8 16             	shr    $0x16,%eax
  if(*pde & PTE_P){
80107398:	8b 04 81             	mov    (%ecx,%eax,4),%eax
8010739b:	a8 01                	test   $0x1,%al
8010739d:	75 11                	jne    801073b0 <copyuvm+0x50>
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
      panic("copyuvm: pte should exist");
8010739f:	83 ec 0c             	sub    $0xc,%esp
801073a2:	68 6c 7a 10 80       	push   $0x80107a6c
801073a7:	e8 f4 8f ff ff       	call   801003a0 <panic>
801073ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return &pgtab[PTX(va)];
801073b0:	89 fa                	mov    %edi,%edx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
801073b2:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
801073b7:	c1 ea 0a             	shr    $0xa,%edx
801073ba:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
801073c0:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
801073c7:	85 c0                	test   %eax,%eax
801073c9:	74 d4                	je     8010739f <copyuvm+0x3f>
    if(!(*pte & PTE_P))
801073cb:	8b 30                	mov    (%eax),%esi
801073cd:	f7 c6 01 00 00 00    	test   $0x1,%esi
801073d3:	0f 84 98 00 00 00    	je     80107471 <copyuvm+0x111>
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
801073d9:	e8 d2 b3 ff ff       	call   801027b0 <kalloc>
801073de:	89 c3                	mov    %eax,%ebx
801073e0:	85 c0                	test   %eax,%eax
801073e2:	74 64                	je     80107448 <copyuvm+0xe8>
    pa = PTE_ADDR(*pte);
801073e4:	89 f0                	mov    %esi,%eax
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
801073e6:	83 ec 04             	sub    $0x4,%esp
    flags = PTE_FLAGS(*pte);
801073e9:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
    pa = PTE_ADDR(*pte);
801073ef:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    memmove(mem, (char*)P2V(pa), PGSIZE);
801073f4:	68 00 10 00 00       	push   $0x1000
801073f9:	05 00 00 00 80       	add    $0x80000000,%eax
801073fe:	50                   	push   %eax
801073ff:	53                   	push   %ebx
80107400:	e8 2b d6 ff ff       	call   80104a30 <memmove>
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
80107405:	58                   	pop    %eax
80107406:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
8010740c:	5a                   	pop    %edx
8010740d:	56                   	push   %esi
8010740e:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107413:	89 fa                	mov    %edi,%edx
80107415:	50                   	push   %eax
80107416:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80107419:	e8 32 f8 ff ff       	call   80106c50 <mappages>
8010741e:	83 c4 10             	add    $0x10,%esp
80107421:	83 f8 ff             	cmp    $0xffffffff,%eax
80107424:	74 3a                	je     80107460 <copyuvm+0x100>
  for(i = 0; i < sz; i += PGSIZE){
80107426:	81 c7 00 10 00 00    	add    $0x1000,%edi
8010742c:	3b 7d 0c             	cmp    0xc(%ebp),%edi
8010742f:	0f 82 5b ff ff ff    	jb     80107390 <copyuvm+0x30>
80107435:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  return d;

bad:
  freevm(d);
  return 0;
}
80107438:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010743b:	89 d0                	mov    %edx,%eax
8010743d:	5b                   	pop    %ebx
8010743e:	5e                   	pop    %esi
8010743f:	5f                   	pop    %edi
80107440:	5d                   	pop    %ebp
80107441:	c3                   	ret
80107442:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80107448:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  freevm(d);
8010744b:	83 ec 0c             	sub    $0xc,%esp
8010744e:	52                   	push   %edx
8010744f:	e8 9c fd ff ff       	call   801071f0 <freevm>
  return 0;
80107454:	83 c4 10             	add    $0x10,%esp
    return 0;
80107457:	31 d2                	xor    %edx,%edx
80107459:	eb dd                	jmp    80107438 <copyuvm+0xd8>
8010745b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      kfree(mem);
80107460:	83 ec 0c             	sub    $0xc,%esp
80107463:	53                   	push   %ebx
80107464:	e8 57 b1 ff ff       	call   801025c0 <kfree>
      goto bad;
80107469:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010746c:	83 c4 10             	add    $0x10,%esp
8010746f:	eb da                	jmp    8010744b <copyuvm+0xeb>
      panic("copyuvm: page not present");
80107471:	83 ec 0c             	sub    $0xc,%esp
80107474:	68 86 7a 10 80       	push   $0x80107a86
80107479:	e8 22 8f ff ff       	call   801003a0 <panic>
8010747e:	66 90                	xchg   %ax,%ax

80107480 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
80107480:	55                   	push   %ebp
80107481:	89 e5                	mov    %esp,%ebp
80107483:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107486:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80107489:	89 c1                	mov    %eax,%ecx
8010748b:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
8010748e:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107491:	f6 c2 01             	test   $0x1,%dl
80107494:	0f 84 f0 00 00 00    	je     8010758a <uva2ka.cold>
  return &pgtab[PTX(va)];
8010749a:	c1 e8 0c             	shr    $0xc,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
8010749d:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  if((*pte & PTE_P) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
}
801074a3:	5d                   	pop    %ebp
  return &pgtab[PTX(va)];
801074a4:	25 ff 03 00 00       	and    $0x3ff,%eax
  if((*pte & PTE_P) == 0)
801074a9:	8b 94 82 00 00 00 80 	mov    -0x80000000(%edx,%eax,4),%edx
  return (char*)P2V(PTE_ADDR(*pte));
801074b0:	89 d0                	mov    %edx,%eax
801074b2:	f7 d2                	not    %edx
801074b4:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801074b9:	05 00 00 00 80       	add    $0x80000000,%eax
801074be:	83 e2 05             	and    $0x5,%edx
801074c1:	ba 00 00 00 00       	mov    $0x0,%edx
801074c6:	0f 45 c2             	cmovne %edx,%eax
}
801074c9:	c3                   	ret
801074ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801074d0 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
801074d0:	55                   	push   %ebp
801074d1:	89 e5                	mov    %esp,%ebp
801074d3:	57                   	push   %edi
801074d4:	56                   	push   %esi
801074d5:	53                   	push   %ebx
801074d6:	83 ec 0c             	sub    $0xc,%esp
801074d9:	8b 75 14             	mov    0x14(%ebp),%esi
801074dc:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801074df:	8b 55 10             	mov    0x10(%ebp),%edx
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
801074e2:	85 f6                	test   %esi,%esi
801074e4:	75 49                	jne    8010752f <copyout+0x5f>
801074e6:	e9 95 00 00 00       	jmp    80107580 <copyout+0xb0>
801074eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  return (char*)P2V(PTE_ADDR(*pte));
801074f0:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char*)va0);
    if(pa0 == 0)
801074f5:	05 00 00 00 80       	add    $0x80000000,%eax
801074fa:	74 6e                	je     8010756a <copyout+0x9a>
      return -1;
    n = PGSIZE - (va - va0);
801074fc:	89 fb                	mov    %edi,%ebx
801074fe:	29 cb                	sub    %ecx,%ebx
80107500:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if(n > len)
80107506:	39 f3                	cmp    %esi,%ebx
80107508:	0f 47 de             	cmova  %esi,%ebx
      n = len;
    memmove(pa0 + (va - va0), buf, n);
8010750b:	29 f9                	sub    %edi,%ecx
8010750d:	83 ec 04             	sub    $0x4,%esp
80107510:	01 c8                	add    %ecx,%eax
80107512:	53                   	push   %ebx
80107513:	52                   	push   %edx
80107514:	89 55 10             	mov    %edx,0x10(%ebp)
80107517:	50                   	push   %eax
80107518:	e8 13 d5 ff ff       	call   80104a30 <memmove>
    len -= n;
    buf += n;
8010751d:	8b 55 10             	mov    0x10(%ebp),%edx
    va = va0 + PGSIZE;
80107520:	8d 8f 00 10 00 00    	lea    0x1000(%edi),%ecx
  while(len > 0){
80107526:	83 c4 10             	add    $0x10,%esp
    buf += n;
80107529:	01 da                	add    %ebx,%edx
  while(len > 0){
8010752b:	29 de                	sub    %ebx,%esi
8010752d:	74 51                	je     80107580 <copyout+0xb0>
  if(*pde & PTE_P){
8010752f:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pde = &pgdir[PDX(va)];
80107532:	89 c8                	mov    %ecx,%eax
    va0 = (uint)PGROUNDDOWN(va);
80107534:	89 cf                	mov    %ecx,%edi
  pde = &pgdir[PDX(va)];
80107536:	c1 e8 16             	shr    $0x16,%eax
    va0 = (uint)PGROUNDDOWN(va);
80107539:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
  if(*pde & PTE_P){
8010753f:	8b 04 83             	mov    (%ebx,%eax,4),%eax
80107542:	a8 01                	test   $0x1,%al
80107544:	0f 84 47 00 00 00    	je     80107591 <copyout.cold>
  return &pgtab[PTX(va)];
8010754a:	89 fb                	mov    %edi,%ebx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
8010754c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107551:	c1 eb 0c             	shr    $0xc,%ebx
80107554:	81 e3 ff 03 00 00    	and    $0x3ff,%ebx
  if((*pte & PTE_P) == 0)
8010755a:	8b 84 98 00 00 00 80 	mov    -0x80000000(%eax,%ebx,4),%eax
  if((*pte & PTE_U) == 0)
80107561:	89 c3                	mov    %eax,%ebx
80107563:	f7 d3                	not    %ebx
80107565:	83 e3 05             	and    $0x5,%ebx
80107568:	74 86                	je     801074f0 <copyout+0x20>
  }
  return 0;
}
8010756a:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
8010756d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80107572:	5b                   	pop    %ebx
80107573:	5e                   	pop    %esi
80107574:	5f                   	pop    %edi
80107575:	5d                   	pop    %ebp
80107576:	c3                   	ret
80107577:	90                   	nop
80107578:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010757f:	00 
80107580:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80107583:	31 c0                	xor    %eax,%eax
}
80107585:	5b                   	pop    %ebx
80107586:	5e                   	pop    %esi
80107587:	5f                   	pop    %edi
80107588:	5d                   	pop    %ebp
80107589:	c3                   	ret

8010758a <uva2ka.cold>:
  if((*pte & PTE_P) == 0)
8010758a:	a1 00 00 00 00       	mov    0x0,%eax
8010758f:	0f 0b                	ud2

80107591 <copyout.cold>:
80107591:	a1 00 00 00 00       	mov    0x0,%eax
80107596:	0f 0b                	ud2
